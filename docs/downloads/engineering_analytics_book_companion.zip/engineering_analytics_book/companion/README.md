# Reproduce the book analysis

This companion analyzes a pinned simulator artifact set and generates clearly labeled synthetic teaching data. It does not execute or modify the scheduler, call external services, train models, or require private Chrema or Nearwork data.

## Run

From the book's root directory:

```bash
python companion/analyze.py
python companion/check_outputs.py
```

Dependencies used for the verified run: Python 3.12.14, NumPy 2.3.5, pandas 2.2.3, and matplotlib 3.10.8. The code uses those libraries plus Python's standard library. Install dependencies in an appropriate isolated environment if they are absent; do not change an unrelated project environment to reproduce the book.

## Inputs and integrity

The snapshot manifest records the byte size and SHA-256 of each input. The analysis verifies them before producing any result. The simulator author confirmed these reports and diagnosis-prefixed traces form one coherent post-repair artifact set. Five copied simulator source files support inspecting metric definitions; the book's analysis does not import them. The snapshot is for evidence and analysis, not a standalone runnable scheduler distribution.

The diagnostic files represent FIFO, a reproduced pre-fix proposed policy, the repaired proposed policy, protection disabled, and a one-time forced-final-GPU intervention. The intervention is a diagnostic experiment, not a deployable general policy or an exact oracle.

The holdout report has 72 rows: 4 scenarios x 3 seeds x 3 policies x 2 regimes. A scenario-specific comparison in one regime has only 3 paired workloads. The 12 objective-ablation rows change one coefficient on those same follow-up seeds; after inspection they should not be described as fresh confirmation for a tuned next default.

All scheduler times are from synthetic simulation except the separately reported wall-clock planner timing. Do not interpret simulated time as measured physical hardware performance or add planner timing to simulated time without a defined model.

## Derived files

- scheduler_tasks.csv: 60 task observations across five traces; arrival, readiness, first phase, accepted result, latency, and waiting
- scheduler_phases.csv: one row per complete phase interval; times, resource, phase, and generation
- scheduler_candidates.csv: one row per candidate in a recorded decision; score components and serialized actions
- diagnosis_metrics.csv: scalar report metrics by diagnostic variant
- resource_accounting.csv: compute, reserved noncompute, and unreserved device seconds
- holdout_runs.csv: all 72 report rows with regime and comparison keys
- holdout_paired.csv: 12 matched-service scenario-seed rows with policy times and differences
- holdout_means.csv: descriptive scenario-policy means from 3 seeds each
- objective_ablation_pairs.csv: 12 one-to-one matched default and changed-weight runs
- synthetic_agent_trials.csv: 1,080 generated trials, with no actual human or agent observations
- synthetic_judge_confusion.csv and synthetic_calibration.csv: generated judge diagnostics
- synthetic_agent_metrics.csv: generated variant success, cost, and latency summaries
- synthetic_paired_runs.csv: 30 generated independent blocks for bootstrap mechanics
- synthetic_research_records.csv: 100 generated records with deliberately selective missingness
- analysis_summary.json: key calculated numbers and library versions
- validation.txt: result of the input and reconstruction checks

## Metric details

The simulator's makespan is the last accepted completion timestamp relative to the simulated run origin. The complete diagnostic runs use the same origin. It is not first-arrival-to-last-completion unless the first arrival occurs at zero. Task latency is accepted completion minus arrival. Ready waiting time begins when dependencies permit execution. The report uses nearest-rank quantiles; for 12 completed tasks its p95 is the maximum and p50 is the sixth sorted value.

Trace timestamps are rounded to six decimal places, while report values have higher precision. Reconciliation uses explicit tolerances. The teaching parser is designed for these complete, single-attempt traces and rejects unmatched phases. A general ingestion pipeline must preserve cancellations, retries, unresolved tasks, and censored intervals rather than applying this fixture's completion assumptions.

The synthetic bootstrap is a percentile bootstrap of the mean paired difference with 20,000 resamples and a fixed seed. Its interval is illustrative. No inferential interval is used to claim general scheduler superiority from three held-out seeds.

## Figures

Figures are regenerated as PNG and SVG. They use the copied traces and reports or explicitly synthetic tables. Line patterns distinguish overlapping scheduler ECDFs. Phase bars do not imply that every blank interval was avoidable. The two holdout panels use a common horizontal scale. The synthetic calibration view shows bin counts and the prediction histogram so sparse regions stay visible.
