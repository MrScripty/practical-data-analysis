"""Immutable descriptors and pure, physical-domain envelope construction.

Memory is GiB; time seconds; rates are abstract compute units / second.
Slot resources are enforced discrete counts, never GPU utilization fractions.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

EPS = 1e-8
Resources = dict[str, float]


def add(*vectors: Resources) -> Resources:
    out: Resources = {}
    for vector in vectors:
        for key, value in vector.items():
            out[key] = out.get(key, 0.0) + value
    return {k: v for k, v in out.items() if abs(v) > EPS}


def peak(*vectors: Resources) -> Resources:
    return {k: max(v.get(k, 0.0) for v in vectors) for k in set().union(*vectors)}


@dataclass(frozen=True)
class Model:
    id: str
    weights: float
    load_ram: float = 1.0
    load_vram: float = 0.5
    retained_ram: float = 0.25
    unload_s: float = 0.15
    revision: str = "synthetic-v1-q4"
    envelope_known: bool = True


@dataclass(frozen=True)
class Host:
    id: str
    ram: float = 32.0
    vram: float = 16.0
    ram_margin: float = 2.0
    vram_margin: float = 1.0
    cpu_rate: float = 1.0
    gpu_rate: float = 5.0
    storage_gib_s: float = 2.0
    link_gib_s: float = 0.12
    link_latency_s: float = 0.005
    cpu_slots: int = 1
    gpu_slots: int = 1
    loader_slots: int = 1
    shared_dram: bool = False
    serial_owner: bool = False
    replicas: bool = True
    overlap_load_compute: bool = True
    mixed_slowdown: float = 1.35
    io_slowdown: float = 1.15
    remote: bool = False
    devices: tuple[str, ...] = ("cpu", "gpu")

    def memory(self, device: str) -> str:
        return f"{self.id}:ram" if device == "cpu" or self.shared_dram else f"{self.id}:vram"

    def capacity(self) -> Resources:
        cap = {f"{self.id}:ram": self.ram - self.ram_margin,
               f"{self.id}:cpu": self.cpu_slots,
               f"{self.id}:gpu": self.gpu_slots,
               f"{self.id}:loader": self.loader_slots,
               f"{self.id}:link": 1}
        if not self.shared_dram:
            cap[f"{self.id}:vram"] = self.vram - self.vram_margin
        if self.serial_owner:
            cap[f"{self.id}:owner"] = 1
        return cap


@dataclass(frozen=True)
class Task:
    id: str
    app: str
    workflow: str
    model: str
    work: float
    arrival: float = 0.0
    deps: tuple[str, ...] = ()
    devices: tuple[str, ...] = ("cpu", "gpu")
    hosts: tuple[str, ...] = ()
    ram: float = 0.5
    vram: float = 0.5
    kv_peak: float = 0.0
    input_gib: float = 0.0
    output_gib: float = 0.0
    output_hold_s: float = 0.0
    value: float = 1.0
    terminal: bool = True
    deadline: float | None = None
    envelope_known: bool = True


@dataclass(frozen=True)
class Hint:
    id: str
    model: str
    app: str
    need_at: float
    expires: float
    confidence: float = 0.8
    count: int = 1
    generation: int = 0
    host: str = "local"
    device: str = "gpu"
    issued_at: float = 0.0


@dataclass(frozen=True)
class Action:
    kind: str
    host: str
    device: str
    task: str = ""
    model: str = ""

    def key(self) -> tuple[str, ...]:
        return self.kind, self.host, self.device, self.task, self.model


@dataclass(frozen=True)
class Plan:
    version: int
    actions: tuple[Action, ...] = ()
    offer_generations: tuple[tuple[str, int], ...] = ()


@dataclass
class Replica:
    host: str
    device: str
    model: str
    state: str = "ready"
    pins: int = 0
    loaded_at: float = 0.0
    busy_seconds: float = 0.0


@dataclass
class Attempt:
    task: str
    generation: int
    host: str
    device: str
    phase: str
    remaining: float
    base_total: float
    phase_started: float
    started: float
    lease: str
    model_key: tuple[str, str, str]
    cancelled: bool = False
    fail_load: bool = False
    phase_context: str = "isolated"
    phase_context_changed: bool = False
    phase_prior: float = 1.0
    compute_fraction: float = 0.0
    cleanup_reason: str = ""


@dataclass
class Transition:
    action: Action
    remaining: float
    started: float
    lease: str
    kind: str
    prior: float = 1.0


@dataclass(frozen=True)
class Config:
    policy: str = "proposed"
    horizon_s: float = 16.0
    shortlist: int = 6
    beam_width: int = 10
    bundle_depth: int = 2
    scenarios: int = 3
    rollout_events: int = 28
    fairness_gap_s: float = 8.0
    periodic_s: float = 2.0
    delay_weight: float = 0.25
    transition_cost: float = 0.025  # value / GiB moved
    hint_weight: float = 0.30       # bounded value / forecast request
    early_residency_cost: float = 0.0005  # value / GiB-second
    risk_weight: float = 0.05      # value / dimensionless late exposure
    cvar_alpha: float = 0.8
    boost_max: float = 4.0
    max_retries: int = 1
    noise: float = 0.08
    protect: bool = True
    fair_baselines: bool = False
    baseline_boosts: bool = False


@dataclass
class Scenario:
    name: str
    description: str
    hosts: list[Host]
    models: list[Model]
    tasks: list[Task]
    hints: list[Hint] = field(default_factory=list)
    events: list[tuple[float, str, dict[str, Any]]] = field(default_factory=list)
    resident: list[tuple[str, str, str]] = field(default_factory=list)
    max_time: float = 300.0


def weights(host: Host, device: str, model: Model) -> Resources:
    out = {host.memory(device): model.weights}
    if device == "gpu":
        out = add(out, {f"{host.id}:ram": model.retained_ram})
    return out


def compute_envelope(host: Host, device: str, task: Task) -> Resources:
    out = {f"{host.id}:ram": task.ram + task.input_gib + task.output_gib}
    if device == "gpu":
        out = add(out, {host.memory(device): task.vram + task.kv_peak})
    else:
        out = add(out, {host.memory(device): task.kv_peak})
    return out


def load_envelope(host: Host, device: str, model: Model) -> Resources:
    out = {f"{host.id}:ram": model.load_ram}
    return add(out, {host.memory(device): model.load_vram}) if device == "gpu" else out


def episode_envelope(host: Host, device: str, task: Task, model: Model, cold: bool) -> Resources:
    """Incremental reservation, excluding weights already represented separately.

    Sequential transfer/load/compute peaks use componentwise max; a retained output
    buffer is reserved through all phases. There is no predicted future release.
    """
    compute = compute_envelope(host, device, task)
    staging = add(load_envelope(host, device, model),
                  {f"{host.id}:ram": task.input_gib + task.output_gib})
    out = peak(compute, staging) if cold else compute
    slots = {f"{host.id}:{device}": 1}
    if cold:
        slots[f"{host.id}:loader"] = 1
    if host.remote and (task.input_gib or task.output_gib):
        slots[f"{host.id}:link"] = 1
    if host.serial_owner:
        slots[f"{host.id}:owner"] = 1
    return add(out, slots)
