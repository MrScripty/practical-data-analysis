# Sources for the mathematical extension

The worked arrays, simulations, images, prose, and charts are original teaching examples. Sources below support definitions, conventions, and further study. Documentation may advance independently of the tested runtime versions.

M01. [MIT projections and least squares](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/pages/least-squares-determinants-and-eigenvalues/projection-matrices-and-least-squares/)

Used in chapter 14. Geometric connection between projection and least-squares residuals.

M02. [NIST mean vector and covariance matrix](https://www.itl.nist.gov/div898/handbook/pmc/section5/pmc541.htm)

Used in chapter 14. Sample covariance definition and observation/feature orientation.

M03. [NumPy covariance](https://numpy.org/doc/stable/reference/generated/numpy.cov.html)

Used in chapter 14. rowvar orientation and covariance API.

M04. [MIT singular value decomposition](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/pages/positive-definite-matrices-and-applications/singular-value-decomposition/)

Used in chapter 14. Matrix factorization and singular directions; original example derived separately.

M05. [NumPy singular value decomposition](https://numpy.org/doc/stable/reference/generated/numpy.linalg.svd.html)

Used in chapter 14. Returned U, singular values, Vh and reconstruction conventions.

M06. [scikit-learn clustering guide](https://scikit-learn.org/stable/modules/clustering.html)

Used in chapter 14. Clustering objectives and contrasting method assumptions.

M07. [scikit-image image data types](https://scikit-image.org/docs/stable/user_guide/data_types.html)

Used in chapter 15. Image dtype and range conventions.

M08. [SciPy multidimensional convolution](https://docs.scipy.org/doc/scipy/reference/generated/scipy.ndimage.convolve.html)

Used in chapter 15. Convolution and boundary-mode concepts; companion implements its own explicit NumPy reflection convention.

M09. [NumPy discrete Fourier transform conventions](https://numpy.org/doc/stable/reference/routines.fft.html)

Used in chapter 15. Frequency ordering, transform normalization, real-valued transform representation.

M10. [scikit-image morphology](https://scikit-image.org/docs/stable/api/skimage.morphology.html)

Used in chapter 15. Erosion, dilation, opening, closing and footprints.

M11. [scikit-image region measurements](https://scikit-image.org/docs/stable/api/skimage.measure.html)

Used in chapter 15. Connected-region measurement, spacing, area and coordinates.

M12. [Boyd and Vandenberghe Convex Optimization](https://web.stanford.edu/~boyd/cvxbook/)

Used in chapter 18. Author-hosted legal book availability and further study of convex problems.

M13. [SciPy optimization guide](https://docs.scipy.org/doc/scipy/tutorial/optimize.html)

Used in chapter 18. Distinguishing solver families and problem structures.

M14. [NIST law of propagation of uncertainty](https://www.nist.gov/pml/nist-technical-note-1297/nist-tn-1297-appendix-law-propagation-uncertainty)

Used in chapter 18. First-order sensitivities, variances, and covariance terms.

M15. [NIST uncertainty budgets and sensitivity coefficients](https://www.itl.nist.gov/div898/handbook/mpc/section5/mpc56.htm)

Used in chapter 18. Relating input uncertainty to output uncertainty contributions.

M16. [JCGM 101 Monte Carlo propagation](https://www.bipm.org/documents/20126/2071204/JCGM_101_2008_E.pdf/325dcaad-c15a-407c-1105-8b7f322d651c)

Used in chapter 18. Propagation of distributions, conditions and separation from validity of the input model.
