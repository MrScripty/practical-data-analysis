"""Deterministic event engine and authoritative workflow/worker adapters.

Policy sees the ready frontier. Only this workflow-owner harness traverses edges.
Remote behavior is an in-memory protocol simulation, not network infrastructure.
"""
from __future__ import annotations
from collections import defaultdict, deque
from dataclasses import asdict
import copy
import hashlib
import heapq
import math
import time
from typing import Any
from .domain import *
from .ledger import Ledger
from .predictor import Predictor
from .admission import prepare, individually_feasible, replica_lease


class Engine:
    def __init__(self, scenario: Scenario, config: Config | None = None, seed: int = 7):
        self.scenario = scenario
        self.config = config or Config()
        self.seed = seed
        self.validate_inputs(scenario, self.config)
        self.now = 0.0
        self.version = 0
        self.hosts = {h.id: h for h in scenario.hosts}
        self.models = {m.id: m for m in scenario.models}
        self.tasks = {t.id: t for t in scenario.tasks}
        if len(self.tasks) != len(scenario.tasks) or len(self.models) != len(scenario.models):
            raise ValueError("Task/model identity must be unique")
        if any(t.model not in self.models or any(d not in self.tasks for d in t.deps) for t in scenario.tasks):
            raise ValueError("Unknown dependency or model")
        self.ledger = Ledger(add(*(h.capacity() for h in self.hosts.values())))
        self.status = {t.id: "pending" for t in scenario.tasks}
        self.generations = {t.id: 0 for t in scenario.tasks}
        self.cancelled: dict[str, bool] = {}
        self.ready_since: dict[str, float] = {}
        self.finished: dict[str, float] = {}
        self.produced: set[tuple[str, int]] = set()
        self.first_started: dict[str, float] = {}
        self.attempts: dict[str, Attempt] = {}
        self.transitions: dict[str, Transition] = {}
        self.replicas: dict[tuple, Replica] = {}
        self.hints = list(scenario.hints)
        self.hint_generation = {h.id: h.generation for h in self.hints}
        self.predictor = Predictor()
        self.connected = {h: True for h in self.hosts}
        self.host_generation = {h: 0 for h in self.hosts}
        self.offer_generation = {h: 0 for h in self.hosts}
        self.reject_once: set[str] = set()
        self.actual_speed = {h: 1.0 for h in self.hosts}
        self.fail_next: set[str] = set()
        self.app_boost: dict[str, tuple[float, float]] = {}
        self.workflow_boost: dict[str, tuple[float, float]] = {}
        self.events: list[tuple[float, int, str, dict]] = []
        self.event_counter = 0
        self.trace: list[dict] = []
        self.stats: dict[str, float] = defaultdict(float)
        self.busy: dict[str, float] = defaultdict(float)
        self.residency_seconds: dict[str, float] = defaultdict(float)
        self.residency_busy_seconds: dict[str, float] = defaultdict(float)
        self.accepted_app_service: dict[str,float] = defaultdict(float)
        self.app_service: dict[str, float] = defaultdict(float)
        self.app_queue: deque[str] = deque()
        self.protected: str | None = None
        self.protected_inflight: str | None = None
        self.next_protected = self.config.fairness_gap_s
        self.planner_ms: list[float] = []
        self.rollout = False
        self.rollout_visible: set[str] = set()
        self.rollout_factor = 1.0
        self.admission_rejections = 0
        self.retry_count: dict[str, int] = defaultdict(int)
        for host, device, model in scenario.resident:
            key = host, device, model
            self.replicas[key] = Replica(host, device, model)
            self.ledger.leases[replica_lease(key)] = weights(self.hosts[host], device, self.models[model])
        self.ledger.check()
        for task in scenario.tasks:
            self.schedule(task.arrival, "arrival", {"task": task.id})
        for when, kind, data in scenario.events:
            self.schedule(when, kind, data)
        self.schedule(self.config.periodic_s, "tick", {})

    @staticmethod
    def validate_inputs(scenario: Scenario, config: Config) -> None:
        def finite_nonnegative(values):
            return all(math.isfinite(v) and v >= 0 for v in values)
        if config.scenarios < 1 or config.shortlist < 1 or config.beam_width < 1 or config.bundle_depth < 1 or config.rollout_events < 1:
            raise ValueError("Search count limits must be positive")
        if config.horizon_s <= 0 or config.periodic_s <= 0 or not 0 < config.cvar_alpha < 1 or not 0 <= config.noise < 1:
            raise ValueError("Invalid horizon, period, tail level or noise")
        if not finite_nonnegative([config.horizon_s,config.periodic_s,config.fairness_gap_s,config.delay_weight,config.transition_cost,config.hint_weight,config.risk_weight,scenario.max_time]):
            raise ValueError("Timing and cost bounds must be finite and nonnegative")
        if len({h.id for h in scenario.hosts}) != len(scenario.hosts):
            raise ValueError("Physical host identity must be unique")
        for host in scenario.hosts:
            if not finite_nonnegative([host.ram,host.vram,host.ram_margin,host.vram_margin,host.link_latency_s]):
                raise ValueError("Invalid host capacity")
            if host.ram < host.ram_margin or host.vram < host.vram_margin:
                raise ValueError("Margins exceed physical capacity")
            if not all(math.isfinite(v) and v > 0 for v in (host.cpu_rate,host.gpu_rate,host.storage_gib_s,host.link_gib_s,host.mixed_slowdown,host.io_slowdown)):
                raise ValueError("Effective rates and slowdown factors must be positive")
            if any(d not in ("cpu","gpu") for d in host.devices):
                raise ValueError("Only independent CPU/GPU modes are supported")
        for model in scenario.models:
            if not finite_nonnegative([model.weights,model.load_ram,model.load_vram,model.retained_ram,model.unload_s]):
                raise ValueError("Invalid model envelope")
        for task in scenario.tasks:
            if not finite_nonnegative([task.work,task.arrival,task.ram,task.vram,task.kv_peak,task.input_gib,task.output_gib,task.output_hold_s,task.value]):
                raise ValueError("Invalid task work or envelope")
        if any(not math.isfinite(t) or t < 0 for t, _, _ in scenario.events):
            raise ValueError("Invalid event time")

    def __deepcopy__(self, memo: dict) -> Engine:
        other = object.__new__(Engine)
        memo[id(self)] = other
        shared = {"scenario", "config", "hosts", "models", "tasks", "hints"}
        for name, value in self.__dict__.items():
            if name in ("trace", "planner_ms"):
                setattr(other, name, [])
            else:
                setattr(other, name, value if name in shared else copy.deepcopy(value, memo))
        return other

    def log(self, event: str, **fields: Any) -> None:
        if not self.rollout:
            self.trace.append({"time": round(self.now, 6), "event": event, **fields})

    def schedule(self, when: float, kind: str, data: dict) -> None:
        self.event_counter += 1
        heapq.heappush(self.events, (when, self.event_counter, kind, dict(data)))

    def plan(self, actions: tuple[Action, ...] = ()) -> Plan:
        return Plan(self.version, actions, tuple(sorted(self.offer_generation.items())))

    def ready(self) -> list[str]:
        return [t for t, state in self.status.items() if state == "ready"
                and (not self.rollout or t in self.rollout_visible)]

    def context(self, host: str, device: str) -> str:
        compute = [a for a in self.attempts.values() if a.host == host and a.phase == "compute"]
        if any(a.device != device for a in compute):
            return "mixed"
        if any(a.host == host and a.phase == "load" for a in self.attempts.values()) or any(
                t.action.host == host and t.kind == "load" for t in self.transitions.values()):
            return "loading"
        return "isolated"

    def prior(self, task: Task, host: Host, device: str, phase: str) -> float:
        model = self.models[task.model]
        if phase == "load":
            return .3 + model.weights / host.storage_gib_s
        if phase == "compute":
            return .05 + task.work / (host.cpu_rate if device == "cpu" else host.gpu_rate)
        if phase in ("transfer_in", "transfer_out"):
            amount = task.input_gib if phase == "transfer_in" else task.output_gib
            return host.link_latency_s + amount / host.link_gib_s
        return .1

    def predict_duration(self, task: Task, host: Host, device: str, phase: str,
                         context: str | None = None) -> float:
        ctx = context or self.context(host.id, device)
        key = self.predictor.key(host.id, device, task.model, phase, task.work, ctx)
        factor = host.mixed_slowdown if phase == "compute" and ctx == "mixed" else host.io_slowdown if ctx == "loading" else 1
        p = self.predictor.predict(key, self.prior(task, host, device, phase))
        return p.mean * (factor if p.support == "prior" else 1.0)

    def noise(self, task: str, generation: int, phase: str) -> float:
        # Stable counter-based sample: policies consume the same per-attempt noise.
        digest = hashlib.sha256(f"{self.seed}:{task}:{generation}:{phase}".encode()).digest()
        uniform = int.from_bytes(digest[:8], "big") / (2**64 - 1)
        return 1 + self.config.noise * (2 * uniform - 1)

    def phase_duration(self, task: Task, host: Host, device: str, phase: str, generation: int) -> float:
        if self.rollout:
            return self.predict_duration(task, host, device, phase, "isolated") * self.rollout_factor
        return self.prior(task, host, device, phase) * self.noise(task.id, generation, phase)

    def commit(self, plan: Plan) -> bool:
        additions, reason = prepare(self, plan, authoritative=True)
        if reason != "ok":
            self.admission_rejections += 1
            self.log("admission_rejected", reason=reason, actions=[asdict(a) for a in plan.actions])
            if reason in ("stale_worker_offer", "worker_rejected"):
                for a in plan.actions:
                    self.offer_generation[a.host] = self.host_generation[a.host]
                    self.reject_once.discard(a.host)
            return False
        if not plan.actions:
            return True
        if not self.ledger.commit(self.ledger.version, additions):
            raise AssertionError("Pure feasibility and atomic ledger disagree")
        self.version += 1
        self.log("commit", actions=[asdict(a) for a in plan.actions], usage=self.ledger.usage(),
                 lease_version=self.ledger.version, worker_generations=dict(plan.offer_generations))
        for action in plan.actions:
            host = self.hosts[action.host]
            if action.kind == "evict":
                key = action.host, action.device, action.model
                self.replicas[key].state = "evicting"
                lease = "evict:" + ":".join(key)
                self.transitions[lease] = Transition(action, self.models[action.model].unload_s,
                                                     self.now, lease, "evict", self.models[action.model].unload_s)
                self.stats["evictions"] += 1
                continue
            model_id = self.tasks[action.task].model if action.kind == "start" else action.model
            key = action.host, action.device, model_id
            cold = key not in self.replicas
            if cold:
                self.replicas[key] = Replica(*key, state="loading", loaded_at=self.now)
                self.stats["loads"] += 1
                self.stats["loaded_gib"] += self.models[model_id].weights
                if self.stats["ever_loaded:" + ":".join(key)]:
                    self.stats["reloads"] += 1
                self.stats["ever_loaded:" + ":".join(key)] += 1
            else:
                self.stats["warm_starts"] += 1
            if action.kind == "preload":
                dummy = Task(action.task, "hint", "hint", model_id, 1)
                duration = self.phase_duration(dummy, host, action.device, "load", 0)
                lease = "preload:" + ":".join(key)
                self.transitions[lease] = Transition(action, duration, self.now, lease, "load",
                                                     self.prior(dummy, host, action.device, "load"))
                self.log("preload_start", hint=action.task, model=model_id, host=host.id)
                continue
            task = self.tasks[action.task]
            self.status[task.id] = "running"
            self.first_started.setdefault(task.id, self.now)
            generation = self.generations[task.id]
            lease = f"attempt:{task.id}:{generation}"
            phase = "transfer_in" if host.remote and task.input_gib else "load" if cold else "compute"
            duration = self.phase_duration(task, host, action.device, phase, generation)
            attempt = Attempt(task.id, generation, host.id, action.device, phase, duration, duration,
                              self.now, self.now, lease, key, fail_load=task.id in self.fail_next,
                              phase_context=self.context(host.id, action.device),
                              phase_prior=self.prior(task, host, action.device, phase))
            self.fail_next.discard(task.id)
            self.attempts[lease] = attempt
            self.replicas[key].pins += 1
            if not cold:
                self.replicas[key].state = "in_use"
            if self.protected == task.id:
                self.protected_inflight = lease
                self.log("protected_start", task=task.id, app=task.app)
            self.log("phase_start", task=task.id, generation=generation, phase=phase, host=host.id, device=action.device)
        self.check()
        return True

    def slowdown(self, attempt: Attempt) -> float:
        host = self.hosts[attempt.host]
        result = 1.0
        if attempt.phase == "compute":
            if any(a.host == attempt.host and a.device != attempt.device and a.phase == "compute"
                   for a in self.attempts.values()):
                result *= host.mixed_slowdown
            if any(a.host == attempt.host and a.phase == "load" for a in self.attempts.values()) or any(
                    t.action.host == attempt.host and t.kind == "load" for t in self.transitions.values()):
                result *= host.io_slowdown
            if not self.rollout:
                result /= self.actual_speed[host.id]
        elif attempt.phase == "load" and any(a.host == attempt.host and a.phase == "compute" for a in self.attempts.values()):
            result *= host.io_slowdown
        return result

    def advance(self, target: float) -> None:
        dt = max(0, target - self.now)
        for attempt in self.attempts.values():
            before = attempt.remaining
            attempt.remaining = max(0, before - dt / self.slowdown(attempt))
            if self.context(attempt.host, attempt.device) != attempt.phase_context:
                attempt.phase_context_changed = True
            if attempt.phase == "compute":
                fraction = (before - attempt.remaining) / max(.001, attempt.base_total)
                attempt.compute_fraction += fraction
                self.app_service[self.tasks[attempt.task].app] += fraction
                self.busy[f"{attempt.host}:{attempt.device}:compute"] += dt
                self.replicas[attempt.model_key].busy_seconds += dt
                self.residency_busy_seconds[": ".join(attempt.model_key)] += dt
            else:
                self.busy[f"{attempt.host}:{attempt.device}:{attempt.phase}"] += dt
        for transition in self.transitions.values():
            factor = self.hosts[transition.action.host].io_slowdown if transition.kind == "load" and any(
                a.host == transition.action.host and a.phase == "compute" for a in self.attempts.values()) else 1
            transition.remaining = max(0, transition.remaining - dt / factor)
        for key, rep in self.replicas.items():
            self.residency_seconds[": ".join(key)] += dt
        self.now = target

    def set_phase(self, attempt: Attempt, phase: str) -> None:
        task = self.tasks[attempt.task]
        host = self.hosts[attempt.host]
        attempt.phase = phase
        attempt.phase_started = self.now
        attempt.phase_prior = self.prior(task, host, attempt.device, phase)
        attempt.remaining = self.phase_duration(task, host, attempt.device, phase, attempt.generation)
        attempt.base_total = attempt.remaining
        attempt.phase_context = self.context(host.id, attempt.device)
        attempt.phase_context_changed = False
        self.log("phase_start", task=task.id, generation=attempt.generation, phase=phase, host=host.id, device=attempt.device)

    def observe_phase(self, attempt: Attempt) -> None:
        if self.rollout or attempt.phase in ("drain", "cleanup"):
            return
        task = self.tasks[attempt.task]
        ctx = "changing" if attempt.phase_context_changed else attempt.phase_context
        key = self.predictor.key(attempt.host, attempt.device, task.model, attempt.phase, task.work, ctx)
        self.predictor.observe(key, attempt.phase_prior, self.now - attempt.phase_started, self.now,
                               censored=attempt.cancelled or bool(attempt.cleanup_reason))

    def phases_done(self) -> None:
        for lease, transition in list(self.transitions.items()):
            if transition.remaining > EPS:
                continue
            key = transition.action.host, transition.action.device, transition.action.model
            if transition.kind == "evict":
                if self.replicas[key].pins:
                    raise AssertionError("Eviction completed on a pinned model")
                self.ledger.release(replica_lease(key))
                del self.replicas[key]
                self.log("evict_ack", model=key[2], host=key[0], device=key[1])
            else:
                self.replicas[key].state = "ready"
                self.replicas[key].loaded_at = self.now
                self.ledger.release(lease)
                if not self.rollout:
                    pkey = self.predictor.key(key[0], key[1], key[2], "load", 1, "isolated")
                    self.predictor.observe(pkey, transition.prior, self.now - transition.started, self.now)
                self.log("preload_ready", model=key[2], host=key[0], device=key[1])
            del self.transitions[lease]
            self.version += 1
        for lease, attempt in list(self.attempts.items()):
            if attempt.remaining > EPS:
                continue
            self.observe_phase(attempt)
            task = self.tasks[attempt.task]
            host = self.hosts[attempt.host]
            self.log("phase_end", task=task.id, generation=attempt.generation, phase=attempt.phase)
            if attempt.phase == "cleanup":
                self.finish_attempt(lease, success=False)
            elif attempt.phase == "transfer_in":
                self.set_phase(attempt, "load" if self.replicas[attempt.model_key].state == "loading" else "compute")
            elif attempt.phase == "load":
                if attempt.fail_load:
                    attempt.cleanup_reason = "load_failure"
                    self.replicas[attempt.model_key].state = "failed"
                    self.set_phase(attempt, "cleanup")
                    attempt.remaining = attempt.base_total = .75
                    self.stats["load_failures"] += 1
                    continue
                self.replicas[attempt.model_key].state = "in_use"
                self.replicas[attempt.model_key].loaded_at = self.now
                reservation = episode_envelope(host, attempt.device, task, self.models[task.model], False)
                self.ledger.shrink(lease, reservation)
                self.version += 1
                self.set_phase(attempt, "compute")
            elif attempt.phase == "compute":
                self.set_phase(attempt, "transfer_out" if host.remote and task.output_gib else "drain")
            elif attempt.phase == "transfer_out":
                self.set_phase(attempt, "drain")
            elif attempt.phase == "drain":
                self.finish_attempt(lease, success=True)
        self.check()

    def finish_attempt(self, lease: str, success: bool) -> None:
        attempt = self.attempts.pop(lease)
        task = self.tasks[attempt.task]
        rep = self.replicas[attempt.model_key]
        rep.pins -= 1
        if not success and rep.state in ("failed", "loading") and not rep.pins:
            self.ledger.release(replica_lease(attempt.model_key))
            del self.replicas[attempt.model_key]
        else:
            rep.state = "in_use" if rep.pins else "ready"
        # Producer drain confirmed locally, even if coordinator connection is absent.
        if success and task.output_gib and task.output_hold_s:
            self.ledger.shrink(lease, {f"{attempt.host}:ram": task.output_gib})
            self.schedule(self.now + task.output_hold_s, "release_output", {"lease": lease})
        else:
            self.ledger.release(lease)
        self.version += 1
        if success and not attempt.cancelled:
            self.produced.add((task.id, attempt.generation))
            data = {"task": task.id, "generation": attempt.generation}
            if self.connected[attempt.host]:
                self.accept_result(**data)
            else:
                self.pending_results.append((attempt.host, data))
                self.log("result_awaits_reconnect", **data, host=attempt.host)
        elif attempt.generation == self.generations[task.id]:
            if attempt.cancelled:
                self.status[task.id] = "cancelled"
            elif self.retry_count[task.id] < self.config.max_retries:
                self.retry_count[task.id] += 1
                self.generations[task.id] += 1
                self.status[task.id] = "ready"
                self.log("retry_ready", task=task.id, generation=self.generations[task.id])
            else:
                self.status[task.id] = "failed"
        if self.protected_inflight == lease:
            self.protected = self.protected_inflight = None
            self.next_protected = self.now + self.config.fairness_gap_s
        self.log("producer_release_ack", task=task.id, generation=attempt.generation,
                 success=success, usage=self.ledger.usage())

    def accept_result(self, task: str, generation: int) -> bool:
        if (task, generation) not in self.produced or generation != self.generations[task] or self.cancelled.get(task) or self.status[task] == "done":
            self.stats["fenced_results"] += 1
            self.log("result_fenced", task=task, generation=generation)
            return False
        self.status[task] = "done"
        self.finished[task] = self.now
        self.stats["accepted_results"] += 1
        self.accepted_app_service[self.tasks[task].app] += self.tasks[task].value
        self.log("result_accepted", task=task, generation=generation)
        self.update_readiness()
        return True

    @property
    def pending_results(self) -> list:
        if not hasattr(self, "_pending_results"):
            self._pending_results = []
        return self._pending_results

    def update_readiness(self) -> None:
        for task in self.tasks.values():
            if self.status[task.id] != "pending" or task.arrival > self.now + EPS:
                continue
            if self.rollout and task.id not in self.rollout_visible:
                continue
            if any(self.status[d] in ("failed", "cancelled", "blocked") for d in task.deps):
                self.status[task.id] = "blocked"
            elif all(self.status[d] == "done" for d in task.deps):
                self.status[task.id] = "ready"
                self.ready_since[task.id] = self.now
                self.log("ready", task=task.id)

    def external_event(self, kind: str, data: dict) -> None:
        self.log(kind, **data)
        self.version += 1
        if kind == "arrival":
            self.update_readiness()
        elif kind == "tick":
            self.schedule(self.now + self.config.periodic_s, "tick", {})
        elif kind == "boost":
            value = max(1.0, min(self.config.boost_max, data["weight"]))
            (self.app_boost if "app" in data else self.workflow_boost)[data.get("app", data.get("workflow"))] = (value, data["until"])
        elif kind == "cancel":
            task = data["task"]
            if self.status[task] in ("done","cancelled","failed","blocked") or self.cancelled.get(task):
                self.log("cancel_ignored", task=task, reason="terminal_or_already_requested")
                return
            self.cancelled[task] = True
            found = False
            for attempt in self.attempts.values():
                if attempt.task == task:
                    found = True
                    self.observe_phase_cancel(attempt)
                    attempt.cancelled = True
                    attempt.cleanup_reason = "cancelled"
                    if attempt.phase != "cleanup":
                        self.set_phase(attempt, "cleanup")
                        attempt.remaining = attempt.base_total = data.get("cleanup_s", 1.0)
            if not found:
                self.status[task] = "cancelled"
            self.update_readiness()
        elif kind == "fail_load":
            self.fail_next.add(data["task"])
        elif kind == "drift":
            self.actual_speed[data["host"]] = data["speed"]
            if data.get("announced", False):
                self.predictor.invalidate(data["host"])
        elif kind == "withdraw_hint":
            self.hint_generation[data["hint"]] = data["generation"]
        elif kind == "disconnect":
            self.connected[data["host"]] = False
        elif kind == "reconnect":
            host = data["host"]
            self.connected[host] = True
            self.host_generation[host] += 1
            self.offer_generation[host] = self.host_generation[host]
            for h, result in list(self.pending_results):
                if h == host:
                    self.accept_result(**result)
                    self.pending_results.remove((h, result))
        elif kind == "fence_retry":
            task = data["task"]
            if self.status[task] not in ("done", "cancelled", "failed"):
                self.generations[task] += 1
                self.status[task] = "ready"
                # Old worker leases and execution intentionally remain untouched.
        elif kind == "worker_generation":
            self.host_generation[data["host"]] += 1
        elif kind == "reject_next":
            self.reject_once.add(data["host"])
        elif kind == "release_output":
            self.ledger.release(data["lease"])
        elif kind == "pressure":
            lease = "external:" + data["id"]
            if not self.ledger.commit(self.ledger.version, {lease: data["resources"]}):
                self.stats["external_pressure_rejected"] += 1
                self.log("external_pressure_refused", reason="outside_reserved_capacity")
            else:
                self.schedule(self.now + data["duration"], "release_output", {"lease": lease})
        elif kind == "stale_result":
            self.accept_result(data["task"], data["generation"])
        else:
            raise ValueError(f"Unsupported external event {kind}")

    def observe_phase_cancel(self, attempt: Attempt) -> None:
        if not self.rollout:
            task = self.tasks[attempt.task]
            key = self.predictor.key(attempt.host, attempt.device, task.model, attempt.phase, task.work, attempt.phase_context)
            self.predictor.observe(key, attempt.phase_prior, self.now-attempt.phase_started, self.now, censored=True)

    def boost(self, task: Task) -> float:
        app = self.app_boost.get(task.app, (1, 0))
        flow = self.workflow_boost.get(task.workflow, (1, 0))
        return max(app[0] if app[1] > self.now else 1, flow[0] if flow[1] > self.now else 1)

    def weight(self, task: Task) -> float:
        boost = self.boost(task)
        age = max(0, self.now - self.ready_since.get(task.id, self.now))
        return task.value * boost * (1 + min(.25, age / 100))

    def protected_target(self) -> str | None:
        if self.rollout or not self.config.protect or (self.config.policy != "proposed" and not self.config.fair_baselines):
            return None
        ready = self.ready()
        eligible = sorted((t for t in ready if individually_feasible(self, t)),
                          key=lambda t: (self.ready_since[t], self.tasks[t].arrival, t))
        apps = {self.tasks[t].app for t in eligible}
        self.app_queue = deque(a for a in self.app_queue if a in apps or
                               (self.protected and self.tasks[self.protected].app == a))
        for task in eligible:
            app = self.tasks[task].app
            if app not in self.app_queue and not (self.protected and self.tasks[self.protected].app == app):
                self.app_queue.append(app)
        if self.protected_inflight:
            return None
        if self.protected and (self.status[self.protected] != "ready" or not individually_feasible(self, self.protected)):
            self.log("protected_degraded", task=self.protected, reason="no_current_feasible_connected_mode")
            self.protected = None
            self.app_queue = deque(a for a in self.app_queue if a in apps)
        if self.protected:
            return self.protected
        if self.now + EPS >= self.next_protected and self.app_queue:
            app = self.app_queue.popleft()
            self.protected = next(t for t in eligible if self.tasks[t].app == app)
            self.log("protected_due", task=self.protected, app=app)
            return self.protected
        return None

    def check(self) -> None:
        self.ledger.check()
        pins: dict[tuple, int] = defaultdict(int)
        for attempt in self.attempts.values():
            if attempt.lease not in self.ledger.leases:
                raise AssertionError("Live attempt lost its lease")
            pins[attempt.model_key] += 1
        for key, rep in self.replicas.items():
            if rep.pins != pins[key] or replica_lease(key) not in self.ledger.leases:
                raise AssertionError("Replica lease/pin accounting mismatch")
        current = [(a.task, a.generation) for a in self.attempts.values()]
        if len(current) != len(set(current)):
            raise AssertionError("Duplicate execution of the same generation")

    def complete(self) -> bool:
        return all(s in ("done", "cancelled", "failed", "blocked") for s in self.status.values()) and not self.attempts

    def run(self, until: float | None = None, max_events: int = 20000, dispatch_first: bool = True) -> dict:
        from .policy import choose
        end = until if until is not None else self.scenario.max_time
        count = 0
        self.update_readiness()
        while self.events and self.events[0][0] <= self.now + EPS:
            _, _, kind, data = heapq.heappop(self.events)
            self.external_event(kind, data)
        while self.now < end - EPS and count < max_events:
            if self.complete() and not self.transitions and not any(e[2] == "release_output" for e in self.events):
                break
            start = time.perf_counter()
            plan = choose(self) if dispatch_first or count > 0 else self.plan()
            if not self.rollout:
                self.planner_ms.append((time.perf_counter() - start) * 1000)
            if plan.actions:
                if not self.commit(plan):
                    # Admission refreshed a stale worker offer; recompute immediately.
                    count += 1
                    continue
            soon = min((self.now + a.remaining * self.slowdown(a) for a in self.attempts.values()), default=math.inf)
            for transition in self.transitions.values():
                factor = self.hosts[transition.action.host].io_slowdown if transition.kind == "load" and any(
                    a.host == transition.action.host and a.phase == "compute" for a in self.attempts.values()) else 1
                soon = min(soon, self.now + transition.remaining * factor)
            if self.events:
                soon = min(soon, self.events[0][0])
            soon = min(soon, end)
            if soon < self.now - EPS:
                raise AssertionError("Event moved backward in time")
            self.advance(soon)
            self.phases_done()
            while self.events and self.events[0][0] <= self.now + EPS:
                _, _, kind, data = heapq.heappop(self.events)
                self.external_event(kind, data)
            self.check()
            count += 1
        self.stats["event_steps"] += count
        return self.metrics()

    def metrics(self) -> dict:
        completed = [self.tasks[t] for t in self.finished]
        workflows = sorted({t.workflow for t in self.tasks.values()})
        workflow_times = {}
        for flow in workflows:
            nodes = [t for t in self.tasks.values() if t.workflow == flow]
            if all(self.status[t.id] == "done" for t in nodes):
                workflow_times[flow] = max(self.finished[t.id] for t in nodes) - min(t.arrival for t in nodes)
        useful = sum(t.value for t in completed if t.terminal)
        latencies = sorted(self.finished[t.id] - t.arrival for t in completed)
        waits = sorted(self.first_started[t] - self.ready_since[t] for t in self.first_started)
        makespan = max(self.finished.values(), default=0)
        outstanding = {t:max(0,self.now-self.ready_since[t]) for t in self.ready()}
        waits += list(outstanding.values())
        def percentile(values: list[float], p: float) -> float | None:
            return values[min(len(values)-1, math.ceil(p*len(values))-1)] if values else None
        device_util = {}
        idle_categories = {}
        for host in self.hosts.values():
            for device in host.devices:
                compute = self.busy.get(f"{host.id}:{device}:compute", 0)
                slots = host.cpu_slots if device == "cpu" else host.gpu_slots
                device_util[f"{host.id}:{device}"] = compute / max(.001, self.now * slots)
                transition = sum(value for key,value in self.busy.items() if key.startswith(f"{host.id}:{device}:") and not key.endswith(":compute"))
                idle_categories[f"{host.id}:{device}"] = {"reserved_noncompute_s":transition,"unreserved_s":max(0,self.now*slots-compute-transition)}
        return {"scenario": self.scenario.name, "policy": self.config.policy, "seed": self.seed,
                "simulated_seconds": self.now, "makespan_s": makespan,
                "last_accepted_completion_s":makespan,
                "completed_batch_makespan_s": makespan if self.complete() else None,
                "unresolved_ready_count":len(outstanding),"unresolved_ready_age_s":outstanding,
                "completed_nodes": len(completed), "completed_workflows": len(workflow_times),
                "workflow_completion_s": workflow_times,
                "useful_value": useful, "useful_value_per_s": useful / max(.001, self.now),
                "completed_batch_useful_per_s": useful/max(.001,makespan) if self.complete() else None,
                "latency_p50_s": percentile(latencies, .5), "latency_p95_s": percentile(latencies, .95),
                "max_ready_wait_s": max(waits, default=0),
                "mean_workflow_completion_s": sum(workflow_times.values()) / max(1, len(workflow_times)),
                "status": dict(self.status), "compute_utilization": device_util, "idle_categories":idle_categories,
                "phase_device_seconds": dict(self.busy), "resident_seconds": dict(self.residency_seconds),
                "executed_service_units_including_retries": dict(self.app_service),
                "accepted_app_value":dict(self.accepted_app_service),
                "resident_busy_fraction":{key:self.residency_busy_seconds[key]/max(.001,total) for key,total in self.residency_seconds.items()},
                "peaks": dict(self.ledger.peaks),
                "loads": self.stats["loads"], "reloads": self.stats["reloads"], "loaded_gib": self.stats["loaded_gib"],
                "warm_starts": self.stats["warm_starts"], "fenced_results": self.stats["fenced_results"],
                "admission_rejections": self.admission_rejections,
                "predictor_observations": self.predictor.observations,
                "predictor_censored": self.predictor.censored, "drift_alarms": self.predictor.drift_count,
                "empirical_upper_coverage": sum(self.predictor.coverage)/max(1, len(self.predictor.coverage)),
                "planner_p50_ms": percentile(sorted(self.planner_ms), .5),
                "planner_p95_ms": percentile(sorted(self.planner_ms), .95),
                "terminal": self.complete()}
