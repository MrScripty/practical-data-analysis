#!/usr/bin/env python3
"""Assemble editable Markdown and a print-quality PDF from reviewed chapters."""
from pathlib import Path
import html
import json
import re
import textwrap
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph,
    Spacer, PageBreak, CondPageBreak, KeepTogether, Table, TableStyle,
    XPreformatted, Image, Flowable)
from reportlab.platypus.tableofcontents import TableOfContents

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
(ROOT/'qa').mkdir(exist_ok=True)
STEM='practical_data_analysis_for_engineering_decisions'
TITLE='Practical Data Analysis for Engineering Decisions'
chapters=sorted((ROOT/'chapters').glob('*.md'))
refs=(ROOT/'sources/REFERENCES.md').read_text()
contents=['## Contents','']+['- '+p.read_text().splitlines()[0].removeprefix('# ') for p in chapters[1:]]+['- Sources and evidence']
md=chapters[0].read_text().replace('# '+TITLE, '# '+TITLE+'\n\n**Puma**\n\nExpanded edition · 2 October 2026',1)+'\n\n'+'\n'.join(contents)+'\n\n'+'\n\n'.join(p.read_text() for p in chapters[1:])+'\n\n'+refs
(ROOT/(STEM+'.md')).write_text(md)
(OUT/(STEM+'.md')).write_text(md)

font_dir=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('BookSerif','DejaVuSerif'),('BookSerif-Bold','DejaVuSerif-Bold'),('BookSerif-Italic','DejaVuSerif-Italic'),('BookSans','DejaVuSans'),('BookSans-Bold','DejaVuSans-Bold'),('BookMono','DejaVuSansMono')]:
    pdfmetrics.registerFont(TTFont(name,str(font_dir/(file+'.ttf'))))
pdfmetrics.registerFontFamily('BookSerif',normal='BookSerif',bold='BookSerif-Bold',italic='BookSerif-Italic',boldItalic='BookSerif-Bold')
pdfmetrics.registerFontFamily('BookSans',normal='BookSans',bold='BookSans-Bold',italic='BookSans',boldItalic='BookSans-Bold')
BLACK=colors.black
S={
 'body':ParagraphStyle('body',fontName='BookSerif',fontSize=10.4,leading=15.0,spaceAfter=8.0,allowWidows=0,allowOrphans=0,textColor=BLACK),
 'h1':ParagraphStyle('h1',fontName='BookSans-Bold',fontSize=22,leading=28,spaceAfter=19,keepWithNext=True,textColor=BLACK),
 'h2':ParagraphStyle('h2',fontName='BookSans-Bold',fontSize=12.4,leading=17,spaceBefore=13,spaceAfter=7,keepWithNext=True,textColor=BLACK),
 'h3':ParagraphStyle('h3',fontName='BookSans-Bold',fontSize=11,leading=15,spaceBefore=11,spaceAfter=6,keepWithNext=True,textColor=BLACK),
 'caption':ParagraphStyle('caption',fontName='BookSans',fontSize=8.8,leading=12.5,spaceBefore=7,spaceAfter=13,allowWidows=0,allowOrphans=0,textColor=colors.HexColor('#333333')),
 'title':ParagraphStyle('title',fontName='BookSans-Bold',fontSize=33,leading=42,spaceAfter=28,textColor=BLACK),
 'subtitle':ParagraphStyle('subtitle',fontName='BookSans',fontSize=16,leading=24,spaceAfter=18,textColor=BLACK),
 'small':ParagraphStyle('small',fontName='BookSans',fontSize=9,leading=13.2,spaceAfter=7,textColor=colors.HexColor('#444444')),
 'toc':ParagraphStyle('toc',fontName='BookSans',fontSize=9.8,leading=12.8,spaceBefore=0,spaceAfter=0,rightIndent=18),
 'code':ParagraphStyle('code',fontName='BookMono',fontSize=8.6,leading=12.2,spaceBefore=7,spaceAfter=13,leftIndent=9,rightIndent=3),
 'table':ParagraphStyle('table',fontName='BookSans',fontSize=8.8,leading=12.5),
 'refhead':ParagraphStyle('refhead',fontName='BookSans-Bold',fontSize=10.1,leading=14.1,spaceAfter=4,spaceBefore=6,keepWithNext=True),
 'ref':ParagraphStyle('ref',fontName='BookSerif',fontSize=9.3,leading=13.4,spaceAfter=9),
}
S['compactBody']=ParagraphStyle('compactBody',parent=S['body'],spaceAfter=6.5)
WIDTH=500

def clean(s):
    return s.replace('\u2014',' - ').replace('\u2013','-').replace('\u2011','-')

def inline(s):
    s=clean(s); stash=[]
    def link(m):
        key=f'LINKPLACEHOLDER{len(stash)}END'
        stash.append('<a href="'+html.escape(m[2],quote=True)+'" color="#245066">'+html.escape(m[1])+'</a>')
        return key
    s=re.sub(r'\[([^]]+)\]\(([^)]+)\)',link,s)
    s=html.escape(s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'`([^`]+)`',r'<font name="BookMono">\1</font>',s)
    for i,x in enumerate(stash):s=s.replace(f'LINKPLACEHOLDER{i}END',x)
    return s

class Book(BaseDocTemplate):
    def beforeDocument(self):
        self.heading_pages=[]; self.chapter_title=''; self.figure_pages=[]; self.cover_pages=set()
    def afterFlowable(self,f):
        if hasattr(f,'book_cover'):self.cover_pages.add(self.page)
        if hasattr(f,'book_heading'):
            title,anchor=f.book_heading
            self.canv.bookmarkPage(anchor)
            self.canv.addOutlineEntry(title,anchor,0,False)
            self.notify('TOCEntry',(0,title,self.page,anchor))
            self.heading_pages.append({'title':title,'page':self.page,'anchor':anchor})
            self.chapter_title=title
        if hasattr(f,'book_figure'):
            self.figure_pages.append({'figure':f.book_figure,'page':self.page})

def page_decoration(canvas,doc):
    if doc.page in doc.cover_pages:return
    canvas.saveState()
    canvas.setFillColor(colors.HexColor('#555555'));canvas.setFont('BookSans',7.5)
    header=doc.chapter_title
    if len(header)>88:header=header[:85]+'...'
    canvas.drawString(56,760,header)
    canvas.drawString(56,31,'Practical Data Analysis')
    canvas.drawRightString(556,31,str(doc.page))
    canvas.restoreState()

def make_table(lines):
    rows=[]
    for line in lines:
        cells=[c.strip() for c in line.strip().strip('|').split('|')]
        if all(re.fullmatch(r':?-+:?',c) for c in cells):continue
        rows.append(cells)
    n=len(rows[0])
    if n==2:widths=[360,140]
    elif n==4 and rows[0][0]=='Task':widths=[86,138,138,138]
    elif n==4:widths=[146,118,118,118]
    else:widths=[WIDTH/n]*n
    data=[[Paragraph(inline('<noop>') if False else inline(cell),S['table']) for cell in row] for row in rows]
    for j in range(n):data[0][j]=Paragraph('<b>'+inline(rows[0][j])+'</b>',S['table'])
    table=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    table.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E7EEF1')),
        ('GRID',(0,0),(-1,-1),.35,colors.HexColor('#D9D9D9')),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F6F8F9')])
    ]))
    return table

counter=0

def parse(raw,first=False,reference=False,compact=False):
    global counter
    lines=raw.splitlines();i=0;flow=[]
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if first and line=='# '+TITLE:i+=1;continue
        h=re.match(r'^(#{1,3}) (.+)',line)
        if h:
            level=len(h[1]);title=h[2]
            if first and title=='Start here':level=1
            para=Paragraph(inline(title),S['h'+str(level)])
            if level==1:
                counter+=1;para.book_heading=(title,'section-'+str(counter))
            flow.append(para);i+=1;continue
        if line.startswith('```'):
            chunk=[];i+=1
            while i<len(lines) and not lines[i].startswith('```'):
                chunk.append(clean(lines[i]));i+=1
            i+=1
            longest=max([pdfmetrics.stringWidth(x,'BookMono',8.6) for x in chunk] or [0])
            assert longest<=WIDTH-12,f'Code overflow {longest}: '+max(chunk,key=len)
            flow.append(KeepTogether([XPreformatted(html.escape('\n'.join(chunk)),S['code'])]));continue
        if line.startswith('|'):
            chunk=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                chunk.append(lines[i]);i+=1
            flow.append(KeepTogether([Spacer(1,5),make_table(chunk),Spacer(1,12)]));continue
        image=re.fullmatch(r'!\[([^]]*)\]\(([^)]+)\)',line)
        if image:
            img=Image(str(ROOT/image[2]));ratio=WIDTH/img.imageWidth
            img.drawWidth=WIDTH;img.drawHeight=img.imageHeight*ratio;img.hAlign='LEFT'
            img.book_figure=image[2]
            # Keep the figure with its caption; make its own leading room.
            group=[Spacer(1,6),img];i+=1
            while i<len(lines) and not lines[i].strip():i+=1
            if i<len(lines) and lines[i].startswith('Figure '):
                cap=[lines[i]];i+=1
                while i<len(lines) and lines[i].strip() and not lines[i].startswith('#'):
                    cap.append(lines[i]);i+=1
                cp=Paragraph(inline(' '.join(cap)),S['caption']);cp.book_figure=image[2];group.append(cp)
            flow.append(KeepTogether(group));continue
        if reference and re.match(r'^[SMGF]\d+\.',line):
            group=[Paragraph(inline(line),S['refhead'])];i+=1
            while i<len(lines) and not lines[i].strip():i+=1
            if i<len(lines) and lines[i].startswith('Used in'):
                group.append(Paragraph(inline(lines[i]),S['ref']));i+=1
            flow.append(KeepTogether(group));continue
        chunk=[line];i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'^(?:#|!\[|\||```)',lines[i]):
            chunk.append(lines[i].strip());i+=1
        txt=' '.join(chunk)
        if txt.startswith('- '):txt='• '+txt[2:]
        flow.append(Paragraph(inline(txt),S['compactBody'] if compact else S['body']))
    return flow

pdf=OUT/(STEM+'.pdf')
doc=Book(str(pdf),pagesize=(612,792),title=TITLE,author='Puma',
         subject='Expanded practical analytics book covering engineering evidence, matrices, images, GIS, finance, and uncertainty',
         leftMargin=56,rightMargin=56,topMargin=53,bottomMargin=52)
doc.addPageTemplates([PageTemplate(id='book',frames=Frame(56,52,500,687,id='body',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0),onPageEnd=page_decoration)])
class FullPageCover(Flowable):
    def __init__(self,path):
        super().__init__();self.path=str(path);self.width=1;self.height=1;self.book_cover=True
    def draw(self):
        c=self.canv;c.saveState();c.resetTransforms()
        c.drawImage(self.path,0,0,width=612,height=792)
        c.restoreState()

story=[FullPageCover(ROOT/'covers/analytics-front.png'),PageBreak(),
       Spacer(1,56),Paragraph('Practical Data Analysis<br/>for Engineering Decisions',S['title']),
       Paragraph('Puma',S['subtitle']),
       Spacer(1,18),Paragraph('Expanded edition',S['subtitle']),
       Paragraph('A practical path from engineering traces<br/>to mathematical analysis',S['body']),
       Spacer(1,48),Paragraph('Scheduler traces · Agent evaluation · Research data<br/>Vectors and matrices · Images · GIS<br/>Finance · Optimization · Uncertainty',S['small']),
       Spacer(1,45),Paragraph('2 October 2026',S['small']),
       Paragraph('18 chapters, 16 original figures, and a reproducible companion',S['small']),PageBreak(),
       Paragraph('Contents',S['h1'])]
toc=TableOfContents();toc.levelStyles=[S['toc']];toc.dotsMinLevel=0
story.extend([toc,Spacer(1,20),Paragraph('The editable manuscript and reproducible companion accompany this book. All scheduler measurements come from a pinned synthetic simulation; other generated examples are labeled explicitly.',S['small']),PageBreak()])
for i,p in enumerate(chapters):
    if i:story.append(PageBreak())
    story.extend(parse(p.read_text(),first=i==0,compact=p.name.startswith('16_')))
story.append(PageBreak());story.extend(parse(refs,reference=True))
story.extend([PageBreak(),FullPageCover(ROOT/'covers/analytics-back.png')])
doc.multiBuild(story)
(ROOT/'qa/heading_pages.json').write_text(json.dumps(doc.heading_pages,indent=2)+'\n')
(ROOT/'qa/figure_pages.json').write_text(json.dumps(doc.figure_pages,indent=2)+'\n')
print('Wrote',pdf)
print('Words',len(md.split()))
