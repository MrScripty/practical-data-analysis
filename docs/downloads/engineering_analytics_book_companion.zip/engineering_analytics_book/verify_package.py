#!/usr/bin/env python3
"""Verify the distributed bundle before regenerating any outputs."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'package_manifest.json').read_text())
for row in manifest['files']:
    raw=(root/row['path']).read_bytes()
    if len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
        raise SystemExit('FAIL: '+row['path'])
print('PASS:',len(manifest['files']),'package files match the distributed manifest')
