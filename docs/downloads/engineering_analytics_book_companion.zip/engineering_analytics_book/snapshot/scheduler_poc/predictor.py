"""Small conditional empirical predictor. All calibration is synthetic.

Ratios correct phase-specific physical priors. Sparse cells shrink to compatible
host/device/phase parents. Samples expire by version and rolling window. The
empirical tail is a risk heuristic, not a conditional coverage guarantee.
"""
from __future__ import annotations
from collections import defaultdict, deque
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class Prediction:
    mean: float
    upper: float
    n: int
    support: str
    drift: bool


class Predictor:
    def __init__(self) -> None:
        self.cells: dict[tuple, deque] = defaultdict(lambda: deque(maxlen=24))
        self.parents: dict[tuple, deque] = defaultdict(lambda: deque(maxlen=48))
        self.drift_count = 0
        self.observations = 0
        self.censored = 0
        self.coverage: list[bool] = []
        self.versions: dict[str, int] = defaultdict(int)

    def key(self, host: str, device: str, model: str, phase: str,
            work: float, context: str) -> tuple:
        shape = "small" if work <= 5 else "medium" if work <= 20 else "large"
        return host, self.versions.get(host, 0), device, model, phase, shape, context

    @staticmethod
    def parent(key: tuple) -> tuple:
        return key[0], key[1], key[2], key[4], key[6]

    def predict(self, key: tuple, prior: float) -> Prediction:
        local = list(self.cells.get(key, ()))
        parent = list(self.parents.get(self.parent(key), ()))
        source = local if len(local) >= 4 else local + parent[-8:]
        ratios = [x[1] for x in source]
        # New configurations retain a broad, explicitly uncalibrated uncertainty.
        mean_ratio = (sum(ratios) + 3.0) / (len(ratios) + 3)
        spread = math.sqrt(sum((x - mean_ratio) ** 2 for x in ratios) / max(1, len(ratios)))
        upper_ratio = max(mean_ratio * (1.35 if len(local) < 4 else 1.1),
                          mean_ratio + 1.7 * spread)
        drift = len(local) >= 4 and abs(sum(x[1] for x in local[-3:]) / 3 - mean_ratio) > .3 * mean_ratio
        return Prediction(max(.001, prior * mean_ratio), max(.001, prior * upper_ratio),
                          len(local), "exact" if len(local) >= 4 else "shrinkage" if ratios else "prior", drift)

    def observe(self, key: tuple, prior: float, duration: float, now: float,
                censored: bool = False) -> None:
        if censored:
            self.censored += 1
            return
        predicted = self.predict(key, prior)
        self.coverage.append(duration <= predicted.upper)
        ratio = duration / max(.001, prior)
        cell = self.cells[key]
        if len(cell) >= 4:
            old = sum(x[1] for x in cell) / len(cell)
            if ratio > old * 1.65 or ratio < old / 1.65:
                # A simple change alarm and forgetting; not a conformal guarantee.
                self.drift_count += 1
                while len(cell) > 3:
                    cell.popleft()
        cell.append((now, ratio))
        self.parents[self.parent(key)].append((now, ratio))
        self.observations += 1

    def invalidate(self, host: str) -> None:
        self.versions[host] += 1

    def residual(self, key: tuple, prior: float, elapsed: float) -> float:
        durations = [prior * ratio for _, ratio in self.cells.get(key, ())]
        survivors = [x - elapsed for x in durations if x > elapsed]
        if survivors:
            return sum(survivors) / len(survivors)
        # Outside support, do not claim zero remaining duration.
        p = self.predict(key, prior)
        return max(.1, p.mean * .3, p.upper - elapsed)
