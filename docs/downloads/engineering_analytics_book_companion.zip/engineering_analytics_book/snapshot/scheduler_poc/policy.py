"""Bounded joint-action search with nonanticipating fixed-policy continuations.

This is a deliberately small specialization of thesis sections 6–7: beam depth
bounds the FIRST bundle; continuation is warm/oldest, not a multi-stage beam.
All candidates use the same visible nodes, weights, and common timing factors.
"""
from __future__ import annotations
import copy
import math
from dataclasses import asdict
from itertools import combinations
from typing import TYPE_CHECKING
from .domain import Action, Plan, EPS
from .admission import prepare, individually_feasible
if TYPE_CHECKING:
    from .engine import Engine


def modes(engine: Engine, task_id: str) -> list[Action]:
    task = engine.tasks[task_id]
    out = []
    for host in engine.hosts.values():
        if not engine.connected[host.id] or (task.hosts and host.id not in task.hosts):
            continue
        for device in task.devices:
            if device in host.devices:
                out.append(Action("start", host.id, device, task_id))
    return out


def estimated_cost(engine: Engine, action: Action) -> float:
    task = engine.tasks[action.task]
    host = engine.hosts[action.host]
    cold = (host.id, action.device, task.model) not in engine.replicas
    result = engine.predict_duration(task, host, action.device, "compute")
    if cold:
        result += engine.predict_duration(task, host, action.device, "load")
    if host.remote:
        if task.input_gib:
            result += engine.predict_duration(task, host, action.device, "transfer_in")
        if task.output_gib:
            result += engine.predict_duration(task, host, action.device, "transfer_out")
    return result


def feasible(engine: Engine, actions: tuple[Action, ...]) -> bool:
    return prepare(engine, engine.plan(actions))[1] == "ok"


def eviction_for(engine: Engine, target: str) -> list[Action]:
    """Choose a placement whose workspace demonstrably fits after legal eviction.

    A fast replica is not necessarily a usable replica. Check each target mode
    against all unremovable live leases, preserving only its exact instance.
    Evictions remain separate acknowledged actions; hypothetical releases never
    authorize loading in the real ledger.
    """
    task = engine.tasks[target]
    options = []
    for action in modes(engine, target):
        if feasible(engine, (action,)):
            # This mode needs no eviction, but another (faster) mode may still
            # merit a cold replacement. Do not erase that counterfactual.
            continue
        keep = action.host, action.device, task.model
        remove = [key for key, rep in engine.replicas.items()
                  if key[0] == action.host and key != keep and rep.state == "ready" and not rep.pins]
        if not remove:
            continue
        trial = copy.deepcopy(engine)
        for key in remove:
            del trial.replicas[key]
            trial.ledger.leases.pop("model:" + ":".join(key))
        if feasible(trial, (action,)):
            moves = [Action("evict", key[0], key[1], model=key[2]) for key in sorted(remove)]
            cost = estimated_cost(engine, action) + sum(engine.models[k[2]].unload_s for k in remove)
            options.append((cost, tuple(a.key() for a in moves), moves))
    return min(options, key=lambda item: (item[0],item[1]))[2] if options else []


def baseline(engine: Engine, warm: bool = False, target: str | None = None) -> Plan:
    ready = [target] if target else engine.ready()
    ready.sort(key=lambda t: (-engine.boost(engine.tasks[t]) if engine.config.baseline_boosts else 0, engine.ready_since.get(t, 0), engine.tasks[t].arrival, t))
    options = [a for t in ready for a in modes(engine, t)]
    if warm:
        order = {t: i for i, t in enumerate(ready)}
        options.sort(key=lambda a: ((a.host, a.device, engine.tasks[a.task].model) not in engine.replicas,
                                    order[a.task], estimated_cost(engine, a)))
    else:
        order = {t: i for i, t in enumerate(ready)}
        options.sort(key=lambda a: (order[a.task], estimated_cost(engine, a)))
    chosen: tuple[Action, ...] = ()
    for action in options:
        if any(a.task == action.task for a in chosen):
            continue
        if feasible(engine, chosen + (action,)):
            chosen += (action,)
        if target and chosen:
            break
    if chosen:
        return engine.plan(chosen)
    # Drain before a cold protected start: deliberately stop ALL new starts.
    # More conservative than the thesis's optional nonconflicting continuation.
    for task in ready:
        if not individually_feasible(engine, task):
            continue
        evictions = eviction_for(engine, task)
        if evictions:
            return engine.plan(tuple(evictions))
        if target:
            break
    return engine.plan()


def shortlist(engine: Engine) -> list[str]:
    ready = engine.ready()
    by_age = sorted(ready, key=lambda t: (engine.ready_since[t], t))
    chosen = []
    seen_apps = set()
    for task in by_age:
        app = engine.tasks[task].app
        if app not in seen_apps:
            chosen.append(task)
            seen_apps.add(app)
    by_value = sorted(ready, key=lambda t: (-engine.weight(engine.tasks[t]), engine.ready_since[t], t))
    for task in by_value:
        if task not in chosen:
            chosen.append(task)
    return chosen[:engine.config.shortlist]


def seeds(engine: Engine) -> list[Plan]:
    ready = shortlist(engine)
    singles = [a for task in ready for a in modes(engine, task) if feasible(engine, (a,))]
    # Bound mode expansion as well as ready nodes.
    singles.sort(key=lambda a: (-engine.weight(engine.tasks[a.task]) / max(.1, estimated_cost(engine, a)), a.key()))
    singles = singles[:max(engine.config.beam_width * 2, 4)]
    plans: list[Plan] = [engine.plan()]
    beam: list[tuple[Action, ...]] = [(a,) for a in singles]
    plans += [engine.plan(a) for a in beam]
    for _ in range(1, engine.config.bundle_depth):
        expanded = set()
        for bundle in beam:
            for action in singles:
                if action in bundle:
                    continue
                candidate = tuple(sorted(bundle + (action,), key=lambda a: a.key()))
                if feasible(engine, candidate):
                    expanded.add(candidate)
        beam = sorted(expanded, key=lambda actions: (-sum(engine.weight(engine.tasks[a.task]) /
                max(.1, estimated_cost(engine, a)) for a in actions), tuple(a.key() for a in actions)))[:engine.config.beam_width]
        plans += [engine.plan(a) for a in beam]
    for task in ready:
        evictions = eviction_for(engine, task)
        if evictions and any((a.host, a.device, engine.tasks[task].model) not in engine.replicas for a in modes(engine, task)):
            plans.append(engine.plan(tuple(evictions)))
    for hint in sorted(engine.hints, key=lambda h: (h.need_at, h.id))[:8]:
        if hint.issued_at > engine.now or hint.expires <= engine.now or hint.confidence < .5:
            continue
        if hint.generation != engine.hint_generation.get(hint.id, hint.generation):
            continue
        if hint.host not in engine.hosts or hint.model not in engine.models:
            continue
        host = engine.hosts[hint.host]
        load = .3 + engine.models[hint.model].weights / host.storage_gib_s
        # Explicit frozen-time approximation; NOT a calibrated need/setup quantile.
        if engine.now < hint.need_at - 1.35 * load or engine.now > hint.need_at:
            continue
        action = Action("preload", hint.host, hint.device, hint.id, hint.model)
        if feasible(engine, (action,)):
            plans.append(engine.plan((action,)))
    unique = {tuple(a.key() for a in p.actions): p for p in plans}
    return list(unique.values())


def cvar(losses: list[float], alpha: float) -> float:
    """Exact empirical CVaR via the variational definition, including fractional tail mass."""
    return min(z + sum(max(0, loss-z) for loss in losses) / ((1-alpha)*len(losses))
               for z in losses)


def score(engine: Engine, plan: Plan, universe: list[str], weights: dict[str, float]) -> tuple[float, dict]:
    cfg = engine.config
    H = cfg.horizon_s
    scores, losses = [], []
    transition_cost = 0.0
    for action in plan.actions:
        if action.kind == "evict":
            # Charge discarded residency as a reload-risk surrogate.
            transition_cost += .5 * cfg.transition_cost * engine.models[action.model].weights
        elif action.kind == "preload":
            transition_cost += cfg.transition_cost * engine.models[action.model].weights
        elif (action.host, action.device, engine.tasks[action.task].model) not in engine.replicas:
            transition_cost += cfg.transition_cost * engine.models[engine.tasks[action.task].model].weights
    initial_progress = {t: max((a.compute_fraction for a in engine.attempts.values() if a.task == t and
                               a.generation == engine.generations[t]), default=0) for t in universe}
    for index in range(cfg.scenarios):
        # Common latent speed conditions; no candidate-specific random draw.
        factor = 1.0 if cfg.scenarios == 1 else .85 + .3 * index / (cfg.scenarios - 1)
        trial = copy.deepcopy(engine)
        trial.rollout = True
        trial.rollout_factor = factor
        trial.rollout_visible = set(universe)
        trial.host_generation = dict(trial.offer_generation)
        trial.reject_once.clear()
        trial.fail_next.clear()
        trial.trace = []
        trial.events = [e for e in trial.events if e[2] == "release_output"]
        trial.schedule(trial.now + cfg.periodic_s, "tick", {})
        trial.protected = trial.protected_inflight = None
        # Replace hidden actual remaining durations with conditional estimates.
        for attempt in trial.attempts.values():
            attempt.fail_load = False
            task = trial.tasks[attempt.task]
            elapsed = trial.now - attempt.phase_started
            key = trial.predictor.key(attempt.host, attempt.device, task.model, attempt.phase,
                                      task.work, attempt.phase_context)
            wall_remaining = trial.predictor.residual(key, attempt.phase_prior, elapsed) * factor
            # Empirical residuals are wall seconds; the engine integrates nominal
            # phase work and applies interference separately on every interval.
            remaining = wall_remaining / trial.slowdown(attempt)
            attempt.remaining = remaining
            fraction_left = max(.001, 1-attempt.compute_fraction) if attempt.phase == "compute" else 1
            attempt.base_total = remaining / fraction_left
        for transition in trial.transitions.values():
            transition.remaining = max(.1, transition.prior * factor - (trial.now-transition.started))
        if not trial.commit(plan):
            return -math.inf, {"invalid": True}
        # Later decisions see only newly observed events, with fixed warm/oldest policy.
        trial.run(until=engine.now + H, max_events=cfg.rollout_events, dispatch_first=False)
        if trial.now < engine.now + H - EPS and not all(trial.status[t] in ("done","failed","cancelled","blocked") for t in universe):
            return -math.inf, {"truncated": True, "reached_s":trial.now-engine.now, "horizon_s":H}
        progress = delay = late = 0.0
        for task_id in universe:
            task = engine.tasks[task_id]
            finish = trial.finished.get(task_id, math.inf)
            current = max((a.compute_fraction for a in trial.attempts.values() if a.task == task_id and
                           a.generation == trial.generations[task_id]), default=0)
            fraction = 1 if finish <= engine.now+H else current
            fraction = max(0, min(1, fraction) - initial_progress[task_id])
            progress += weights[task_id] * fraction
            delay += weights[task_id] * min(H, max(0, finish-engine.now)) / H
            if task.deadline is not None:
                late += min(1, max(0, finish-task.deadline) / H) if math.isfinite(finish) else 1
        hint_value = 0.0
        for hint in engine.hints[:8]:
            if (hint.issued_at <= engine.now < hint.expires and hint.confidence >= .5
                and hint.generation == engine.hint_generation.get(hint.id, hint.generation)
                and not any(engine.tasks[t].model == hint.model for t in universe)):
                key = hint.host, hint.device, hint.model
                rep = trial.replicas.get(key)
                if rep and rep.state == "ready":
                    hint_value += cfg.hint_weight * min(hint.count, 3) * hint.confidence
        early = 0.0
        for action in plan.actions:
            if action.kind == "preload":
                hint = next(h for h in engine.hints if h.id == action.task)
                early += cfg.early_residency_cost * engine.models[hint.model].weights * max(0, hint.need_at-engine.now)
        rollout_cost = cfg.transition_cost * max(0, trial.stats.get("loaded_gib", 0) - engine.stats.get("loaded_gib", 0))
        eviction_cost = sum(.5 * cfg.transition_cost * engine.models[a.model].weights for a in plan.actions if a.kind == "evict")
        scores.append(progress - cfg.delay_weight*delay - rollout_cost - eviction_cost + hint_value - early)
        losses.append(late)
    result = sum(scores)/len(scores) - cfg.risk_weight*cvar(losses, cfg.cvar_alpha)
    return result, {"mean_shaped_value": sum(scores)/len(scores), "tail_loss": cvar(losses, cfg.cvar_alpha),
                    "transition_cost": transition_cost, "scenarios": cfg.scenarios}


def choose(engine: Engine) -> Plan:
    if engine.rollout:
        return baseline(engine, warm=True)
    if engine.config.policy != "proposed" and engine.config.fair_baselines:
        protected = engine.protected_target()
        if protected:
            return baseline(engine, target=protected)
    if engine.config.policy == "fifo":
        return baseline(engine)
    if engine.config.policy == "residency":
        return baseline(engine, warm=True)
    if engine.config.policy != "proposed":
        raise ValueError(f"Unknown policy {engine.config.policy}")
    target = engine.protected_target()
    if target:
        plan = baseline(engine, target=target)
        engine.log("protected_decision", task=target, actions=[asdict(a) for a in plan.actions])
        return plan
    plans = seeds(engine)
    universe = sorted(set(engine.ready()) | {a.task for a in engine.attempts.values()
                    if a.generation == engine.generations[a.task]})
    weights = {t: engine.weight(engine.tasks[t]) for t in universe}
    ranked = []
    for plan in plans:
        value, detail = score(engine, plan, universe, weights)
        ranked.append((value, plan, detail))
    # Conservative tie-break: less moving data, then fewer actions, then stable identity.
    ranked.sort(key=lambda item: (-round(item[0], 8), item[2].get("transition_cost", 0),
                                 len(item[1].actions), tuple(a.key() for a in item[1].actions)))
    selected = ranked[0]
    if not math.isfinite(selected[0]):
        fallback = baseline(engine, warm=False)
        engine.log("planner_fallback", reason="no_complete_valid_rollout", candidates=len(ranked),
                   actions=[asdict(a) for a in fallback.actions])
        return fallback
    engine.log("decision", selected=[asdict(a) for a in selected[1].actions], score=selected[0],
               universe=universe, weights=weights, candidates=[{"score": round(v, 6) if math.isfinite(v) else None,
               "actions": [asdict(a) for a in p.actions], **d} for v, p, d in ranked])
    return selected[1]
