# Why the scheduler loses and what the revision establishes

## Conclusion

The prototype is an audited implementation of selected scheduling mechanisms. It
is not yet a generally superior scheduling algorithm. Some losses are explained
by a specific implementation omission or the finite-horizon score; other
end-to-end differences still need research. Safety tests passing and work
finishing do not prove that the chosen schedule was a good one.

All times below come from declared synthetic simulation. Nothing was measured on
real Pantograph hardware. Original evaluation seeds were 7, 19 and 41. The
follow-up controls use previously unexamined seeds 59, 83 and 101 without retuning
the default coefficients to those outcomes.

## A concrete losing run

In the randomized seed-7 workload, FIFO and residency-greedy both finish in
45.694653 s. The proposed policy takes 56.642415 s: 10.947762 s later, or 24.0%
longer. Turning its protected-service mechanism off produces 56.665930 s. Thus
this loss cannot be dismissed as the necessary cost of fairness.

The final task, random7, becomes ready at 40.495955 s under the proposed policy.
It uses the vision model and has 16.093210 normalized work units. The CPU retains
that model, while the GPU retains other models. The proposal starts the warm CPU
and finishes at 56.642415 s. Earlier ready-node decisions also differ from FIFO;
FIFO makes this task ready at 38.34 s (rounded) and uses a GPU load and execution.

### Defect found and repaired

The eviction candidate helper returned immediately when *any* mode already fit.
That meant a feasible warm CPU could hide a faster cold GPU replacement. The
repair keeps considering other modes and adds a known-cost regression: with a
slow warm CPU and an obstructed fast GPU, the GPU eviction candidate must exist
and win in the simple fixture. This fixes a candidate-coverage bug specified by
the paper's existing replacement/replica contract; it does not require changing
the paper's mathematical claim.

Importantly, the repaired seed-7 schedule still takes 56.642415 s. The report
preserves that failed-to-improve outcome rather than attributing a nonexistent
speedup to the repair.

### Why the repaired score still chooses the CPU

At the final decision, the new trace explicitly includes both alternatives:

| Candidate | Shaped score | Observed result when executed |
|---|---:|---|
| Start the warm CPU now | 0.712417 | Batch finishes at 56.642415 s |
| Evict idle replicas and prepare the GPU | 0.597209 | Forced diagnostic finishes at 47.038627 s |

The score charges model load/eviction bytes and gives nearly full service credit
to CPU work that runs close to or beyond the 16-second horizon. The delay term is
only 0.25 times normalized delay. Under those coefficients, earlier completion
does not compensate for the setup penalties. This is a demonstrated mismatch
between the shaped ranking objective and batch completion in this state, not an
allocation failure or an unexplained random fluctuation.

A one-time forced-GPU intervention reduces this run by 9.603788 s while obeying
the same physical ledger. It is a diagnostic intervention, **not a new general
policy or an exact oracle**. It still finishes 1.343974 s later than FIFO because
the earlier schedules differed. That residual difference has not been isolated
to a single cause. The experiment script and full before/after/intervention
traces are included.

## Controls on new seeds

The first comparison used unprotected FIFO/residency and the protected proposed
policy. It also gave discretionary speed-weight handling only to the proposed
policy. Those rows are valid end-to-end configurations, but they do not isolate
the value of search or the cost of protection.

The follow-up uses the same eight-second protected-turn rule and the same
expiring app/workflow boost inputs for every policy. Baselines retain their own
ranking rules: FIFO orders by boost then age; residency-greedy still prefers warm
placements, using boost/age within that ordering. This matches the service
contract and available information, not the exact realized dispatch sequence.
It remains weaker than a complete suite of modern fair/earliest-finish baselines.

Mean completion in seconds across held-out seeds 59, 83 and 101:

| Matched service workload | FIFO | Residency greedy | Proposed |
|---|---:|---:|---:|
| Randomized | 47.35 | 40.34 | 47.08 |
| Priority and warm arrival stress | 54.17 | 54.17 | 54.17 |
| Severe contention | 40.90 | 40.90 | 34.76 |
| Lookahead pipeline | 14.64 | 14.64 | 12.82 |

The randomized policy is approximately tied with FIFO but remains 16.7% slower
than residency-greedy. Contention and lookahead benefits persist with matched
service controls. The earlier 5.3% priority-case regression against unprotected
baselines must not be labeled a pure fairness penalty: matched policies tie on
the new seeds, and removing protection from the proposed policy does not improve
every outcome. The correct classification is a policy-configuration comparison,
with the separate mechanisms still needing controlled attribution.

## One objective ablation rather than a silent retune

A predeclared diagnostic changes only delay_weight from 0.25 to 1.0 on the held-out
seeds. Other coefficients, search bounds and matched service controls stay fixed.
It is not substituted as the default after seeing these results.

| Workload | Default proposed | More completion-delay weight |
|---|---:|---:|
| Randomized | 47.08 | 43.41 |
| Priority stress | 54.17 | 54.17 |
| Contention | 34.76 | 34.78 |
| Lookahead | 12.82 | 12.82 |

This supports further work on the objective: the randomized mean improves, but
43.41 s still loses to the 40.34 s residency baseline. Twelve follow-up runs are
not enough to validate a new general default. Horizon sensitivity is also
material: the separate single-seed sweep includes a contention regression at a
32-second horizon and large changes on the randomized case.

## Classification and next test

| Finding | Classification | Evidence and next test |
|---|---|---|
| Missing cold GPU replacement | Implementation bug, repaired | Known-cost regression and before/after candidate trace; keep regression across capability variants |
| Warm CPU beats earlier-finishing GPU in the shaped score | Verified objective mismatch, not resolved by the candidate repair | Candidate scores plus forced physical execution; compare completion-oriented profiles on broader held-out streams |
| Remaining randomized aggregate loss | Partly explained, not fully isolated | Protection-off and matched-service controls rule out a blanket fairness excuse; add stronger fair warm/earliest-finish baselines and continuation ablations |
| Earlier priority-case increase | Confounded policy comparison | Matched service ties on new seeds; separately vary boosts, protection, and discretionary ranking |
| Safety and lifecycle defects found in review | Repaired represented-simulator defects | Independent counterexamples and rerun regressions; production adapters still need real validation |

The bounded next research step is to compare objective profiles and better
continuations under fixed memory envelopes, fixed service obligations, and new
arrival/model-popularity seeds. Report throughput, workflow completion, tail
latency, background wait, reloads and planning cost together. Select a numerical
user-facing objective first; do not call arbitrary byte-cost savings a throughput
win when useful completion is slower. Only then test observed runtime traces in
shadow mode. No whole-graph optimality or universal speedup is warranted.

## Reproduction artifacts

- reports/before_candidate_fix_evaluation.json: original 117-run comparison
- reports/before_candidate_fix_diagnosis.json: original seed-7 protected/unprotected diagnostic
- reports/before_candidate_fix_code-sha256.txt: original executable fingerprint
- reports/evaluation.json: rerun after the candidate repair
- reports/loss_diagnosis.json: reproducible legacy omission, repaired default, no-protection and forced-GPU intervention
- reports/holdout_matched_evaluation.json: 72 matched/unprotected follow-up runs
- reports/objective_ablation.json: 12 single-parameter follow-up runs
- traces/diagnosis_*.jsonl: directly corresponding detailed traces
- experiments/reproduce_loss_diagnosis.py: reproduces the legacy omission locally for comparison and labels its intervention
- run_holdout_comparison.py and run_objective_ablation.py: unchanged-parameter follow-up scripts

The legacy omission is reproduced by a narrowly labeled, in-memory experiment
wrapper. It is not an option in the shipped production policy. Result files and
traces carry complete policy parameters; the final package manifest hashes all
included files. Wall-clock planner timings can vary with the machine and load.
