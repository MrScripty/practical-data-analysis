# Sources for spatial and financial analysis

Sources were checked on 2 October 2026. They support the stated methods and cautions; all chapter calculations, datasets, and diagrams are original synthetic teaching material. These sources do not establish a present Nearwork implementation or any current market investment opportunity.

## G01 Projections

GeoPandas developers. [Projections](https://docs.geopandas.org/en/stable/docs/user_guide/projections.html).

Used in Chapter 16: CRS metadata, declaring versus transforming coordinates, and GeoPandas longitude/latitude order. Does not establish the accuracy of any particular local projection.

Verification: Full documentation page inspected; stable URL resolved to current development-labelled documentation on access date.

## G02 Geodesic calculations

PROJ contributors. [Geodesic calculations](https://proj.org/en/stable/geodesic.html).

Used in Chapter 16: Distinguishing ellipsoidal geodesics from the chapter’s explicitly spherical approximation. No claim that the synthetic sphere is survey grade.

Verification: Full documentation page inspected.

## G03 Merging data

GeoPandas developers. [Merging data](https://geopandas.org/en/stable/docs/user_guide/mergingdata.html).

Used in Chapter 16: Attribute versus spatial joins, geometric predicates, one-to-many matches and nearest-join options. Rectangle half-open assignment is an original teaching convention.

Verification: Full documentation page inspected.

## G04 Geotransform tutorial

GDAL contributors. [Geotransform tutorial](https://gdal.org/en/stable/tutorials/geotransforms_tut.html).

Used in Chapter 16: Six affine coefficients, top-left corner coordinates, north-up negative pixel height and half-cell center offset. Zonal overlap example independently derived.

Verification: Full documentation page inspected.

## G05 GDAL Grid tutorial

GDAL contributors. [GDAL Grid tutorial](https://gdal.org/en/stable/tutorials/gdal_grid_tut.html).

Used in Chapter 16: Inverse distance to a power interpolation and neighborhood parameters. Chapter fixture uses all points, p=2, zero smoothing; measurement-only variance is separately derived.

Verification: Full documentation page inspected.

## G06 How Kriging works

Esri. [How Kriging works](https://doc.esri.com/en/arcgis-pro/latest/tool-reference/spatial-analyst/how-kriging-works.html).

Used in Chapter 16: Kriging relies on a modeled spatial relationship; prediction error is conditional on model assumptions. No kriging implementation or empirical calibration is claimed.

Verification: Full current page inspected after redirect from pro.arcgis.com.

## G07 Cross-validation strategies for data with temporal spatial hierarchical or phylogenetic structure

David R. Roberts and colleagues. [Cross-validation strategies for data with temporal spatial hierarchical or phylogenetic structure](https://nsojournals.onlinelibrary.wiley.com/doi/10.1111/ecog.02881).

Used in Chapter 16: Structured validation must reflect interpolation versus transfer to new space; dependence can make random validation misleading. Not a universal endorsement of every blocking design.

Verification: Full publisher article and abstract inspected; Ecography 40 (2017), 913–929; DOI 10.1111/ecog.02881.

## G08 Global Spatial Autocorrelation with Moran’s I

PySAL esda contributors. [Global Spatial Autocorrelation with Moran’s I](https://pysal.org/esda/stable/user-guide/global_morans_i.html).

Used in Chapter 16: Moran statistic, spatial lag and random-label permutation reference. Chapter explicitly fixes locations and weights and defines its own right tail; it does not assert generic point-process CSR or reproduce software default p-value semantics.

Verification: Full methodological sections inspected; finite randomization mean and plus-one formula checked against exhaustive original fixture.

## G09 Local Spatial Autocorrelation 1

Luc Anselin and GeoDa Center. [Local Spatial Autocorrelation 1](https://geodacenter.github.io/workbook/6a_local_auto/lab6a.html).

Used in Chapter 16: Local quadrant membership differs from significance; local tests raise multiplicity and permutation-resolution issues. Chapter implements descriptive local values only.

Verification: Local interpretation and multiple-comparison sections inspected.

## G10 Choropleth Map Design for Cancer Incidence Part 2

Thomas B. Richards and colleagues CDC Preventing Chronic Disease. [Choropleth Map Design for Cancer Incidence Part 2](https://www.cdc.gov/pcd/issues/2010/jan/09_0073.htm).

Used in Chapter 16: Warnings about ecological inference, small denominators and geographic pattern interpretation. Chapter has no disease analysis and its four-person numerical counterexample is original.

Verification: Full page inspected; Preventing Chronic Disease 7(1):A24, January 2010, article identifier 09_0073.

## F01 Present Value Relations Slides 1–36

Andrew W. Lo MIT OpenCourseWare. [Present Value Relations Slides 1–36](https://ocw.mit.edu/courses/15-401-finance-theory-i-fall-2008/resources/mit15_401f08_lec02/).

Used in Chapter 17: Present value, compounding and real/nominal consistency. All project cash flows, break-even numbers and IRR counterexample are original calculations; no recommended discount rate.

Verification: Resource page and linked 37-page PDF inspected.

## F02 Portfolio Theory Slides 1–46

Andrew W. Lo MIT OpenCourseWare. [Portfolio Theory Slides 1–46](https://ocw.mit.edu/courses/15-401-finance-theory-i-fall-2008/resources/mit15_401f08_lec13/).

Used in Chapter 17: Weighted portfolio returns and the role of covariance in mean-variance analysis. Matrices and return observations are synthetic, not estimates for named assets.

Verification: Resource page and linked 47-page PDF inspected.

## F03 Foundations of Portfolio Theory

Harry M. Markowitz. [Foundations of Portfolio Theory](https://onlinelibrary.wiley.com/doi/10.1111/j.1540-6261.1991.tb02669.x).

Used in Chapter 17: Historical foundation and conditional role of mean-variance portfolio criteria. Does not supply the chapter’s numerical portfolio or current market claims.

Verification: Publisher bibliographic page verified. Nobel Foundation indexed lecture excerpts inspected, including discussion of adequacy of mean/variance; direct Nobel PDF retrieval failed. Journal of Finance 46 (1991), 469–477; 1990 lecture.

## F04 The Statistics of Sharpe Ratios

Andrew W. Lo. [The Statistics of Sharpe Ratios](https://alo.mit.edu/publications/page/18/).

Used in Chapter 17: Sharpe estimates have sampling error; simple annualization is not generally valid under serial correlation. The additive-sum variance identity is derived independently in the chapter.

Verification: Author-hosted abstract inspected. Financial Analysts Journal 58(4), 2002, 36–52; DOI 10.2469/faj.v58.n4.2453.

## F05 On the coherence of Expected Shortfall

Carlo Acerbi and Dirk Tasche. [On the coherence of Expected Shortfall](https://arxiv.org/abs/cond-mat/0104295).

Used in Chapter 17: Expected shortfall definitions need care for discontinuous distributions; precise tail probability mass. Chapter uses upper-tail loss confidence alpha, which must not be confused with an author’s lower-tail probability convention.

Verification: Author-submitted abstract and HTML full text inspected; revision v5 May 2002; Journal of Banking and Finance 26, 1487–1503. HTML https://arxiv.org/html/cond-mat/0104295v5.

## F06 How Fees and Expenses Affect Your Investment Portfolio

US Securities and Exchange Commission Office of Investor Education and Assistance. [How Fees and Expenses Affect Your Investment Portfolio](https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins/updated).

Used in Chapter 17: Fees reduce returns and the capital left to compound. Does not justify the toy 0.001 transaction cost as realistic or current.

Verification: Official July 23 2025 bulletin inspected; no rule interpretation or regulatory recommendation made.

## F07 The Probability of Backtest Overfitting

David H. Bailey Jonathan M. Borwein Marcos López de Prado and Qiji Jim Zhu. [The Probability of Backtest Overfitting](https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf).

Used in Chapter 17: Trying many alternatives creates selection risk even without a direct look-ahead bug; retain experiment history. Chapter does not implement CSCV or estimate a PBO.

Verification: Author-hosted February 2015 revised manuscript inspected; associated publication Journal of Computational Finance 20(4), 2017, 39–69.

## F08 The Delisting Bias in CRSP Data

Tyler Shumway. [The Delisting Bias in CRSP Data](https://doi.org/10.1111/j.1540-6261.1997.tb03818.x).

Used in Chapter 17: Historical research example of missing delisting outcomes. Supports auditing terminal observations, not a claim that current CRSP data still has the reported defect.

Verification: Publisher abstract and volume/issue inspected. Journal of Finance 52(1), 1997, 327–340; online page also displays later digital publication date.
