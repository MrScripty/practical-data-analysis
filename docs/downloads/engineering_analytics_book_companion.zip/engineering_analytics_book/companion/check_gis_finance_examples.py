#!/usr/bin/env python3
"""Deterministic hand answers, invariants, failure cases, and executable chapter snippets."""
from pathlib import Path
from itertools import permutations
import json
import re
import numpy as np
import gis_finance_examples as g

ROOT = Path(__file__).resolve().parents[1]
COUNT = 0

def check(condition, description):
    global COUNT
    if not condition:
        raise AssertionError(description)
    COUNT += 1

def close(actual, expected, description, atol=1e-10):
    check(np.allclose(actual,expected,rtol=1e-10,atol=atol),description)

def rejects(fn, description):
    try:
        fn()
    except ValueError:
        check(True,description)
    else:
        raise AssertionError('Did not reject: '+description)


def main():
    file = ROOT/'companion/derived/gis_finance_fixtures.json'
    if not file.exists():
        g.run()
    f = json.loads(file.read_text())
    # Coordinate order, scale, poles, antipodes, and antimeridian.
    close(g.haversine_km([0,0],[0,0]),0,'zero geodesic')
    close(g.haversine_km([0,0],[1,0]),6371.0088*np.pi/180,'equator arc')
    close(g.haversine_km([0,0],[180,0]),6371.0088*np.pi,'antipodal arc')
    close(g.haversine_km([179,0],[-179,0]),g.haversine_km([0,0],[2,0]),'antimeridian shortest arc')
    close(g.haversine_km([4,90],[100,90]),0,'same pole',atol=1e-9)
    check(55.59 < g.haversine_km([0,60],[1,60]) < 55.61,'high latitude longitude distance')
    close(g.haversine_km([15,40],[30,50]),g.haversine_km([30,50],[15,40]),'distance symmetry')
    rejects(lambda:g.haversine_km([0,91],[1,0]),'latitude range')
    rejects(lambda:g.haversine_km([np.nan,0],[1,0]),'nonfinite geodesic')
    rejects(lambda:g.haversine_km([0,0,0],[1,0]),'coordinate dimensionality')
    # All rectangle match cardinalities are explicit, including boundary C and G.
    p,b = f['geometry']['points_km'],f['geometry']['rectangles_km']
    close([len(a) for a in g.rectangle_join(p,b)],[1,1,1,1,1,1,0],'half-open cardinality')
    check(g.rectangle_join(p,b)==[[0],[0],[1],[1],[2],[3],[]],'half-open assignments')
    check(g.rectangle_join(p,b,'strict')==[[0],[0],[],[1],[2],[3],[]],'strict assignments')
    check(g.rectangle_join(p,b,'closed')==[[0],[0],[0,1],[1],[2],[3],[1]],'closed assignments')
    for mode in ['half_open','strict','closed']:
        check(g.rectangle_join(p,b,mode)==f['geometry']['joins'][mode],f'fixture join {mode}')
    rejects(lambda:g.rectangle_join([[0,0]],[[0,0,0,1]]),'degenerate rectangle')
    rejects(lambda:g.rectangle_join([[0,0]],b,'guess'),'unknown boundary rule')
    # Independently reconstruct each affine query from known pixel coordinates.
    raster=np.array([[10.,20.],[30.,40.]])
    gt=[0.,2.,0.,4.,0.,-2.]
    close(g.world_to_pixel([1,3],gt),[.5,.5],'cell center transform')
    rotated=[12.,2.,.3,20.,-.2,-3.]
    for pix in [[0,0],[.5,.5],[1.2,7.8],[-2,3]]:
        c,r=pix
        xy=[rotated[0]+rotated[1]*c+rotated[2]*r,rotated[3]+rotated[4]*c+rotated[5]*r]
        close(g.world_to_pixel(xy,rotated),pix,'rotated affine inverse')
    rejects(lambda:g.world_to_pixel([0,0],[0,1,2,0,2,4]),'singular affine')
    for xy,value in [([1,3],10),([3,3],20),([1,1],30),([3,1],40),([2,2],40)]:
        close(g.sample_cell(raster,xy,gt),value,'containing cell hand answer')
    check(np.isnan(g.sample_cell(raster,[4,2],gt)),'east edge excluded')
    check(np.isnan(g.sample_cell(raster,[0,0],gt)),'south edge excluded')
    close(g.sample_bilinear(raster,[2,2],gt),25,'bilinear central average')
    close(g.sample_bilinear(raster,[1,3],gt),10,'bilinear exact center')
    close(g.sample_bilinear(raster,[1.5,2.5],gt),17.5,'bilinear quarter weights')
    check(np.isnan(g.sample_bilinear(raster,[.5,2],gt)),'no bilinear extrapolation')
    missing=raster.copy();missing[0,0]=np.nan
    check(np.isnan(g.sample_bilinear(missing,[2,2],gt)),'positive-weight missing cell propagates')
    close(g.sample_bilinear(missing,[3,1],gt),40,'zero-weight missing does not propagate')
    close(g.fractional_zonal_mean(raster,gt,[0,1,3,4]),[20,1],'fractional zonal hand answer')
    close(g.fractional_zonal_mean(missing,gt,[0,1,3,4]),[28,5/9],'missing-area denominator and coverage')
    close(g.fractional_zonal_mean(raster,gt,[-2,0,4,4]),[25,2/3],'partial raster coverage')
    missing_mean,coverage=g.fractional_zonal_mean(raster,gt,[8,8,9,9])
    check(np.isnan(missing_mean) and coverage==0,'no overlap returns unknown mean')
    rejects(lambda:g.fractional_zonal_mean(raster,rotated,[0,1,3,4]),'rotated zonal operation explicitly unsupported')
    # IDW exact fixture, affine-equivariant response, and input validation.
    ip=np.array([[0.,0.],[2.,0.],[0.,2.]]);iz=np.array([10.,20.,30.]);q=[1.,0.]
    est,a=g.idw(ip,iz,q)
    close(est,180/11,'IDW hand answer')
    close(a,[5/11,5/11,1/11],'IDW normalized weights')
    close(a.sum(),1,'IDW partition of unity')
    close(g.idw(ip,iz,ip[0])[0],10,'IDW exact sample')
    close(g.idw(ip,[7,7,7],q)[0],7,'IDW constant field')
    close(g.idw(ip,3*iz+4,q)[0],3*est+4,'IDW response affine equivariance')
    close(g.idw(1000*ip,iz,np.array(q)*1000)[0],est,'IDW consistent distance units')
    close(a@np.diag([4,4,4])@a,204/121,'IDW measurement-only variance')
    rejects(lambda:g.idw([[0,0],[0,0]],[1,2],[1,0]),'duplicate IDW locations')
    rejects(lambda:g.idw(ip,iz,q,0),'zero IDW power')
    loo=[g.idw(np.delete(ip,i,0),np.delete(iz,i),ip[i])[0] for i in range(3)]
    close(loo,[25,50/3,40/3],'IDW leave-one-out hand answers')
    close(np.sqrt(np.mean((iz-loo)**2)),f['interpolation']['leave_one_out_rmse'],'IDW RMSE fixture')
    # All 24 permutations; no asymptotic distribution is used for the exact result.
    x=np.arange(1.,5.);w=g.chain_weights(4);z=x-x.mean()
    close(w.sum(1),np.ones(4),'spatial rows sum to one')
    check(not np.allclose(w,w.T),'row standardization can break symmetry')
    close(w@x,[2,2,3,3],'neighbor means')
    close(g.moran_i(x,w),.4,'Moran hand answer')
    exact=np.array([g.moran_i(v,w) for v in permutations(x)])
    close(exact,f['moran']['exact_null'],'all exact permutation values')
    close(exact.mean(),-1/3,'exact permutation mean')
    close(np.mean(exact>=.4-1e-12),1/12,'exact right tail')
    close(np.mean(z*(w@z)/np.mean(z*z)),g.moran_i(x,w),'local/global identity')
    complete=g.row_standardize(np.ones((4,4))-np.eye(4))
    for v in permutations(x):
        close(g.moran_i(v,complete),-1/3,'complete graph removes ordering information')
    for scale,shift in [(2,0),(-2,9),(.1,-5)]:
        close(g.moran_i(scale*x+shift,w),.4,'Moran affine attribute invariance')
    observed,mp,null=g.moran_permutation(x,w,999,1601)
    close(mp,.069,'seeded Monte Carlo right tail')
    close(mp,(1+np.count_nonzero(null>=observed-1e-12))/1000,'Monte Carlo rank formula')
    close(g.moran_permutation(x,w,999,1601)[2],null,'repeatable permutations')
    check(mp>=.001,'Monte Carlo p floor')
    rejects(lambda:g.moran_i([1,1,1,1],w),'constant Moran attribute')
    rejects(lambda:g.moran_i(x,np.eye(4)),'Moran self weights')
    rejects(lambda:g.row_standardize(np.zeros((4,4))),'islands need policy')
    rejects(lambda:g.moran_permutation(x,w,0),'positive permutation count')
    # Aggregation and ecological fallacy: hand slopes.
    cells=np.array([[1,1],[9,9]])
    close(cells.mean(1),[1,9],'row aggregation')
    close(cells.mean(0),[5,5],'column aggregation')
    for xx,yy in [([1,2],[4,3]),([3,4],[6,5])]:
        close((yy[1]-yy[0])/(xx[1]-xx[0]),-1,'within-zone slope')
    close((5.5-3.5)/(3.5-1.5),1,'between-zone slope')
    # Present value, timing, compounding, inflation, multiple IRRs.
    close(g.npv([100],.05),100,'immediate flow not discounted')
    close(g.npv([0,105],.05),100,'single-period present value')
    close(g.npv([-10000,4000,4000,4000],0),2000,'zero-rate accounting')
    close(g.npv([-10000,4000,4000,4000],.05),892.9921174819128,'project NPV hand answer')
    close(g.npv([110],.1,times=[1]),100,'explicit time')
    close(g.npv([121],.1,times=[2]),100,'two-period explicit time')
    check(g.npv([100],.05,[2])<g.npv([100],.05,[1]),'delaying benefit reduces PV')
    close(g.npv([-100,230,-132],.1),0,'first IRR root')
    close(g.npv([-100,230,-132],.2),0,'second IRR root')
    s=f['cashflow']['annual_savings_break_even_5pct']
    close(g.npv([-10000,s,s,s],.05),0,'break-even savings')
    close((1+.12/12)**12-1,.12682503013196977,'monthly compounding')
    close((1.05/1.02)-1,.02941176470588225,'real/nominal rate identity')
    rejects(lambda:g.npv([1],-1),'discount denominator zero')
    rejects(lambda:g.npv([1],.05,[-1]),'negative times unsupported')
    # NPV variance derived from independent and common annual savings errors.
    d=1/1.05**np.arange(1,4)
    independent=d@np.eye(3)@d
    common=d@np.ones((3,3))@d
    close(common,d.sum()**2,'common cash-flow error variance')
    check(common>independent,'correlated annual forecast error matters')
    # Wealth/log identities, total loss, and peak-relative drawdown.
    r=np.array([.10,-.10,.05,-.20,.25]);wealth=g.wealth_path(r)
    close(g.wealth_path([.1,-.1])[-1],99,'arithmetic mean is not growth')
    close(wealth,[100,110,99,103.95,83.16,103.95],'wealth path hand answer')
    close(np.expm1(np.log1p(r).sum()),.0395,'log/simple total return identity')
    close(r.mean(),.02,'arithmetic mean')
    close(np.expm1(np.log1p(r).mean()),.007778058819184472,'geometric mean')
    close(g.drawdown(wealth),[0,0,-.1,-.055,-.244,-.055],'drawdown hand answer')
    close(g.wealth_path(r[::-1])[-1],wealth[-1],'terminal compounding order invariance')
    check(not np.isclose(g.drawdown(g.wealth_path(np.sort(r))).min(),-.244),'drawdown changes with order')
    close(g.wealth_path([-1,.5]),[100,0,0],'total loss is absorbing without new capital')
    close(g.drawdown([100,0]),[0,-1],'total-loss drawdown')
    rejects(lambda:g.wealth_path([-1.01]),'loss below minus 100 percent')
    rejects(lambda:g.drawdown([0,1]),'zero initial wealth')
    # Covariance expression equals independent direct computation on observed columns.
    model=np.array([[.04,.01],[.01,.01]]);weights=np.array([.5,.5])
    close(g.portfolio_variance(weights,model),.0175,'model portfolio variance')
    close(np.sqrt(g.portfolio_variance(weights,model)),.13228756555322954,'model volatility')
    data=np.array([[.02,.01],[-.01,0],[.03,.02],[-.02,-.01]])
    cov=np.cov(data,rowvar=False,ddof=1)
    for a in [0.,.1,.25,.5,.75,1.]:
        weights=np.array([a,1-a])
        close(g.portfolio_variance(weights,cov),np.var(data@weights,ddof=1),'sample portfolio variance identity')
    rejects(lambda:g.portfolio_variance([.5,.5],[[1,.8],[.1,1]]),'asymmetric covariance')
    rejects(lambda:g.portfolio_variance([.5,.5],[[1,2],[2,1]]),'indefinite covariance')
    close(g.portfolio_variance([.5,.5],[[1,-1],[-1,1]]),0,'positive semidefinite singular covariance accepted')
    rejects(lambda:g.portfolio_variance([],np.zeros((0,0))),'empty portfolio')
    # Exact empirical tail mass, ties, invariances, and invalid probability.
    losses=[0,0,0,0,1,1,2,3,4,10]
    close(g.empirical_var_es(losses,.8),[3,7],'80 percent VaR and ES')
    close(g.empirical_var_es(losses,.85),[4,8],'fractional tail observation')
    close(g.empirical_var_es([1,1,1],.9),[1,1],'tied losses')
    close(g.empirical_var_es([1,2,3,4],.99),[4,4],'extreme empirical tail')
    close(g.empirical_var_es(np.array(losses)+3,.85),[7,11],'loss translation')
    close(g.empirical_var_es(np.array(losses)*2,.85),[8,16],'positive loss scaling')
    close(g.empirical_var_es([-3,-2,-1],.8),[-1,-1],'negative losses allowed')
    rejects(lambda:g.empirical_var_es(losses,1),'undefined empty tail')
    rejects(lambda:g.empirical_var_es([], .8),'empty loss distribution')
    # A row-by-row accounting and future-perturbation test of causal positions.
    r=np.array([.02,-.01,.03,-.02,.01,-.01]);signal=(r>0).astype(float)
    gross=g.causal_backtest(r,signal,0);net=g.causal_backtest(r,signal,.001)
    close(net['position'],[0,1,0,1,0,1],'one-period lag')
    close(net['turnover'],[0,1,1,1,1,1],'position-change accounting')
    close(g.wealth_path(signal*r)[-1],106.1106,'leaky counterexample')
    close(gross['terminal_wealth'],96.0498,'causal no-cost hand answer')
    close(net['total_one_way_trades'],6,'terminal liquidation counted')
    close(net['terminal_wealth'],96.0498*.999**6,'multiplicative fee hand answer')
    close(net['terminal_wealth'],95.47494002744416,'net terminal fixture')
    check(net['terminal_wealth']<gross['terminal_wealth'],'nonnegative costs reduce wealth')
    close(g.causal_backtest(r,signal,.001,False)['terminal_wealth']*.999,net['terminal_wealth'],'final sale fee')
    for cutoff in [1,2,3,4,5]:
        altered=r.copy();altered[cutoff:]=np.array([-.04,.02,-.03,.01,.04])[:len(r)-cutoff]
        result=g.causal_backtest(altered,(altered>0).astype(float),.001)
        close(result['position'][:cutoff+1],net['position'][:cutoff+1],'future changes cannot alter prior positions')
    close(g.causal_backtest(r,np.zeros(6),.001)['terminal_wealth'],100,'cash remains cash')
    rejects(lambda:g.causal_backtest(r,[1,1],.001),'unaligned signals')
    rejects(lambda:g.causal_backtest(r,np.ones(6)*.5,.001),'fractional positions unsupported')
    rejects(lambda:g.causal_backtest(r,signal,-.01),'negative fees rejected')
    # Conditional bootstrap is reproducible and respects support, not a market claim.
    series=np.array(f['bootstrap']['values'])
    for length in [1,3,6]:
        means=g.circular_block_means(series,length)
        close(np.quantile(means,[.025,.5,.975]),f['bootstrap']['block_length_mean_percentiles'][str(length)],'bootstrap fixture')
        check(means.min()>=series.min() and means.max()<=series.max(),'bootstrap mean support')
    close(g.circular_block_means(np.ones(12)*.03,3,20),np.ones(20)*.03,'constant bootstrap')
    close(g.circular_block_means(series,12,30),np.repeat(series.mean(),30),'full circular block mean')
    rejects(lambda:g.circular_block_means(series,0),'invalid block length')
    # Execute every Python block in the two chapters with an isolated namespace.
    chapters=sorted((ROOT/'chapters').glob('16_*.md'))+sorted((ROOT/'chapters').glob('17_*.md'))
    check(len(chapters)==2,'exactly two chapter files')
    snippet_count=0
    for chapter in chapters:
        for snippet in re.findall(r'```python\n(.*?)```',chapter.read_text(),flags=re.S):
            exec(compile(snippet,str(chapter),'exec'),{})
            snippet_count+=1
            check(True,f'chapter snippet {chapter.name}')
        for path in re.findall(r'!\[[^]]*\]\(([^)]+)\)',chapter.read_text()):
            check((ROOT/path).exists(),f'chapter figure exists {path}')
    check(snippet_count==6,'six runnable chapter snippets')
    for stem in ['13_geometry_and_raster_support','14_neighborhoods_and_randomization',
                 '15_cashflow_and_drawdown','16_portfolio_and_backtest']:
        for ext in ['png','svg']:
            check((ROOT/'figures'/f'{stem}.{ext}').stat().st_size>1000,'nonempty figure asset')
    print(f'PASS: {COUNT} GIS and finance checks; {snippet_count} chapter Python snippets executed')
    print('These tests validate the stated synthetic calculations, not a production GIS model or investment strategy.')


if __name__=='__main__':
    main()
