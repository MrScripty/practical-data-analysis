# Reproduce the spatial and financial examples

These original synthetic exercises support Chapters 16 and 17. They contain no Nearwork observations, real market data, personal finances, investment recommendation, or trading connection.

From the expanded book root:

```bash
python companion/gis_finance_examples.py
python companion/check_gis_finance_examples.py
```

The scripts also work when called using their absolute paths from another directory. For individual chapter snippets, start Python in the companion directory or set PYTHONPATH to its absolute path. The test runner executes every Python chapter block automatically, with the correct import path.

## Dependencies and files

Verified with Python 3.12.14, NumPy 2.3.5, and matplotlib 3.10.8. No network or downloaded data is used at runtime. GeoPandas, GDAL, PROJ, and PySAL are conceptual and production-library references; they are not installation requirements for these small explicit implementations.

The generator writes only these deliverables plus writable plotting caches:

- companion/derived/gis_finance_fixtures.json: inputs, assumptions, and numerical outputs
- companion/derived/gis_point_join.csv: points and half-open zone matches
- companion/derived/finance_backtest.csv: six periods of signals, held positions, turnover, and net accounting
- figures/13_geometry_and_raster_support.png and .svg
- figures/14_neighborhoods_and_randomization.png and .svg
- figures/15_cashflow_and_drawdown.png and .svg
- figures/16_portfolio_and_backtest.png and .svg

It does not read or overwrite math_examples.py outputs. Imported functions have no plotting side effects. Figures are original matplotlib diagrams; no source figures are copied.

## Spatial conventions

Geographic coordinate pairs use longitude then latitude in degrees. The haversine function uses a sphere of radius 6,371.0088 km and is not an ellipsoidal geodesic. The other spatial fixtures use invented Cartesian kilometer coordinates with no real-world EPSG code.

Rectangle bounds are xmin, ymin, xmax, ymax. Half-open joins include low bounds and exclude high bounds. Strict joins exclude all boundaries. Closed joins include boundaries and can produce duplicate memberships. This is not a general polygon engine.

The raster transform uses GDAL's six-coefficient, corner-based convention. Cell centers use column+0.5, row+0.5. The containing-cell sampler uses floor in pixel coordinates and excludes the outer right/bottom pixel boundary. The bilinear sampler works between cell centers, performs no extrapolation beyond their convex rectangular domain, and propagates positive-weight NaN values. It is inappropriate for categorical codes. Fractional zonal means support only north-up, nonrotated grids and axis-aligned rectangles. They exclude nonfinite cells, report observed area fraction, and assume intensity values constant within cells. They do not automatically conserve extensive totals under resampling.

IDW uses all unique observation locations, Euclidean distance, power 2, no smoothing, normalized nonnegative weights, and exact matching at sensor coordinates. Its a^T C a uncertainty calculation includes measurement error only. Leave-one-location-out predictions illustrate that this is different from field prediction error.

Moran's I uses a zero-diagonal row-standardized chain graph. The exact null enumerates all 24 label permutations. The Monte Carlo test uses 999 permutations and seed 1601, a prespecified right tail, and the plus-one rank formula. The exact p-value is 1/12; the seeded Monte Carlo p-value is 0.069. The two are not expected to match exactly. Local Moran values use m2=sum(z²)/n and are descriptive only: no local p-values or multiple-testing claim are implemented.

## Financial conventions

Cash flows include t=0, use positive inflows and negative outflows, and have time units matching the discount rate. The rate must exceed -1. Explicit times are nonnegative. The examples use fixed discount rates and scenario cash flows; no market discount rate is estimated.

Wealth paths use simple returns, include initial wealth, and have no external flows. Total loss is permitted; finite log returns require gross returns strictly above zero. Drawdown is nonpositive relative to the running peak; its maximum magnitude is reported positive. Model covariance and sample covariance fixtures are separate and labeled. The covariance function checks symmetry and positive semidefiniteness; it does not estimate future risk.

VaR uses an inverse empirical CDF with equal observation probabilities. Expected shortfall integrates the upper loss quantile, taking fractional mass at the cutoff. Losses are denominated in thousands of USD, not percentages. At alpha=.8 the fixture yields VaR=3 and ES=7; at alpha=.85 it yields VaR=4 and ES=8. Averaging observations at or above VaR is not the implemented convention.

The backtest supports binary cash/asset positions only. The signal observed at the end of interval t becomes the position for interval t+1. Positions start in cash. A one-way cost of 0.001 is charged on position changes before interval returns; terminal liquidation charges an additional cost. The CSV ends before the final liquidation. The JSON reports terminal wealth after it. There are six one-way trades and final wealth 95.47494002744416. Zero cash yield, no taxes, no borrowing, idealized boundary execution, and no slippage or market impact are teaching assumptions. Real execution needs an available post-signal price and a richer accounting model.

Bootstrap examples use circular, fixed-length blocks with replacement, 5,000 draws, and seed 1702. They concatenate blocks and truncate to the original length. Percentile summaries use NumPy's default linear quantile interpolation. They are conditional summaries of a short invented sequence, not coverage guarantees or return forecasts. Block length 1 is the independent-row comparison; lengths 3 and 6 expose sensitivity.

## What the checks establish

The independent test script currently passes 199 checks, including six executable chapter snippets, hand answers, complete four-site randomization, affine transforms, NoData/coverage, join cardinality, IDW invariances, two IRR roots, compounding, covariance identities, discrete tail mass, future-perturbation causality, final transaction costs, bootstrap reproducibility, and invalid inputs.

These tests validate the documented small calculations. They do not validate real geometry, geocoding accuracy, spatial exchangeability, financial data availability, tax treatment, market execution, or an investment strategy. The compiled book still needs production layout review after integration.

## Numerical boundary and scale policies

The affine inverse normalizes its two-by-two linear part before a relative singular-value check and solve. It rejects a smallest singular value no larger than twice machine epsilon times the largest; coordinate-unit rescaling alone therefore does not change acceptance.

Portfolio covariance validation uses relative tolerance 64 times dimension times machine epsilon after normalizing the matrix by its largest absolute entry. Accepted roundoff asymmetry is averaged. PSD validity uses a relative spectral bound, and a negative quadratic form is clamped only within the declared propagated bound. Materially indefinite or asymmetric covariances remain invalid at small or large unit scales.

Empirical VaR uses a left search in the computed cumulative-probability grid. A boundary belongs to the first observation attaining it. A representable probability immediately above that boundary selects the next observation; no broad epsilon merges them. ES still allocates fractional tail mass.

Run `python companion/check_release_regressions.py` from the book root for the cross-module scale, probability-boundary, and figure-integration regressions.
