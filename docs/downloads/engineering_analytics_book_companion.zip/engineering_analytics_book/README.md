# Practical Data Analysis for Engineering Decisions

Puma · Expanded edition · 2 October 2026

A project-first book for a programmer learning to analyze engineering behavior. It preserves the original thirteen chapters and adds five chapters on matrices, image measurements, spatial data, finance, and optimization under uncertainty. Sixteen original figures, worked calculations, and executable examples connect the mathematics to practical decisions.

Start with the PDF for reading, the Markdown for editing, and the chapter files for focused study. The original scheduler investigation uses pinned simulator reports and traces. It is not a hardware benchmark. The added numerical datasets are synthetic teaching examples; no live research, image-inspection, financial-account, or market data is used.

## Verify and reproduce

Use Python 3.12 with NumPy, pandas, and matplotlib. The exact versions used for the verified release are recorded in requirements-analysis.txt. If dependencies are absent, install them in a dedicated environment. The companion does not need network access, a GPU, or the scheduler repository.

From this directory, verify the distributed files before regenerating anything:

```bash
python verify_package.py
```

Then reproduce all three analysis groups and run their checks:

```bash
python companion/analyze.py
python companion/check_outputs.py
python companion/math_examples.py
python companion/check_math_examples.py
python companion/gis_finance_examples.py
python companion/check_gis_finance_examples.py
python companion/check_release_regressions.py
```

The original companion README explains the scheduler measurements, input hashes, and synthetic evaluation datasets. MATH_README.md explains arrays, image boundaries, and uncertainty simulation. GIS_FINANCE_README.md explains spatial support, financial timing, empirical tail conventions, and numerical validation. All are in companion/.

Chapter 16 and 17 snippets import gis_finance_examples. Run those snippets with companion/ on Python's import path, or work from that directory. The supplied chapter-snippet checker configures the path automatically.

## Included material

- chapters/: editable chapter source, the expanded reading path, and reference appendix
- companion/: three original analysis generators, semantic checks, documented conventions, and derived data
- snapshot/: eighteen pinned scheduler evidence files and their integrity manifest
- figures/: sixteen PNG/SVG scientific figures
- covers/: the requested Puma front and back cover artwork
- sources/: compiled bibliography and additive source records
- production/: book and package builders for recreating the deliverables
- package_manifest.json: distributed file sizes and SHA-256 hashes

The preserved first-edition chapter and snapshot hashes are in companion/first_edition_hashes.json. Regeneration can change output bytes when runtime libraries differ, so the package manifest is a check of the delivered files, not a promise that all environments render identical images.

## Building the document

The analysis needs only the requirements listed above. Rebuilding the PDF additionally needs ReportLab and the DejaVu fonts used by production/build_book.py. Run that builder from any directory to regenerate the combined Markdown and PDF under output/. Rebuilding the package additionally needs pypdf to record the PDF page count. Scientific calculations do not depend on either document library.

## Interpreting the examples

The scheduler reports represent one synthetic simulator and a small defined workload set. Three paired held-out seeds per scenario do not establish general policy superiority. The forced-final-GPU example is a diagnostic intervention, not a deployable optimal scheduler.

Image, spatial, financial, and optimization examples demonstrate calculations under stated assumptions. They are not validated deployment models or investment recommendations. In a real application, retain provenance and units, use an appropriate independent evaluation design, and test the assumptions that could reverse the decision.
