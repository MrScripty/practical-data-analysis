#!/usr/bin/env python3
"""Original synthetic examples for Chapters 14, 15 and 18.
Run from any directory. NumPy and matplotlib only; no external data/network.
"""
from pathlib import Path
import os, json, csv
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'qa/matplotlib'))
os.environ.setdefault('XDG_CACHE_HOME',str(ROOT/'qa/cache'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=ROOT/'companion/derived'; OUT.mkdir(parents=True,exist_ok=True)
FIG=ROOT/'figures'; FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':12,'axes.titlesize':13,'axes.labelsize':12,
                     'figure.dpi':160,'savefig.dpi':180,'svg.hashsalt':'engineering-math-v1'})

def save(fig,name):
    fig.savefig(FIG/(name+'.png'),bbox_inches='tight',metadata={'Software':'Engineering Analytics Book'})
    fig.savefig(FIG/(name+'.svg'),bbox_inches='tight',metadata={'Date':None})
    plt.close(fig)

def write_csv(name,rows):
    with (OUT/name).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def conv2(a,k):
    """Odd square kernel, convolution, reflect padding; explicit teaching implementation."""
    a=np.asarray(a,dtype=float); k=np.asarray(k,dtype=float)
    if a.ndim != 2 or 0 in a.shape or not np.isfinite(a).all():
        raise ValueError('Expected a nonempty finite two-dimensional image')
    if (k.ndim != 2 or k.shape[0] != k.shape[1]
            or k.shape[0] % 2 != 1 or not np.isfinite(k).all()):
        raise ValueError('Expected a finite odd square convolution kernel')
    r=k.shape[0]//2
    windows=np.lib.stride_tricks.sliding_window_view(np.pad(a,r,mode='reflect'),k.shape)
    return np.einsum('ijab,ab->ij',windows,k[::-1,::-1])

def binary_op(a,op):
    if op not in {'erode', 'dilate'}:
        raise ValueError('Expected erode or dilate')
    windows=np.lib.stride_tricks.sliding_window_view(np.pad(a,1,constant_values=False),(3,3))
    return (windows.all if op=='erode' else windows.any)(axis=(-2,-1))

def components(mask):
    """Four-neighbor connected components; zero background."""
    labels=np.zeros(mask.shape,dtype=int); n=0
    for r,c in np.argwhere(mask):
        if labels[r,c]:continue
        n+=1;labels[r,c]=n; stack=[(int(r),int(c))]
        while stack:
            i,j=stack.pop()
            for di,dj in ((-1,0),(1,0),(0,-1),(0,1)):
                x,y=i+di,j+dj
                if 0<=x<mask.shape[0] and 0<=y<mask.shape[1] and mask[x,y] and not labels[x,y]:
                    labels[x,y]=n;stack.append((x,y))
    return labels,n

def run():
    fixture={'schema_version':1,'provenance':'All new examples are synthetic teaching data; not scheduler measurements.'}
    x=np.array([3.,1.]); u=np.array([1.,1.]); projection=u*(x@u)/(u@u)
    residual=x-projection
    X=np.array([[1.,2.],[2.,1.],[3.,4.],[4.,3.]])
    mean=X.mean(axis=0); C=X-mean
    U,s,Vt=np.linalg.svd(C,full_matrices=False)
    # Fix arbitrary signs for stable figures; preserve U*S*Vt identity.
    for j in range(len(s)):
        if Vt[j,np.argmax(abs(Vt[j]))]<0:Vt[j]*=-1;U[:,j]*=-1
    scores=C@Vt.T; recon=scores[:,:1]@Vt[:1]+mean
    covariance=C.T@C/(len(X)-1); eig=s*s/(len(X)-1)
    A=np.column_stack([np.ones(3),np.arange(3)]); y=np.array([1.,2.,2.])
    beta=np.linalg.lstsq(A,y,rcond=None)[0]; fit=A@beta
    fixture['vectors']={'x':x.tolist(),'direction':u.tolist(),'projection':projection.tolist(),
        'residual':residual.tolist(),'distance_raw':[1.,10.],'distance_seconds_to_ms':[1000.,10.],
        'distance_scaled':[1.,.5]}
    fixture['pca']={'data':X.tolist(),'mean':mean.tolist(),'covariance':covariance.tolist(),
        'singular_values':s.tolist(),'axes':Vt.tolist(),'scores':scores.tolist(),
        'eigenvalues':eig.tolist(),'explained_fraction':(eig/eig.sum()).tolist(),
        'rank_one_reconstruction':recon.tolist(),'squared_reconstruction_error':float(((X-recon)**2).sum())}
    fixture['least_squares']={'features':A.tolist(),'observed':y.tolist(),'beta':beta.tolist(),
                             'predicted':fit.tolist(),'residual':(y-fit).tolist()}
    fig,ax=plt.subplots(1,2,figsize=(10,4.3),layout='constrained')
    for v,label,color in ((x,'x = (3, 1)','#345C80'),(projection,'projection = (2, 2)','#B46B20')):
        ax[0].quiver(0,0,*v,angles='xy',scale_units='xy',scale=1,color=color,label=label)
    ax[0].plot([0,3],[0,3],':',color='gray');ax[0].plot([2,3],[2,1],'k--',label='orthogonal residual')
    ax[0].set(xlim=(-.1,3.6),ylim=(-.1,3.6),xlabel='Feature 1',ylabel='Feature 2',title='Projection separates a direction')
    ax[0].set_aspect('equal');ax[0].legend(fontsize=11.5,loc='upper left')
    ax[1].scatter(X[:,0],X[:,1],label='original',s=55)
    ax[1].scatter(recon[:,0],recon[:,1],marker='x',s=90,label='rank one reconstruction')
    for p,q in zip(X,recon):ax[1].plot([p[0],q[0]],[p[1],q[1]],'k:',alpha=.6)
    ax[1].plot([.7,4.3],[.7,4.3],color='#B46B20',alpha=.5,label='first principal direction')
    ax[1].set(xlim=(.5,4.5),ylim=(.5,4.5),xlabel='Duration index (scaled units)',ylabel='Load index (scaled units)',title='One axis retains 80% of variation')
    ax[1].set_aspect('equal')
    handles, labels = ax[1].get_legend_handles_labels()
    fig.legend(handles, labels, loc='outside lower center', ncol=3, fontsize=11.5)
    save(fig,'07_projection_and_pca')
    rng=np.random.default_rng(1401);high=[];boxes=[]
    for d in (2,10,100,1000):
        # Difference of two independent N(0, I) vectors has N(0, 2I) distribution.
        sq=(rng.normal(0,np.sqrt(2),size=(5000,d))**2).sum(axis=1)
        high.append({'dimensions':d,'pair_count':len(sq),'mean_squared_distance':float(sq.mean()),
            'cv_squared_distance':float(sq.std(ddof=1)/sq.mean()),'theory_cv_squared_distance':float(np.sqrt(2/d))})
        boxes.append(sq/(2*d))
    fixture['high_dimension']=high;write_csv('high_dimensional_distances.csv',high)
    fig,ax=plt.subplots(figsize=(8,4.2),layout='constrained')
    ax.boxplot(boxes,tick_labels=['2','10','100','1,000'],showfliers=False,whis=(5,95))
    ax.axhline(1,color='gray',ls=':');ax.set(xlabel='Number of independent Gaussian features',ylabel='Squared distance / (2 × dimension)',title='Distances concentrate under this specified model')
    ax.text(.98,.96,'5,000 pairs per dimension; whiskers 5th–95th percentiles',transform=ax.transAxes,ha='right',va='top',fontsize=11.5)
    save(fig,'08_distance_concentration')
    # Synthetic image: known object, blur, independent noise, one speck and one hole.
    truth=np.zeros((64,64),bool);truth[18:42,20:44]=True
    kernel=np.outer([1.,2.,1.],[1.,2.,1.])/16
    clean=.12+.7*truth
    rng=np.random.default_rng(1501)
    observed=np.clip(conv2(clean,kernel)+rng.normal(0,.025,truth.shape),0,1)
    observed[8,8]=.98;observed[29,31]=.12
    masks=[observed>=t for t in (.3,.5,.7)]
    rows=[]
    for threshold,mask in zip((.3,.5,.7),masks):
        labels,n=components(mask);areas=np.bincount(labels.ravel())[1:]
        largest=labels==(1+int(areas.argmax()))
        pos=np.argwhere(largest)
        rows.append({'threshold':threshold,'components_4_connected':n,'all_foreground_pixels':int(mask.sum()),
          'largest_pixels':int(largest.sum()),'largest_area_mm2':float(largest.sum()*.2**2),
          'centroid_row':float(pos[:,0].mean()),'centroid_col':float(pos[:,1].mean()),
          'iou_truth_largest':float((truth&largest).sum()/(truth|largest).sum())})
    raw=masks[1];opened=binary_op(binary_op(raw,'erode'),'dilate');closed=binary_op(binary_op(raw,'dilate'),'erode')
    write_csv('image_threshold_measurements.csv',rows)
    fixture['image']={'seed':1501,'shape':[64,64],'intensity_units':'unitless synthetic normalized intensity',
        'pixel_spacing_mm':[.2,.2],'truth_area_pixels':int(truth.sum()),'truth_area_mm2':float(truth.sum()*.2**2),
        'threshold_rows':rows,'raw_count':int(raw.sum()),'opening_count':int(opened.sum()),'closing_count':int(closed.sum()),
        'observed':observed.tolist(),'truth':truth.astype(int).tolist(),'kernel':kernel.tolist()}
    fig,axes=plt.subplots(2,3,figsize=(10,6.8),layout='constrained')
    for ax,a,title in zip(axes.flat,[truth,observed,masks[0],raw,opened,closed],
        ['Known synthetic object','Observed intensity','Threshold 0.30','Threshold 0.50','Opening with 3 × 3 square','Closing with 3 × 3 square']):
        ax.imshow(a,cmap='gray',vmin=0,vmax=1,interpolation='nearest');ax.set_title(title);ax.set_xticks([]);ax.set_yticks([])
    save(fig,'09_image_measurement_pipeline')
    fig,ax=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    ax[0].hist(observed.ravel(),bins=np.linspace(0,1,41),color='#345C80')
    for t in (.3,.5,.7):ax[0].axvline(t,ls=':',label=f't = {t:.1f}')
    ax[0].set(xlabel='Synthetic pixel intensity',ylabel='Pixel count',title='Histogram discards spatial arrangement');ax[0].legend(fontsize=11.5)
    N=64;n=np.arange(N);signal=np.sin(2*np.pi*4*n/N)+.3*np.sin(2*np.pi*20*n/N)
    H=np.array([.25,.5,.25]);smoothed=(np.roll(signal,1)+2*signal+np.roll(signal,-1))/4
    amp=2*np.abs(np.fft.rfft(signal))/N;amp[0]/=2;amp[-1]/=2
    smooth_amp=2*np.abs(np.fft.rfft(smoothed))/N;smooth_amp[0]/=2;smooth_amp[-1]/=2
    freq=np.fft.rfftfreq(N,d=1)
    ax[1].plot(freq,amp,'o-',markersize=3,label='original');ax[1].plot(freq,smooth_amp,'x--',markersize=4,label='3 point average')
    ax[1].set(xlabel='Cycles per pixel',ylabel='Sinusoid amplitude',title='Smoothing reduces high frequencies more');ax[1].legend(fontsize=11.5)
    fixture['frequency']={'N':N,'signal':signal.tolist(),'filtered':smoothed.tolist(),'frequencies':freq.tolist(),
        'amplitudes':amp.tolist(),'filtered_amplitudes':smooth_amp.tolist(),
        'boundary':'periodic (circular), deliberately different from reflect image padding'}
    save(fig,'10_histogram_and_frequency')
    # Optimization model is illustrative and not fitted to scheduler measurements.
    workers=np.arange(1,33);nominal=100/workers+2+.2*(workers-1)
    rng=np.random.default_rng(1801);draws=100000
    a=rng.uniform(80,120,draws);b=rng.uniform(1,3,draws);c=rng.uniform(.1,.3,draws)
    times=a[:,None]/workers+b[:,None]+c[:,None]*(workers-1)
    quantiles=np.quantile(times,[.05,.5,.95],axis=0)
    variance=(40**2/12)/workers**2 + 2**2/12 + (.2**2/12)*(workers-1)**2
    sensitivity=np.array([1/22,1,21]);sd=np.array([40,2,.2])/np.sqrt(12)
    variance_parts=(sensitivity*sd)**2
    opt=workers[np.argmin(times,axis=1)]
    p=(times[:,21]>12).mean();pse=np.sqrt(p*(1-p)/draws)
    rows=[{'workers':int(k),'nominal_seconds':float(nominal[i]),'mean_seconds_mc':float(times[:,i].mean()),
       'p05_seconds_mc':float(quantiles[0,i]),'median_seconds_mc':float(quantiles[1,i]),'p95_seconds_mc':float(quantiles[2,i]),
       'sd_seconds_analytic':float(np.sqrt(variance[i]))} for i,k in enumerate(workers)]
    fixture['optimization']={'model':'T(n)=a/n+b+c*(n-1)',
       'input_assumptions':{'a':'Uniform(80,120)','b':'Uniform(1,3)','c':'Uniform(0.1,0.3)','dependence':'independent'},
       'seed':1801,'draws':draws,'nominal_continuous_minimizer':float(np.sqrt(500)),
       'nominal_integer_minimizer':int(workers[nominal.argmin()]),'budget_12_minimizer':int(workers[:12][nominal[:12].argmin()]),
       'nominal_22_seconds':float(nominal[21]),'nominal_23_seconds':float(nominal[22]),
       'variance_parts_at_22':variance_parts.tolist(),'sd_time_22_analytic':float(np.sqrt(variance[21])),
       'sd_time_22_mc':float(times[:,21].std(ddof=1)),'mean_time_22_mc':float(times[:,21].mean()),
       'probability_time_22_above_12':float(p),'probability_mc_standard_error':float(pse),
       'mean_batch_rate_22_mc':float((600/times[:,21]).mean()),'aggregate_batch_rate_22_mc':float(600/times[:,21].mean()),
       'sd_batch_rate_22_mc':float((600/times[:,21]).std(ddof=1)),
       'sd_batch_rate_22_linear':float(600/nominal[21]**2*np.sqrt(variance[21])),
       'per_draw_optimum_counts':{str(k):int((opt==k).sum()) for k in np.unique(opt)},'rows':rows,
       'common_random_numbers':'One (a,b,c) triple is reused for all n within each draw.'}
    write_csv('worker_sensitivity.csv',rows)
    fig,ax=plt.subplots(1,2,figsize=(10,4.3),layout='constrained')
    ax[0].fill_between(workers,quantiles[0],quantiles[2],color='#B6CCDF',alpha=.75,label='5th–95th input uncertainty band')
    ax[0].plot(workers,nominal,color='#345C80',label='nominal coefficients');ax[0].axvline(22,ls=':',color='#B46B20',label='nominal integer optimum')
    ax[0].set(xlabel='Workers n',ylabel='Batch duration (seconds)',title='Synthetic concurrency model',ylim=(5,42));ax[0].legend(fontsize=11.5)
    ax[1].bar(['parallel work a','fixed overhead b','coordination c'],variance_parts,color=['#345C80','#779CA3','#B46B20'])
    ax[1].set(ylabel='Contribution to variance (seconds²)',title='Uncertainty budget at 22 workers');ax[1].tick_params(axis='x',labelsize=11.5)
    save(fig,'11_optimization_and_sensitivity')
    fig,ax=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    ax[0].hist(times[:,21],bins=50,color='#345C80');ax[0].axvline(12,color='#B46B20',ls='--',label='12 second threshold')
    ax[0].set(xlabel='Batch duration at n = 22 (seconds)',ylabel='Monte Carlo count',title='Output uncertainty under the input model');ax[0].text(12.15,3900,'12 s',fontsize=11.5,va='top',color='#B46B20')
    kvals=sorted(map(int,fixture['optimization']['per_draw_optimum_counts']))
    ax[1].bar(kvals,[fixture['optimization']['per_draw_optimum_counts'][str(k)]/draws for k in kvals],color='#779CA3')
    ax[1].set(xlabel='Best n if that draw were known',ylabel='Fraction of input draws',title='Unknown coefficients change the optimum')
    save(fig,'12_uncertainty_and_optima')
    (OUT/'math_fixtures.json').write_text(json.dumps(fixture,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'figures':6,'high_dimension':high,'image':fixture['image']['threshold_rows'],'optimization':{k:v for k,v in fixture['optimization'].items() if k not in ('rows','per_draw_optimum_counts')}},indent=2))
    return fixture

if __name__=='__main__':run()
