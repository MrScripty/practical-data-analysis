#!/usr/bin/env python3
"""Original synthetic examples for Chapters 16 and 17, with no external data.
Run from any directory. Requires only NumPy and matplotlib.
Conventions and limitations are documented in GIS_FINANCE_README.md.
"""
from pathlib import Path
from itertools import permutations
import csv
import json
import os

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / 'qa/matplotlib_gis_finance'))
os.environ.setdefault('XDG_CACHE_HOME', str(ROOT / 'qa/cache_gis_finance'))
import numpy as np


def finite_array(value, ndim=None):
    a = np.asarray(value, dtype=float)
    if (ndim is not None and a.ndim != ndim) or not np.all(np.isfinite(a)):
        raise ValueError('Wrong dimensions or nonfinite input')
    return a


def haversine_km(lonlat_a, lonlat_b):
    """Great-circle distance on a sphere, NOT an ellipsoidal geodesic."""
    a, b = finite_array(lonlat_a, 1), finite_array(lonlat_b, 1)
    for point in (a, b):
        if point.shape != (2,) or abs(point[0]) > 180 or abs(point[1]) > 90:
            raise ValueError('Expected longitude, latitude in degrees')
    lon1, lat1 = np.radians(a)
    lon2, lat2 = np.radians(b)
    h = np.sin((lat2-lat1)/2)**2 + np.cos(lat1)*np.cos(lat2)*np.sin((lon2-lon1)/2)**2
    return float(2*6371.0088*np.arcsin(np.sqrt(np.clip(h, 0, 1))))


def rectangle_join(points, rectangles, boundary='half_open'):
    """Teaching join for axis-aligned rectangles only. Bounds: xmin,ymin,xmax,ymax."""
    points, bounds = finite_array(points, 2), finite_array(rectangles, 2)
    if points.shape[1] != 2 or bounds.shape[1] != 4:
        raise ValueError('Expected point pairs and four rectangle bounds')
    if np.any(bounds[:, 2:] <= bounds[:, :2]):
        raise ValueError('Rectangle must have positive width and height')
    if boundary not in {'half_open', 'closed', 'strict'}:
        raise ValueError('Unknown boundary rule')
    matches = []
    for point in points:
        low = point >= bounds[:, :2] if boundary != 'strict' else point > bounds[:, :2]
        high = point <= bounds[:, 2:] if boundary == 'closed' else point < bounds[:, 2:]
        matches.append(np.flatnonzero(np.all(low & high, axis=1)).tolist())
    return matches


def world_to_pixel(xy, transform):
    """Invert GDAL affine transform. Returns corner-based column,row coordinates."""
    xy, g = finite_array(xy, 1), finite_array(transform, 1)
    if xy.shape != (2,) or g.shape != (6,):
        raise ValueError('Expected xy and six geotransform coefficients')
    matrix = np.array([[g[1], g[2]], [g[4], g[5]]])
    # A determinant has squared coordinate units. Normalize before checking
    # conditioning so a consistent change of map units does not change validity.
    scale = np.max(np.abs(matrix))
    if scale == 0:
        raise ValueError('Singular raster transform')
    normalized = matrix / scale
    singular = np.linalg.svd(normalized, compute_uv=False)
    if singular[-1] <= 2*np.finfo(float).eps*singular[0]:
        raise ValueError('Singular or numerically ill-conditioned raster transform')
    try:
        return np.linalg.solve(normalized, (xy - g[[0, 3]]) / scale)
    except np.linalg.LinAlgError as exc:
        raise ValueError('Singular raster transform') from exc


def sample_cell(raster, xy, transform):
    """Containing cell; half-open pixel domain. Out of bounds returns NaN."""
    a = np.asarray(raster, dtype=float)
    if a.ndim != 2 or 0 in a.shape:
        raise ValueError('Expected nonempty raster')
    col, row = np.floor(world_to_pixel(xy, transform)).astype(int)
    return float(a[row, col]) if 0 <= row < a.shape[0] and 0 <= col < a.shape[1] else float('nan')


def sample_bilinear(raster, xy, transform):
    """Interpolate between cell centers. No extrapolation; positive-weight NoData propagates."""
    a = np.asarray(raster, dtype=float)
    if a.ndim != 2 or 0 in a.shape:
        raise ValueError('Expected nonempty raster')
    col, row = world_to_pixel(xy, transform) - 0.5
    if not (0 <= row <= a.shape[0]-1 and 0 <= col <= a.shape[1]-1):
        return float('nan')
    r0, c0 = int(np.floor(row)), int(np.floor(col))
    r1, c1 = min(r0+1, a.shape[0]-1), min(c0+1, a.shape[1]-1)
    dy, dx = row-r0, col-c0
    weights = [(r0,c0,(1-dy)*(1-dx)), (r0,c1,(1-dy)*dx),
               (r1,c0,dy*(1-dx)), (r1,c1,dy*dx)]
    return float(sum(weight*a[r,c] for r,c,weight in weights if weight > 0))


def fractional_zonal_mean(raster, transform, bounds):
    """Area-weighted mean for north-up axis-aligned raster and rectangle only.
    Returns mean and observed area fraction; missing cells are excluded from mean.
    """
    a = np.asarray(raster, dtype=float)
    g, b = finite_array(transform, 1), finite_array(bounds, 1)
    if a.ndim != 2 or 0 in a.shape or g.shape != (6,) or b.shape != (4,):
        raise ValueError('Invalid raster, transform, or bounds')
    if g[2] != 0 or g[4] != 0 or g[1] <= 0 or g[5] >= 0 or np.any(b[2:] <= b[:2]):
        raise ValueError('Requires positive-area zone and north-up nonrotated raster')
    total, observed_area = 0., 0.
    for r in range(a.shape[0]):
        for c in range(a.shape[1]):
            left, right = g[0]+c*g[1], g[0]+(c+1)*g[1]
            top, bottom = g[3]+r*g[5], g[3]+(r+1)*g[5]
            overlap = max(0., min(right,b[2])-max(left,b[0])) * max(0., min(top,b[3])-max(bottom,b[1]))
            if overlap and np.isfinite(a[r,c]):
                total += overlap*a[r,c]
                observed_area += overlap
    mean = total/observed_area if observed_area else float('nan')
    coverage = observed_area/((b[2]-b[0])*(b[3]-b[1]))
    return float(mean), float(coverage)


def idw(points, values, query, power=2.):
    """All-point inverse distance weighting; exact nodes, no smoothing, unique points."""
    p, z, q = finite_array(points, 2), finite_array(values, 1), finite_array(query, 1)
    if p.shape[1] != 2 or p.shape[0] != len(z) or not len(z) or q.shape != (2,):
        raise ValueError('Incompatible coordinates and values')
    if not np.isfinite(power) or power <= 0 or len(np.unique(p,axis=0)) != len(p):
        raise ValueError('Need positive power and unique source coordinates')
    distance = np.linalg.norm(p-q, axis=1)
    weights = np.zeros(len(z))
    if np.any(distance == 0):
        weights[np.argmin(distance)] = 1.
    else:
        # Scaling cancels in normalized weights and avoids small-distance overflow.
        raw = (distance.min()/distance)**power
        weights = raw/raw.sum()
    return float(weights @ z), weights


def row_standardize(weights):
    w = finite_array(weights, 2)
    if w.shape[0] != w.shape[1] or len(w) < 2 or np.any(w < 0) or np.any(np.diag(w) != 0):
        raise ValueError('Need square nonnegative weights with zero diagonal')
    if np.any(w.sum(axis=1) == 0):
        raise ValueError('Islands require an explicit policy')
    return w/w.sum(axis=1, keepdims=True)


def chain_weights(n):
    if not isinstance(n, (int, np.integer)) or n < 2:
        raise ValueError('Need at least two locations')
    w = np.eye(n,k=1)+np.eye(n,k=-1)
    return row_standardize(w)


def moran_i(values, weights):
    x, w = finite_array(values, 1), finite_array(weights, 2)
    if len(x) < 2 or w.shape != (len(x),len(x)) or np.any(w < 0) or np.any(np.diag(w) != 0):
        raise ValueError('Invalid attributes or spatial weights')
    z = x-x.mean()
    if z@z == 0 or w.sum() <= 0:
        raise ValueError('Constant attributes or zero total weight')
    return float(len(x)/w.sum() * (z@w@z)/(z@z))


def moran_permutation(values, weights, draws=999, seed=1601):
    """Right-tailed random-label Monte Carlo test conditional on fixed W and values."""
    if not isinstance(draws,(int,np.integer)) or draws < 1:
        raise ValueError('Need a positive number of draws')
    observed = moran_i(values, weights)
    rng = np.random.default_rng(seed)
    null = np.array([moran_i(rng.permutation(values),weights) for _ in range(draws)])
    count = np.count_nonzero(null >= observed-1e-12)
    return observed, float((count+1)/(draws+1)), null


def npv(cashflows, rate, times=None):
    """Cashflows at stated nonnegative times, t=0 included; rate per matching unit."""
    c = finite_array(cashflows,1)
    t = np.arange(len(c),dtype=float) if times is None else finite_array(times,1)
    if not len(c) or t.shape != c.shape or np.any(t < 0) or not np.isfinite(rate) or rate <= -1:
        raise ValueError('Invalid cashflows, times, or discount rate')
    return float(np.sum(c / (1+rate)**t))


def wealth_path(returns, initial=100.):
    """No external cashflows; simple returns may equal -1 (total loss)."""
    r = finite_array(returns,1)
    if np.any(r < -1) or not np.isfinite(initial) or initial <= 0:
        raise ValueError('Need positive initial wealth and returns at least -1')
    return np.r_[initial, initial*np.cumprod(1+r)]


def drawdown(wealth):
    w = finite_array(wealth,1)
    if not len(w) or w[0] <= 0 or np.any(w < 0):
        raise ValueError('Need nonnegative wealth starting above zero')
    return w/np.maximum.accumulate(w)-1


def portfolio_variance(weights, covariance):
    """Quadratic risk with scale-relative symmetry/PSD checks.

    Tolerance is 64*n*machine_epsilon relative to the matrix scale. Small
    accepted asymmetry is averaged. Only a negative quadratic form within
    the corresponding spectral error bound is clamped to zero.
    """
    w, s = finite_array(weights,1), finite_array(covariance,2)
    if not len(w) or s.shape != (len(w),len(w)):
        raise ValueError('Covariance must match weights')
    scale = np.max(np.abs(s))
    if scale == 0:
        return 0.
    normalized = s / scale
    tolerance = 64*len(w)*np.finfo(float).eps
    if np.max(np.abs(normalized-normalized.T)) > tolerance:
        raise ValueError('Covariance must be symmetric within relative roundoff')
    symmetric = (normalized+normalized.T)/2
    eigenvalues = np.linalg.eigvalsh(symmetric)
    spectral = np.max(np.abs(eigenvalues))
    if eigenvalues[0] < -tolerance*spectral:
        raise ValueError('Covariance is not positive semidefinite')
    weight_scale = np.max(np.abs(w))
    if weight_scale == 0:
        return 0.
    unit_weights = w/weight_scale
    quadratic = float(unit_weights @ symmetric @ unit_weights)
    roundoff_bound = 2*tolerance*spectral*float(unit_weights @ unit_weights)
    if quadratic < -roundoff_bound:
        raise ValueError('Negative variance exceeds the declared roundoff bound')
    if quadratic < 0:
        quadratic = 0.
    value = (np.longdouble(quadratic)*np.longdouble(scale)
             *np.longdouble(weight_scale)**2)
    if value > np.finfo(float).max:
        raise ValueError('Portfolio variance exceeds floating-point range')
    return float(value)


def empirical_var_es(losses, alpha=.8):
    """Equal-probability empirical losses. Inverse-CDF VaR and integrated-quantile ES.
    Handles discrete mass at the cutoff by taking fractional observations.
    VaR uses left search in the float CDF grid: grid boundaries belong to
    their first attaining observation; adjacent floats remain distinguishable.
    """
    losses = np.sort(finite_array(losses,1))
    if not len(losses) or not 0 < alpha < 1:
        raise ValueError('Need observations and alpha strictly between zero and one')
    n = len(losses)
    left = np.arange(n)/n
    right = np.arange(1,n+1)/n
    var = losses[np.searchsorted(right, alpha, side='left')]
    tail_mass = np.maximum(0., right-np.maximum(left,alpha))
    es = (losses@tail_mass)/(1-alpha)
    return float(var), float(es)


def causal_backtest(returns, close_signal, cost_rate=.001, liquidate=True):
    """Binary cash/asset strategy. Signal after return t executes for interval t+1.
    Fee is charged before each holding interval on starting wealth. Cash yield zero.
    End liquidation, if requested, is an extra terminal cost without another return.
    """
    r, signal = finite_array(returns,1), finite_array(close_signal,1)
    if len(r) != len(signal) or not len(r) or np.any(r <= -1) or not np.all(np.isin(signal,[0.,1.])):
        raise ValueError('Need aligned returns above -1 and binary close signals')
    if not np.isfinite(cost_rate) or not 0 <= cost_rate < 1:
        raise ValueError('Invalid one-way cost rate')
    position = np.r_[0.,signal[:-1]]
    turnover = np.abs(position-np.r_[0.,position[:-1]])
    factor = (1-cost_rate*turnover)*(1+position*r)
    terminal_fee = cost_rate*position[-1] if liquidate else 0.
    wealth = np.r_[100.,100.*np.cumprod(factor)]
    terminal_wealth = wealth[-1]*(1-terminal_fee)
    return {'position':position,'turnover':turnover,'period_factor':factor,
            'wealth_before_final_liquidation':wealth,'terminal_wealth':float(terminal_wealth),
            'total_one_way_trades':float(turnover.sum()+(position[-1] if liquidate else 0.))}


def circular_block_means(values, block_length=3, draws=5000, seed=1702):
    """Circular moving-block bootstrap of the mean, conditional on observed series."""
    x = finite_array(values,1)
    if not len(x) or not isinstance(block_length,(int,np.integer)) or not 1 <= block_length <= len(x):
        raise ValueError('Invalid series or block length')
    if not isinstance(draws,(int,np.integer)) or draws < 1:
        raise ValueError('Invalid draw count')
    rng = np.random.default_rng(seed)
    starts = rng.integers(0,len(x),size=(draws,int(np.ceil(len(x)/block_length))))
    indices = (starts[:,:,None]+np.arange(block_length)) % len(x)
    indices = indices.reshape(draws,-1)[:,:len(x)]
    return x[indices].mean(axis=1)


def write_csv(path, rows):
    with path.open('w',newline='') as f:
        writer = csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    out, figdir = ROOT/'companion/derived', ROOT/'figures'
    out.mkdir(exist_ok=True,parents=True)
    figdir.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':12,'axes.titlesize':13,'axes.labelsize':12,
                         'figure.dpi':150,'savefig.dpi':180,'svg.hashsalt':'gis-finance-v1'})
    def save(fig,name):
        fig.savefig(figdir/(name+'.png'),bbox_inches='tight',metadata={'Software':'Engineering Analytics Book'})
        fig.savefig(figdir/(name+'.svg'),bbox_inches='tight',metadata={'Date':None})
        plt.close(fig)
    f = {'schema_version':1,'provenance':'All values original synthetic teaching fixtures, not financial or Nearwork observations.'}
    p = np.array([[.5,.5],[1.5,.5],[2.,.5],[3.5,.5],[.5,2.5],[2.5,2.5],[4.,1.]])
    b = np.array([[0.,0.,2.,2.],[2.,0.,4.,2.],[0.,2.,2.,4.],[2.,2.,4.,4.]])
    joins = {mode:rectangle_join(p,b,mode) for mode in ['half_open','strict','closed']}
    f['geometry'] = {'point_ids':list('ABCDEFG'),'points_km':p.tolist(),'rectangles_km':b.tolist(),
                     'joins':joins,'equator_one_degree_km':haversine_km([0,0],[1,0]),
                     'latitude60_one_degree_km':haversine_km([0,60],[1,60])}
    raster = np.array([[10.,20.],[30.,40.]])
    gt = [0.,2.,0.,4.,0.,-2.]
    zonal = fractional_zonal_mean(raster,gt,[0.,1.,3.,4.])
    f['raster'] = {'values':raster.tolist(),'geotransform':gt,'query':[2.,2.],
                   'containing_cell':sample_cell(raster,[2,2],gt),'bilinear':sample_bilinear(raster,[2,2],gt),
                   'zone_bounds':[0.,1.,3.,4.],'zone_mean':zonal[0],'zone_coverage':zonal[1]}
    ip, iz = np.array([[0.,0.],[2.,0.],[0.,2.]]), np.array([10.,20.,30.])
    estimate, a = idw(ip,iz,[1.,0.])
    loo = [idw(np.delete(ip,i,0),np.delete(iz,i),ip[i])[0] for i in range(3)]
    f['interpolation'] = {'points':ip.tolist(),'values':iz.tolist(),'query':[1.,0.],
                          'prediction':estimate,'weights':a.tolist(),'measurement_only_variance':float(a@np.diag([4.,4.,4.])@a),
                          'leave_one_out_prediction':loo,'leave_one_out_rmse':float(np.sqrt(np.mean((iz-loo)**2)))}
    x, w = np.array([1.,2.,3.,4.]), chain_weights(4)
    exact = np.array([moran_i(v,w) for v in permutations(x)])
    observed, mc_p, simulated = moran_permutation(x,w)
    z = x-x.mean()
    local = z*(w@z)/np.mean(z*z)
    f['moran'] = {'values':x.tolist(),'weights':w.tolist(),'I':observed,'lag':(w@x).tolist(),
                   'local_I':local.tolist(),'exact_null':exact.tolist(),'exact_mean':float(exact.mean()),
                   'exact_right_p':float(np.mean(exact >= observed-1e-12)),
                   'mc_draws':999,'mc_seed':1601,'mc_right_p':mc_p,'mc_null_mean':float(simulated.mean())}
    f['aggregation'] = {'cell_values':[[1.,1.],[9.,9.]],'row_means':[1.,9.],'column_means':[5.,5.],
                         'individual_x':[1.,2.,3.,4.],'individual_y':[4.,3.,6.,5.],
                         'group_mean_x':[1.5,3.5],'group_mean_y':[3.5,5.5]}
    fig,ax = plt.subplots(1,2,figsize=(10.2,4.2),layout='constrained')
    for k,(x0,y0,x1,y1) in enumerate(b):
        ax[0].add_patch(Rectangle((x0,y0),x1-x0,y1-y0,facecolor='#DCE7EE',edgecolor='#345C80',alpha=.7))
        ax[0].text((x0+x1)/2,(y0+y1)/2+.2,f'Zone {k+1}',ha='center',color='#345C80')
    ax[0].scatter(p[:,0],p[:,1],color='#B46B20',zorder=3)
    for label,point in zip('ABCDEFG',p): ax[0].annotate(label,point,xytext=(4,5),textcoords='offset points')
    ax[0].set(xlim=(-.2,4.6),ylim=(-.2,4.3),xlabel='Local easting (km)',ylabel='Local northing (km)',title='A join needs a boundary rule')
    ax[0].set_aspect('equal')
    ax[1].imshow(raster,extent=[0,4,0,4],origin='upper',cmap='Blues',vmin=0,vmax=45)
    for row in range(2):
        for col in range(2): ax[1].text(.75+2*col,3.2-2*row,str(int(raster[row,col])),ha='center',va='center',color='white' if row else 'black',fontsize=14)
    ax[1].add_patch(Rectangle((0,1),3,3,fill=False,edgecolor='#B46B20',lw=2,linestyle='--'))
    ax[1].scatter([2],[2],color='#B46B20',marker='x',s=75)
    ax[1].set(xlabel='Local easting (km)',ylabel='Local northing (km)',title='Bilinear point 25; dashed-zone mean 20',xticks=range(5),yticks=range(5))
    save(fig,'13_geometry_and_raster_support')
    fig,ax = plt.subplots(1,2,figsize=(10.2,3.9),layout='constrained')
    ax[0].plot(range(1,5),x,'o-',label='observed',color='#345C80')
    ax[0].plot(range(1,5),w@x,'s--',label='neighbor mean',color='#B46B20')
    ax[0].set(xlabel='Location along a chain',ylabel='Synthetic attribute',title='Four fixed locations and a fixed graph',xticks=range(1,5))
    ax[0].legend()
    rounded, counts = np.unique(np.round(exact,8),return_counts=True)
    ax[1].bar(rounded,counts/len(exact),width=.065,color='#345C80')
    ax[1].axvline(observed,color='#B46B20',lw=2,label='observed I = 0.4')
    ax[1].axvline(-1/3,color='black',ls=':',label='null mean = -1/3')
    ax[1].set(xlabel="Moran's I",ylabel='Exact permutation probability',title='All 24 label assignments; right-tail p = 1/12')
    ax[1].set_ylim(0,.33)
    ax[1].legend(fontsize=11.5,loc='upper center')
    save(fig,'14_neighborhoods_and_randomization')
    cash = np.array([-10000.,4000.,4000.,4000.])
    f['cashflow'] = {'cashflows_usd':cash.tolist(),'times_years':[0,1,2,3],
                     'npv_5pct_usd':npv(cash,.05),'npv_10pct_usd':npv(cash,.10),
                     'annual_savings_break_even_5pct':10000/sum(1/1.05**t for t in [1,2,3]),
                     'npv_low_3000':npv([-10000,3000,3000,3000],.05),
                     'npv_high_5000':npv([-10000,5000,5000,5000],.05),
                     'irr_counterexample_rates':[.1,.2],
                     'irr_counterexample_npvs':[npv([-100,230,-132],.1),npv([-100,230,-132],.2)]}
    returns = np.array([.10,-.10,.05,-.20,.25])
    wealth = wealth_path(returns)
    dd = drawdown(wealth)
    f['returns'] = {'simple':returns.tolist(),'log':np.log1p(returns).tolist(),'wealth':wealth.tolist(),
                    'drawdown':dd.tolist(),'total_return':float(wealth[-1]/wealth[0]-1),
                    'arithmetic_mean':float(returns.mean()),'geometric_mean':float(np.expm1(np.log1p(returns).mean())),
                    'max_drawdown_magnitude':float(-dd.min())}
    covariance = np.array([[.04,.01],[.01,.01]])
    weights = np.array([.5,.5])
    sample_returns = np.array([[.02,.01],[-.01,.00],[.03,.02],[-.02,-.01]])
    sample_cov = np.cov(sample_returns,rowvar=False,ddof=1)
    f['portfolio'] = {'model_covariance':covariance.tolist(),'weights':weights.tolist(),
                      'variance':portfolio_variance(weights,covariance),'volatility':float(np.sqrt(portfolio_variance(weights,covariance))),
                      'sample_returns':sample_returns.tolist(),'sample_covariance':sample_cov.tolist(),
                      'direct_sample_portfolio_variance':float(np.var(sample_returns@weights,ddof=1))}
    losses = [0.,0.,0.,0.,1.,1.,2.,3.,4.,10.]
    f['tail_risk'] = {'losses_thousand_usd':losses,'alpha_80_var_es':list(empirical_var_es(losses,.8)),
                      'alpha_85_var_es':list(empirical_var_es(losses,.85))}
    r = np.array([.02,-.01,.03,-.02,.01,-.01])
    signal = (r > 0).astype(float)
    gross, net = causal_backtest(r,signal,0.), causal_backtest(r,signal,.001)
    leaky = wealth_path(signal*r)
    f['backtest'] = {'asset_returns':r.tolist(),'close_signal':signal.tolist(),'position':net['position'].tolist(),
                    'turnover':net['turnover'].tolist(),'cost_rate':.001,'liquidates_at_end':True,
                    'leaky_terminal_wealth':float(leaky[-1]),'causal_gross_terminal_wealth':gross['terminal_wealth'],
                    'causal_net_terminal_wealth':net['terminal_wealth'],'total_one_way_trades':net['total_one_way_trades']}
    sequence = np.array([-.02,-.02,-.01,.01,.02,.02,.03,.02,.01,-.01,-.02,-.03])
    boot = {str(l):circular_block_means(sequence,l) for l in [1,3,6]}
    f['bootstrap'] = {'values':sequence.tolist(),'draws':5000,'seed':1702,
                       'block_length_mean_percentiles':{l:np.quantile(v,[.025,.5,.975]).tolist() for l,v in boot.items()}}
    fig,ax = plt.subplots(1,2,figsize=(10.2,4.1),layout='constrained')
    rates = np.linspace(0,.2,101)
    for saving,color in [(3000,'#8C4A35'),(4000,'#345C80'),(5000,'#54806A')]:
        ax[0].plot(rates*100,[npv([-10000,saving,saving,saving],rate) for rate in rates],label=f'${saving:,} yearly savings',color=color)
    ax[0].axhline(0,color='gray',lw=.8);ax[0].axvline(5,color='gray',ls=':')
    ax[0].set(xlabel='Annual discount rate (%)',ylabel='NPV (USD)',title='A positive forecast depends on its assumptions')
    ax[0].legend(fontsize=11.5)
    ax[1].plot(range(len(wealth)),wealth,'o-',color='#345C80',label='wealth')
    ax[1].plot(range(len(wealth)),np.maximum.accumulate(wealth),'--',color='#B46B20',label='running peak')
    ax[1].fill_between(range(len(wealth)),wealth,np.maximum.accumulate(wealth),color='#DCE7EE')
    ax[1].set(xlabel='Period',ylabel='Wealth index',title=f'Ends above 100; maximum drawdown {-dd.min():.1%}')
    ax[1].legend(fontsize=11.5)
    save(fig,'15_cashflow_and_drawdown')
    fig,ax = plt.subplots(1,2,figsize=(10.2,4.1),layout='constrained')
    grid = np.linspace(0,1,101)
    for rho,color in [(.5,'#345C80'),(0.,'#B46B20'),(-.5,'#54806A')]:
        s = np.array([[.04,rho*.2*.1],[rho*.2*.1,.01]])
        vol = [np.sqrt(portfolio_variance([weight,1-weight],s))*100 for weight in grid]
        ax[0].plot(grid,vol,label=f'correlation = {rho:g}',color=color)
    ax[0].set(xlabel='Weight in asset A (20% volatility)',ylabel='Per-period portfolio volatility (%)',title='Covariance changes the value of diversification')
    ax[0].legend(fontsize=11.5)
    ax[1].plot(range(7),leaky,'o-',label='invalid same-period signal',color='#54806A')
    ax[1].plot(range(7),gross['wealth_before_final_liquidation'],'s-',label='lagged signal, no costs',color='#345C80')
    ax[1].plot(range(7),net['wealth_before_final_liquidation'],'^-',label='lagged signal, with costs',color='#B46B20')
    ax[1].scatter([6],[net['terminal_wealth']],marker='x',color='black',label='after final sale')
    ax[1].set(xlabel='Period',ylabel='Wealth index',title='A one-period timing error reverses the story')
    ax[1].legend(fontsize=11.5,loc='upper center',bbox_to_anchor=(.5,-.23))
    save(fig,'16_portfolio_and_backtest')
    write_csv(out/'gis_point_join.csv',[{'id':label,'x_km':point[0],'y_km':point[1],
               'half_open_zones':';'.join(str(j+1) for j in matches)} for label,point,matches in zip('ABCDEFG',p,joins['half_open'])])
    write_csv(out/'finance_backtest.csv',[{'period':i+1,'asset_return':r[i],'close_signal':signal[i],
               'held_position':net['position'][i],'one_way_turnover':net['turnover'][i],
               'net_period_factor':net['period_factor'][i],'wealth_before_terminal_sale':net['wealth_before_final_liquidation'][i+1]} for i in range(len(r))])
    (out/'gis_finance_fixtures.json').write_text(json.dumps(f,indent=2)+'\n')
    print(json.dumps({'chapters':[16,17],'figures':4,'fixture':str(out/'gis_finance_fixtures.json'),
                      'NPV_5pct':f['cashflow']['npv_5pct_usd'],'Moran_I':observed,
                      'Moran_exact_right_p':f['moran']['exact_right_p'],'causal_net_wealth':net['terminal_wealth']},indent=2))
    return f


if __name__ == '__main__':
    run()
