# Reproduce the mathematical examples

These original examples support Chapters 14, 15, and 18. All their arrays, image values, model coefficients, and simulated draws are synthetic. They do not extend the empirical evidence from the scheduler simulator.

From the expanded book root:

```bash
python companion/math_examples.py
python companion/check_math_examples.py
```

The code uses Python, NumPy, and matplotlib already required by the first-edition companion. Verified versions are Python 3.12.14, NumPy 2.3.5, and matplotlib 3.10.8. No external data, network access, GPU, SciPy, scikit-image, or scikit-learn installation is required. Those projects' documentation is linked where useful for concepts or production APIs; the small teaching routines here are explicit implementations for the stated fixtures.

## Generated files

- derived/math_fixtures.json contains inputs and numerical outputs for projection, least squares, PCA, Gaussian distance concentration, the image, the frequency example, and the worker model
- derived/high_dimensional_distances.csv contains four dimension-specific summaries, each from 5,000 simulated pairs
- derived/image_threshold_measurements.csv records components, counts, calibrated area, centroid, and known-reference IoU for three thresholds
- derived/worker_sensitivity.csv records nominal timing, Monte Carlo timing summaries, and analytic duration standard deviations for 1 through 32 workers
- Figure assets with stems 07 through 12 contain the six mathematical PNG and SVG figures; displayed book numbering follows chapter order

## Conventions

Observations occupy matrix rows. PCA centers columns; it does not standardize these already comparable synthetic indices to unit variance. Signs of singular vectors are fixed only to stabilize plots. Signs do not affect reconstruction.

Image rows increase downward and columns increase rightward. Coordinates refer to pixel centers at integer indices. The synthetic square occupies rows 18:42 and columns 20:44 in Python's end-exclusive slicing. The NumPy reflect padding used for grayscale convolution excludes the edge value in the reflected extension. Binary morphology uses a 3-by-3 square and false values outside the image. Component labeling uses four-connectivity. The separate one-dimensional Fourier example uses periodic boundaries and exact DFT-bin frequencies.

The worker model is T(n) = a/n + b + c(n-1). Its uncertain coefficients are independent uniforms with bounds [80,120], [1,3], and [0.1,0.3]. A coefficient triple is shared across worker counts within each of the 100,000 draws. Input uncertainty and Monte Carlo numerical error are different. The per-draw optimum is a sensitivity diagnostic assuming those coefficients were known, not an implementable clairvoyant policy.

The mean of per-batch rates and aggregate rate use different denominators. Both are stored with explicit names. For equal-sized sequential batches, the aggregate rate is total items divided by total elapsed duration.

## What the checks establish

The checks compare calculations to hand answers and independent analytic identities, execute chapter Python snippets, probe invalid kernels and connectivity edge cases, and verify that preserved first-edition chapters and pinned snapshot files retain their hashes. They do not certify a real image-measurement system, hardware model, or investment strategy. The data model and algorithm need a separate validation for any real application.
