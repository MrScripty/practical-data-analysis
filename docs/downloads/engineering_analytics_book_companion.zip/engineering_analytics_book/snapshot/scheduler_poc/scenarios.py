"""Declared synthetic profiles. All effective rates are assumptions, not benchmarks."""
from dataclasses import replace
import random
from .domain import Host, Model, Task, Hint, Scenario


def workstation(**kwargs):
    return replace(Host("local"), **kwargs)


def model_set():
    return [Model("text-q4",4.5,2,.75,.5), Model("vision-fp16",6,2.5,1,.5), Model("embed-fp16",1.2,.5,.25,.2)]


def build(name, seed=7):
    rng = random.Random(seed)
    models = model_set()
    if name == "batching":
        tasks = [Task(f"n{i:02}","batch",f"request{i}","text-q4" if i%2==0 else "vision-fp16",
                      6+rng.uniform(-.8,.8),kv_peak=.8) for i in range(10)]
        return Scenario(name,"Alternating models, one GPU copy and useful CPU replica",[workstation(vram=9,storage_gib_s=1,mixed_slowdown=1.08)],models,tasks,resident=[("local","gpu","text-q4")])
    if name == "cold_start_choice":
        tasks = [Task(f"cold{i}","batch",f"cold-flow{i}","vision-fp16",15,devices=("gpu",)) for i in range(2)]
        tasks += [Task(f"warm{i}","batch",f"warm-flow{i}","text-q4",3,devices=("gpu",)) for i in range(4)]
        return Scenario(name,"Both models fit; FIFO cold-first and warm-first differ in response time",[workstation(vram=24)],models,tasks,resident=[("local","gpu","text-q4")])
    if name == "memory_pressure":
        tasks = [Task(f"generate{i}","chat",f"flow{i}","text-q4",18,devices=("gpu",),vram=1,kv_peak=5,ram=1) for i in range(3)]
        tasks += [Task("vision","vision","vision","vision-fp16",8,devices=("gpu",),arrival=1,vram=2)]
        return Scenario(name,"Future KV and load scratch compete with external reservations",[workstation()],models,tasks,events=[(0,"pressure",{"id":"desktop","resources":{"local:vram":3},"duration":8})])
    if name == "lookahead":
        tasks = [Task("prepare","image","pipeline","embed-fp16",8,devices=("cpu",),terminal=False),Task("render","image","pipeline","vision-fp16",15,deps=("prepare",),devices=("gpu",))]
        return Scenario(name,"Preload before readiness; actual execution waits for inputs",[workstation()],models,tasks,hints=[Hint("render-hint","vision-fp16","image",8.5,15,.95)],resident=[("local","cpu","embed-fp16")])
    if name == "priority_fairness":
        tasks = [Task(f"foreground{i:02}","foreground",f"front{i}","text-q4",10,arrival=i*.6,devices=("gpu",)) for i in range(14)]
        tasks += [Task("cold-background","background","older-workflow","vision-fp16",80,devices=("gpu",),arrival=.1),Task("same-app-old","foreground","old-workflow","vision-fp16",6,devices=("gpu",),arrival=.2)]
        events = [(2,"boost",{"app":"foreground","weight":4,"until":30})]+[(float(i),"boost",{"workflow":"front13","weight":4,"until":40}) for i in range(3,12,2)]
        return Scenario(name,"Repeated boosts cannot starve a cold long episode",[workstation(vram=9)],models,tasks,events=events,resident=[("local","gpu","text-q4")])
    if name == "contention":
        tasks = [Task(f"cpu{i}","prep",f"cpu-flow{i}","embed-fp16",5,devices=("cpu",)) for i in range(4)]+[Task(f"gpu{i}","image",f"gpu-flow{i}","vision-fp16",10,devices=("gpu",)) for i in range(4)]
        return Scenario(name,"Severe mixed-device contention can favor serial execution",[workstation(mixed_slowdown=3.5)],models,tasks,resident=[("local","cpu","embed-fp16"),("local","gpu","vision-fp16")])
    if name == "cancel_failure":
        tasks = [Task("cancel-me","chat","cancel-flow","text-q4",30,devices=("gpu",)),Task("flaky-load","image","retry-flow","vision-fp16",10,devices=("gpu",),arrival=.1),Task("after-cancel","chat","dependent-flow","embed-fp16",2,deps=("cancel-me",))]
        return Scenario(name,"Cancellation and failed loads retain allocations until cleanup",[workstation(vram=10)],models,tasks,events=[(0,"fail_load",{"task":"flaky-load"}),(1,"cancel",{"task":"cancel-me","cleanup_s":3})])
    if name == "remote_fencing":
        remote = Host("lan",ram=64,vram=24,cpu_rate=1.8,gpu_rate=12,storage_gib_s=4,remote=True,link_gib_s=.11,mixed_slowdown=1.2)
        tasks = [Task("remote-small","render","small","vision-fp16",80,input_gib=.01,output_gib=.01),Task("local-large","render","large","vision-fp16",6,input_gib=2,output_gib=.2,arrival=1)]
        return Scenario(name,"LAN costs, stale offers, disconnect and fenced duplicate results",[workstation(),remote],models,tasks,resident=[("lan","gpu","vision-fp16"),("local","gpu","vision-fp16")],events=[(0,"worker_generation",{"host":"lan"}),(.5,"disconnect",{"host":"lan"}),(1,"fence_retry",{"task":"remote-small"}),(12,"reconnect",{"host":"lan"}),(20,"stale_result",{"task":"remote-small","generation":0})])
    if name == "drift":
        tasks = [Task(f"drift{i}","batch",f"drift-flow{i}","text-q4",12,arrival=i*2,devices=("gpu",)) for i in range(14)]
        return Scenario(name,"Unannounced speed loss tests empirical adaptation",[workstation()],models,tasks,resident=[("local","gpu","text-q4")],events=[(10,"drift",{"host":"local","speed":.4})])
    if name == "serial_owner":
        tasks = [Task(f"serial{i}","app",f"serial-flow{i}","text-q4" if i%2 else "embed-fp16",8) for i in range(6)]
        return Scenario(name,"Conservative exclusive owner and single resident backend",[workstation(serial_owner=True,replicas=False,overlap_load_compute=False)],models,tasks)
    if name == "unified_memory":
        tasks = [Task(f"unified{i}","app",f"unified-flow{i}","text-q4",10,ram=2,vram=1,kv_peak=3) for i in range(5)]
        return Scenario(name,"CPU/GPU replicas share one physical DRAM pool",[workstation(ram=16,shared_dram=True)],models,tasks)
    if name == "horizon_loss":
        tasks = [Task("long-valuable","long","long-output","vision-fp16",150,devices=("gpu",))]+[Task(f"short{i}","short",f"short-output{i}","text-q4",3,devices=("gpu",),value=.3) for i in range(6)]
        return Scenario(name,"Finite-horizon setup preference can lose to another ordering",[workstation(vram=9)],models,tasks,resident=[("local","gpu","text-q4")])
    if name == "randomized":
        tasks=[]
        for i in range(12):
            model=rng.choice(models); deps=(f"random{i-1}",) if i%4 and rng.random()<.4 else ()
            tasks.append(Task(f"random{i}",f"app{i%3}",f"flow{i//4}",model.id,rng.uniform(1,20),arrival=rng.uniform(0,5),deps=deps,ram=rng.uniform(.2,2),vram=rng.uniform(.3,1.5),kv_peak=rng.choice((0,1,2)),terminal=i%4==3))
        return Scenario(name,"Seeded DAGs, shapes and resource footprints",[workstation(vram=12)],models,tasks)
    raise ValueError(f"Unknown scenario {name}")


NAMES=("batching","cold_start_choice","memory_pressure","lookahead","priority_fairness","contention","cancel_failure","remote_fencing","drift","serial_owner","unified_memory","horizon_loss","randomized")
