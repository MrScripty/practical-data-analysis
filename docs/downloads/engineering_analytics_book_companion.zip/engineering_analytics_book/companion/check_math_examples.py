#!/usr/bin/env python3
"""Check known answers, scientific invariants, edge cases, and preserved inputs.
The analytic identities are independent references for the generated examples.
"""
from pathlib import Path
import hashlib,json,re,math
import numpy as np
from math_examples import conv2,binary_op,components
ROOT=Path(__file__).resolve().parents[1]
f=json.loads((ROOT/'companion/derived/math_fixtures.json').read_text())
checks=[]
def check(name, condition):
    assert condition,name
    checks.append(name)
def close(name,actual,expected,atol=1e-10):
    check(name,np.allclose(actual,expected,rtol=1e-10,atol=atol))

v=f['vectors'];p=f['pca'];ls=f['least_squares']
close('projection hand result',v['projection'],[2,2]);close('projection perpendicular residual',np.dot(v['residual'],v['direction']),0)
close('Pythagorean decomposition',np.dot(v['x'],v['x']),np.dot(v['projection'],v['projection'])+np.dot(v['residual'],v['residual']))
close('covariance hand result',p['covariance'],[[5/3,1],[1,5/3]])
close('PCA eigenvalues hand result',p['eigenvalues'],[8/3,2/3])
close('PCA explained fractions',p['explained_fraction'],[.8,.2])
close('PCA rank one reconstruction',p['rank_one_reconstruction'],[[1.5,1.5],[1.5,1.5],[3.5,3.5],[3.5,3.5]])
close('PCA discarded variance equals reconstruction error',p['squared_reconstruction_error'],(4-1)*p['eigenvalues'][1])
V=np.array(p['axes']);close('PCA axes orthonormal',V@V.T,np.eye(2))
close('PCA full reconstruction',np.array(p['scores'])@V+np.array(p['mean']),p['data'])
close('least squares hand coefficients',ls['beta'],[7/6,.5])
close('least squares hand residuals',ls['residual'],[-1/6,1/3,-1/6])
close('least squares normal equation residual',np.array(ls['features']).T@np.array(ls['residual']),[0,0])
for r in f['high_dimension']:
    d=r['dimensions'];se=math.sqrt(8*d/r['pair_count'])
    check(f'Gaussian distance mean within six MC standard errors d={d}',abs(r['mean_squared_distance']-2*d)<6*se)
    close(f'Gaussian squared distance CV theory d={d}',r['theory_cv_squared_distance'],math.sqrt(2/d))

impulse=np.zeros((5,5));impulse[2,2]=8
close('box convolution center hand result',conv2(impulse,np.ones((3,3))/9)[2,2],8/9)
close('normalized convolution preserves constant at reflect edges',conv2(np.ones((5,5))*7,np.ones((3,3))/9),np.ones((5,5))*7)
asym=np.array([[0,0,0],[0,1,2],[0,0,0]])
shifted=conv2(impulse/8,asym)
close('asymmetric convolution orientation',[shifted[2,1],shifted[2,2],shifted[2,3]],[0,1,2])
for shape in ((2,2),(3,2)):
    try:conv2(impulse,np.ones(shape))
    except ValueError:checks.append(f'invalid kernel shape {shape} rejected')
    else:raise AssertionError('invalid convolution kernel accepted')
single=np.zeros((5,5),bool);single[2,2]=True
check('erosion removes isolated pixel',not binary_op(single,'erode').any())
check('dilation expands isolated pixel into nine',binary_op(single,'dilate').sum()==9)
close('opening restores isolated 3 by 3 square',binary_op(binary_op(binary_op(single,'dilate'),'erode'),'dilate'),binary_op(single,'dilate'))
_,count=components(np.eye(2,dtype=bool));check('four connectivity keeps diagonal pixels separate',count==2)
check('empty mask has no components',components(np.zeros((3,3),bool))[1]==0)
i=f['image'];a=np.array(i['observed']);truth=np.array(i['truth'],bool)
check('image values finite and bounded',np.isfinite(a).all() and a.min()>=0 and a.max()<=1)
check('truth square known pixel count',truth.sum()==576);close('truth calibrated area',i['truth_area_mm2'],23.04)
close('truth pixel center centroid',np.argwhere(truth).mean(axis=0),[29.5,31.5])
check('threshold nesting',np.all((a>=.7)<=(a>=.5)) and np.all((a>=.5)<=(a>=.3)))
close('threshold largest component count regression',[r['largest_pixels'] for r in i['threshold_rows']],[617,574,485])
for r in i['threshold_rows']:
    close(f"area scale at threshold {r['threshold']}",r['largest_area_mm2'],r['largest_pixels']*.04)
    check(f"mask count at threshold {r['threshold']}",r['all_foreground_pixels']==int((a>=r['threshold']).sum()))
raw=a>=.5;closed=binary_op(binary_op(raw,'dilate'),'erode')
check('same area does not establish same mask',closed.sum()==truth.sum() and not np.array_equal(closed,truth))
close('area calibration uncertainty',2*576*.2*.002,.4608)
fr=f['frequency'];amp=np.array(fr['amplitudes']);filtered=np.array(fr['filtered_amplitudes'])
close('two sinusoid amplitudes',[amp[4],amp[20]],[1,.3])
for k,amplitude in ((4,1),(20,.3)):
    gain=.5+.5*np.cos(2*np.pi*k/64)
    close(f'filter analytic Fourier gain bin {k}',filtered[k],amplitude*gain)
check('other Fourier bins numerically zero',np.max(np.delete(amp,[4,20]))<1e-12)
close('Fourier Parseval mean energy',np.mean(np.array(fr['signal'])**2),(1+.3**2)/2)

o=f['optimization'];rows=o['rows']
close('continuous optimum hand result',o['nominal_continuous_minimizer'],math.sqrt(500))
check('nominal integer optimum hand result',o['nominal_integer_minimizer']==22)
check('budget constraint enforced',o['budget_12_minimizer']==12)
close('nominal neighbor difference',o['nominal_23_seconds']-o['nominal_22_seconds'],3/1265)
close('analytic time variance',o['sd_time_22_analytic']**2,400/1452+1/3+441/300)
check('Monte Carlo mean agrees with analytic mean',abs(o['mean_time_22_mc']-o['nominal_22_seconds'])<6*o['sd_time_22_analytic']/math.sqrt(o['draws']))
check('Monte Carlo SD agrees with analytic SD',abs(o['sd_time_22_mc']-o['sd_time_22_analytic'])<.015*o['sd_time_22_analytic'])
close('tail Monte Carlo standard error',o['probability_mc_standard_error'],math.sqrt(o['probability_time_22_above_12']*(1-o['probability_time_22_above_12'])/o['draws']))
check('sampled percentile optimum',min(rows,key=lambda r:r['p95_seconds_mc'])['workers']==20)
check('clairvoyant optimum counts account for draws',sum(o['per_draw_optimum_counts'].values())==o['draws'])
check('nonlinear rate means ordered as expected',o['mean_batch_rate_22_mc']>o['aggregate_batch_rate_22_mc'])
close('aggregate rate denominator',o['aggregate_batch_rate_22_mc'],600/o['mean_time_22_mc'])
close('reduced c uncertainty variance',sum(o['variance_parts_at_22'][:2])+o['variance_parts_at_22'][2]/4,.9763154269972454)
for h in (1e-2,1e-3,1e-4):
    t=lambda n:100/n+2+.2*(n-1)
    close(f'finite difference analytic gradient h={h}',(t(22+h)-t(22-h))/(2*h),-100/22**2+.2,atol=1e-7)
# Code snippets use the chapter's sequential state, as when running top-to-bottom.
for stem in ('14_','15_','18_'):
    chapter=next((ROOT/'chapters').glob(stem+'*.md'));env={}
    for k,code in enumerate(re.findall(r'```python\n(.*?)```',chapter.read_text(),re.S)):
        exec(compile(code,str(chapter), 'exec'),env)
        checks.append(f'{chapter.name} Python snippet {k+1} executes')
for r in json.loads((ROOT/'companion/first_edition_hashes.json').read_text()):
    check('preserved '+r['path'],hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()==r['sha256'])
print(f'PASS: {len(checks)} checks')
for name in checks:print('PASS:',name)
