#!/usr/bin/env python3
"""Release regressions for integration and scale/boundary-sensitive helpers."""
from pathlib import Path
from itertools import permutations
import subprocess,sys
import numpy as np
import gis_finance_examples as g
import math_examples as m
ROOT=Path(__file__).resolve().parents[1]
count=0
def check(condition,description):
    global count
    if not condition:raise AssertionError(description)
    count+=1
def rejects(call,description):
    try:call()
    except ValueError:check(True,description)
    else:raise AssertionError('Accepted invalid input: '+description)
def relative(actual,expected,description):
    # Relative-only comparison must remain meaningful for small coordinate units.
    check(np.allclose(actual,expected,rtol=1e-12,atol=0),description)

losses=np.arange(1.,101.)
grid=np.arange(1,101)/100
for k in range(1,100):
    alpha=grid[k-1]
    check(g.empirical_var_es(losses,alpha)[0]==k,f'VaR CDF boundary {k}')
    check(g.empirical_var_es(losses,np.nextafter(alpha,0))[0]==k,f'VaR below boundary {k}')
    check(g.empirical_var_es(losses,np.nextafter(alpha,1))[0]==k+1,f'VaR above boundary {k}')
for scale in (1e-100,1e-14,1e-8,1.,1e8,1e100):
    relative(g.world_to_pixel([.5*scale,-.5*scale],[0,scale,0,0,0,-scale]),[.5,.5],f'affine unit scale {scale}')
    rejects(lambda:g.world_to_pixel([0,0],np.array([0,1,2,0,2,4])*scale),f'singular affine at scale {scale}')
    good=scale*np.array([[1.,.5],[.5,2.]])
    for weights in ([1.,-1.],[.5,.5]):
        expected=scale*(np.array(weights)@np.array([[1.,.5],[.5,2.]])@np.array(weights))
        relative(g.portfolio_variance(weights,good),expected,f'PSD scaling {scale} weights {weights}')
        bad=scale*np.array([[1.,2.],[2.,1.]])
        rejects(lambda:g.portfolio_variance(weights,bad),f'indefinite covariance at scale {scale} weights {weights}')
    rejects(lambda:g.portfolio_variance([.5,.5],scale*np.array([[1.,.2],[.4,1.]])),f'asymmetry at scale {scale}')
    near=scale*np.array([[1.,.5+np.finfo(float).eps],[.5,1.]])
    relative(g.portfolio_variance([.5,.5],near),.75*scale,f'roundoff asymmetry at scale {scale}')
    check(g.portfolio_variance([0,1],scale*np.diag([1,-np.finfo(float).eps]))==0,f'bounded roundoff clamping at scale {scale}')
check(g.portfolio_variance([1,-1],np.zeros((2,2)))==0,'zero covariance')
check(g.portfolio_variance([0,0],np.eye(2))==0,'zero weights')
rejects(lambda:g.portfolio_variance([0,0],[[1,2],[2,1]]),'invalid covariance rejected even for zero weights')
# A conservative exact 5% test may have zero size: every random-label p >= 1/12.
w=g.chain_weights(4);null=np.array([g.moran_i(v,w) for v in permutations([1,2,3,4])])
pvalues=np.array([np.mean(null>=value-1e-12) for value in null])
check(np.min(pvalues)>.05 and np.count_nonzero(pvalues<=.05)==0,'discrete null counterexample to exactly five expected rejections')
check(100*np.mean(pvalues<=.05)<=5,'multiple-testing expectation upper bound')
# Explicit contracts also survive Python optimization.
rejects(lambda:m.binary_op(np.zeros((3,3),bool),'erdoe'),'unknown morphology operation')
rejects(lambda:m.conv2(np.ones((3,3)),np.ones((2,2))),'even convolution kernel')
check(np.isclose(m.conv2(np.arange(9).reshape(3,3),np.ones((3,3))/9)[0,0],8/3),'NumPy reflect / SciPy mirror corner convention')
probe="""import numpy as np
from math_examples import conv2,binary_op
for fn in (lambda:conv2(np.ones((3,3)),np.ones((2,2))),lambda:binary_op(np.ones((3,3)),'erdoe')):
    try:fn()
    except ValueError:pass
    else:raise RuntimeError('Invalid input accepted under optimized Python')
"""
subprocess.run([sys.executable,'-O','-c',probe],cwd=ROOT/'companion',check=True,capture_output=True)
check(True,'public validation works with python -O')
assets=['01_scheduler_timeline','02_scheduler_ecdf','03_resource_accounting','04_holdout_pairs',
 '05_synthetic_calibration','06_synthetic_cost_quality','07_projection_and_pca','08_distance_concentration',
 '09_image_measurement_pipeline','10_histogram_and_frequency','11_optimization_and_sensitivity',
 '12_uncertainty_and_optima','13_geometry_and_raster_support','14_neighborhoods_and_randomization',
 '15_cashflow_and_drawdown','16_portfolio_and_backtest']
for name in assets:
    for ext in ('png','svg'):
        path=ROOT/'figures'/(name+'.'+ext)
        check(path.is_file() and path.stat().st_size>0,'expected figure asset '+path.name)
# Integration must work in the presence of all expanded figures.
subprocess.run([sys.executable,str(ROOT/'companion/check_outputs.py')],check=True,capture_output=True)
check(True,'original semantic checks allow expanded figures')
print(f'PASS: {count} release regression checks')
