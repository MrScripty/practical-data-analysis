#!/usr/bin/env python3
"""Lightweight semantic checks independent of figure rendering."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'companion'/'derived'
s=json.loads((D/'analysis_summary.json').read_text())
assert s['snapshot_files_verified']==18
m=s['scheduler']['diagnosis_makespan_s']
assert np.isclose(m['before_fix_proposed'],m['after_fix_proposed'])
assert m['fifo'] < m['forced_final_gpu'] < m['after_fix_proposed']
assert m['after_fix_no_protection'] > m['after_fix_proposed']
t=pd.read_csv(D/'scheduler_tasks.csv')
assert len(t)==60 and not t.duplicated(['run_id','task_id']).any()
a=pd.read_csv(D/'synthetic_agent_trials.csv')
assert len(a)==1080 and a.task_id.nunique()==120
assert set(a.data_origin)=={'synthetic'}
assert not a.duplicated(['task_id','variant','trial']).any()
assert ((a.human_pass==a.judge_pass).sum())==944
assert ((a.human_pass==0)&(a.judge_pass==1)).sum()==85
r=pd.read_csv(D/'synthetic_research_records.csv')
assert r.verification_minutes.notna().sum()==84
assert r.verification_minutes.isna().sum()==16
assert np.isclose(r.verification_minutes.mean(),5.5)
assert np.isclose(np.where(r.hard_to_verify,18,4).mean(),7.5)
h=pd.read_csv(D/'holdout_runs.csv')
assert len(h)==72 and len(h[h.regime=='matched_service'])==36
p=pd.read_csv(D/'holdout_paired.csv')
x=p[p.scenario=='randomized'].proposed_minus_residency_s
assert len(x)==3 and (x<0).any() and (x>0).any()
original_figures = ['01_scheduler_timeline', '02_scheduler_ecdf', '03_resource_accounting', '04_holdout_pairs', '05_synthetic_calibration', '06_synthetic_cost_quality']
assert all((ROOT/'figures'/(name+'.png')).is_file() for name in original_figures)
print('PASS: unchanged repair outcome, intervention ordering, complete task keys, synthetic judge denominators, missingness arithmetic, held-out pair population, and the six original generated figures (additional figures allowed).')
