#!/usr/bin/env python3
"""Rebuild the book's derived tables, calculations, and original charts.

Uses only the pinned scheduler snapshot. Does not execute or modify scheduler code.
Synthetic examples are generated here and always labeled as such.
"""
from __future__ import annotations
import hashlib
import json
import math
import platform
import os
import tempfile
from collections import Counter
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir()) / 'engineering-analytics-mpl'))
os.environ.setdefault('XDG_CACHE_HOME', str(Path(tempfile.gettempdir()) / 'engineering-analytics-cache'))
Path(os.environ['MPLCONFIGDIR']).mkdir(parents=True, exist_ok=True)
Path(os.environ['XDG_CACHE_HOME']).mkdir(parents=True, exist_ok=True)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SNAP = ROOT / 'snapshot'
OUT = ROOT / 'companion' / 'derived'
FIG = ROOT / 'figures'
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(exist_ok=True)
COLORS = {'fifo': '#4B5563', 'residency': '#008477', 'proposed': '#9A4115'}
LABELS = {'fifo': 'FIFO', 'residency': 'Residency greedy', 'proposed': 'Proposed'}
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.titleweight': 'bold', 'figure.facecolor': 'white',
                     'savefig.facecolor': 'white'})


def read_json(name):
    return json.loads((SNAP / name).read_text())


def save(fig, name):
    fig.savefig(FIG / (name + '.png'), dpi=180, bbox_inches='tight')
    fig.savefig(FIG / (name + '.svg'), bbox_inches='tight')
    plt.close(fig)


def nearest_rank(values, q):
    """Match the scheduler's convention, not NumPy's interpolated default."""
    v = sorted(values)
    return v[min(len(v)-1, math.ceil(q * len(v))-1)] if v else None


def verify_snapshot():
    m = read_json('manifest.json')
    for f in m['files']:
        b = (SNAP / f['path']).read_bytes()
        assert len(b) == f['bytes'], f['path']
        assert hashlib.sha256(b).hexdigest() == f['sha256'], f['path']
    return len(m['files'])


def require_complete(metrics):
    """These comparisons require a fully completed batch, not its last partial result."""
    assert metrics.get('terminal') is True, 'Incomplete run cannot enter a completed-batch comparison.'
    status = metrics.get('status', {})
    assert status and all(v == 'done' for v in status.values()), 'Unfinished task status.'
    assert metrics.get('completed_nodes') == len(status), 'Completed count disagrees with task statuses.'
    complete = metrics.get('completed_batch_makespan_s')
    assert complete is not None and math.isfinite(complete), 'Completed-batch makespan is missing.'
    assert math.isclose(complete, metrics['makespan_s'], rel_tol=0, abs_tol=1e-9), 'Completed and last-result makespans disagree.'


def parse_trace(label, metrics):
    require_complete(metrics)
    events = [json.loads(s) for s in (SNAP / f'traces/diagnosis_{label}.jsonl').read_text().splitlines()]
    assert all(b['time'] >= a['time'] for a, b in zip(events, events[1:]))
    tasks = {}
    active = {}
    phases = []
    candidates = []
    for event_i, e in enumerate(events):
        t = e['time']; typ = e['event']
        if 'task' in e:
            d = tasks.setdefault(e['task'], {'run_id': label, 'task_id': e['task']})
        if typ == 'arrival':
            assert 'arrival_s' not in d
            d['arrival_s'] = t
        elif typ == 'ready':
            assert 'ready_s' not in d, 'This teaching parser requires a single ready event per task.'
            d['ready_s'] = t
        elif typ == 'phase_start':
            key = (e['task'], e['generation'], e['phase'])
            assert key not in active
            active[key] = e
            d.setdefault('first_phase_s', t)
            d.setdefault('first_device', e['device'])
        elif typ == 'phase_end':
            key = (e['task'], e['generation'], e['phase'])
            assert key in active
            start = active.pop(key)
            phases.append({'run_id': label, 'task_id': e['task'],
                           'generation': e['generation'], 'phase': e['phase'],
                           'host': start['host'], 'device': start['device'],
                           'start_s': start['time'], 'end_s': t,
                           'duration_s': t - start['time']})
        elif typ == 'result_accepted':
            assert 'accepted_s' not in d
            d['accepted_s'] = t
        elif typ == 'decision':
            for i, c in enumerate(e['candidates']):
                candidates.append({'run_id': label, 'event_i': event_i,
                                   'time_s': t, 'candidate_i': i,
                                   'score': c['score'], 'transition_cost': c['transition_cost'],
                                   'mean_shaped_value': c['mean_shaped_value'],
                                   'tail_loss': c['tail_loss'],
                                   'actions_json': json.dumps(c['actions'], sort_keys=True)})
    assert not active, 'Unclosed phase; do not silently discard censored intervals.'
    rows = []
    for task in tasks.values():
        assert all(k in task for k in ['arrival_s', 'ready_s', 'first_phase_s', 'accepted_s'])
        task['latency_s'] = task['accepted_s'] - task['arrival_s']
        task['ready_wait_s'] = task['first_phase_s'] - task['ready_s']
        assert task['latency_s'] >= 0 and task['ready_wait_s'] >= -1e-6
        rows.append(task)
    assert len(rows) == metrics['completed_nodes'] == 12
    assert abs(max(t['accepted_s'] for t in rows) - metrics['makespan_s']) < 2e-6
    for q, key in [(0.5, 'latency_p50_s'), (0.95, 'latency_p95_s')]:
        assert abs(nearest_rank([t['latency_s'] for t in rows], q) - metrics[key]) < 2e-6
    phases_df = pd.DataFrame(phases)
    observed_phases = {
        f'{host}:{device}:{phase}': float(group.duration_s.sum())
        for (host, device, phase), group in phases_df.groupby(['host', 'device', 'phase'])
    }
    expected_phases = metrics['phase_device_seconds']
    # Compare both directions: a whole missing category must not disappear from validation.
    for key in set(observed_phases) | set(expected_phases):
        observed = observed_phases.get(key, 0.0)
        expected = expected_phases.get(key, 0.0)
        assert abs(observed - expected) < 20e-6, f'Phase accounting mismatch: {key}'
    assert set(observed_phases) == set(expected_phases), 'Phase categories disagree.'
    # The five diagnostic traces are all-complete, single-attempt teaching fixtures.
    # A production parser must retain unmatched starts and distinguish retries.
    return pd.DataFrame(rows), phases_df, pd.DataFrame(candidates)


def scheduler_analysis():
    diagnosis = read_json('reports/loss_diagnosis.json')['results']
    task_tables, phase_tables, candidate_tables = [], [], []
    metric_rows = []
    for d in diagnosis:
        t, p, c = parse_trace(d['label'], d['metrics'])
        task_tables.append(t); phase_tables.append(p); candidate_tables.append(c)
        metric_rows.append({'run_id': d['label'], **{k: v for k, v in d['metrics'].items()
                              if isinstance(v, (str, int, float, bool)) or v is None}})
    tasks = pd.concat(task_tables, ignore_index=True)
    phases = pd.concat(phase_tables, ignore_index=True)
    candidates = pd.concat(candidate_tables, ignore_index=True)
    assert not tasks.duplicated(['run_id', 'task_id']).any()
    tasks.to_csv(OUT / 'scheduler_tasks.csv', index=False)
    phases.to_csv(OUT / 'scheduler_phases.csv', index=False)
    candidates.to_csv(OUT / 'scheduler_candidates.csv', index=False)
    pd.DataFrame(metric_rows).to_csv(OUT / 'diagnosis_metrics.csv', index=False)

    # A resource timeline shows phase overlap; the final task is labeled directly.
    fig, axes = plt.subplots(2, 1, figsize=(9.4, 5.1), sharex=True)
    phase_colors = {'load': '#E5B55C', 'compute': '#28638A', 'drain': '#A6BBC8'}
    for ax, run, title in zip(axes, ['fifo', 'after_fix_proposed'], ['FIFO', 'Proposed after candidate repair']):
        df = phases[phases.run_id == run]
        for _, p in df.iterrows():
            y = {'cpu': 0, 'gpu': 1}[p.device]
            ax.broken_barh([(p.start_s, p.duration_s)], (y-.3, .6), facecolors=phase_colors[p.phase])
            if p.phase == 'compute':
                ax.text(p.start_s + p.duration_s/2, y, p.task_id.replace('random', ''), ha='center', va='center', color='white', fontsize=8)
        ax.set_yticks([0, 1], ['CPU', 'GPU']); ax.set_ylim(-.55, 1.6)
        ax.set_title(title, loc='left'); ax.grid(axis='x', alpha=.2)
    from matplotlib.patches import Patch
    axes[0].legend(handles=[Patch(color=c, label=n.title()) for n, c in phase_colors.items()], loc='upper right', ncol=3, frameon=False)
    axes[-1].set_xlabel('Simulated seconds from run origin; numbers identify tasks')
    fig.suptitle('A slower finish is visible in the final CPU interval', x=.1, ha='left', fontsize=13)
    fig.tight_layout(); save(fig, '01_scheduler_timeline')

    fig, ax = plt.subplots(figsize=(8.6, 4.5))
    for run, name, color in [('fifo', 'FIFO', COLORS['fifo']), ('forced_final_gpu', 'Forced final GPU diagnostic', '#008477'), ('after_fix_proposed', 'Proposed', COLORS['proposed'])]:
        x = np.sort(tasks.loc[tasks.run_id == run, 'latency_s'].to_numpy())
        ax.step(np.r_[0, x], np.r_[0, np.arange(1, len(x)+1)/len(x)], where='post', label=name, color=color, linewidth=2, linestyle='--' if run == 'after_fix_proposed' else '-')
        ax.scatter(x, np.arange(1, len(x)+1)/len(x), edgecolors=color, facecolors='white' if run == 'after_fix_proposed' else color, s=19 if run == 'after_fix_proposed' else 13)
    ax.set(xlabel='Task arrival to accepted result in simulated seconds', ylabel='Fraction of tasks at or below latency', ylim=(0, 1.04), title='Seed 7 task latency distributions cross')
    ax.legend(frameon=False, loc='lower right'); ax.grid(alpha=.2)
    fig.tight_layout(); save(fig, '02_scheduler_ecdf')

    accounting = []
    for d in diagnosis:
        if d['label'] not in ['fifo', 'after_fix_proposed', 'forced_final_gpu']: continue
        m = d['metrics']
        for dev in ['cpu', 'gpu']:
            compute = m['phase_device_seconds'].get(f'local:{dev}:compute', 0)
            transition = m['idle_categories'][f'local:{dev}']['reserved_noncompute_s']
            idle = m['idle_categories'][f'local:{dev}']['unreserved_s']
            assert abs(compute+transition+idle-m['simulated_seconds']) < 1e-6
            accounting.append({'run_id': d['label'], 'device': dev, 'compute_s': compute, 'reserved_noncompute_s': transition, 'unreserved_s': idle})
    a = pd.DataFrame(accounting); a.to_csv(OUT/'resource_accounting.csv', index=False)
    fig, ax = plt.subplots(figsize=(8.6, 4.6)); left = np.zeros(len(a))
    for col, label, color in [('compute_s', 'Compute', '#28638A'), ('reserved_noncompute_s', 'Reserved noncompute', '#E5B55C'), ('unreserved_s', 'Unreserved', '#D5D9DE')]:
        ax.barh(np.arange(len(a)), a[col], left=left, label=label, color=color)
        left += a[col]
    labels = {'fifo': 'FIFO', 'after_fix_proposed': 'Proposed', 'forced_final_gpu': 'Forced GPU'}
    ax.set_yticks(np.arange(len(a)), [f'{labels[r.run_id]} | {r.device.upper()}' for r in a.itertuples()])
    ax.invert_yaxis(); ax.set_xlabel('Device seconds over the complete simulated run; one slot per device')
    ax.set_title('Idle accounting locates time without proving its cause', loc='left')
    ax.legend(frameon=False, loc='upper center', bbox_to_anchor=(.5,-.18), ncol=3); fig.tight_layout(); save(fig, '03_resource_accounting')

    holdout = read_json('reports/holdout_matched_evaluation.json')
    records = []
    for r in holdout['results']:
        m=r['metrics']; require_complete(m); records.append({'regime':r['regime'], **{k:m[k] for k in ['scenario','seed','policy','makespan_s','latency_p95_s','max_ready_wait_s','loads','planner_p95_ms']}})
    h=pd.DataFrame(records); assert len(h)==72
    assert not h.duplicated(['regime','scenario','seed','policy']).any()
    h.to_csv(OUT/'holdout_runs.csv',index=False)
    matched=h[h.regime=='matched_service']
    wide=matched.pivot(index=['scenario','seed'],columns='policy',values='makespan_s').reset_index()
    assert len(wide)==12 and not wide[['fifo','proposed','residency']].isna().any().any()
    for base in ['fifo','residency']:
        wide[f'proposed_minus_{base}_s']=wide.proposed-wide[base]
        wide[f'proposed_over_{base}_ratio']=wide.proposed/wide[base]
    wide.to_csv(OUT/'holdout_paired.csv',index=False)
    means=matched.groupby(['scenario','policy'],as_index=False).makespan_s.mean()
    means.to_csv(OUT/'holdout_means.csv',index=False)
    scenarios=['randomized','priority_fairness','contention','lookahead']
    display=['Randomized','Priority stress','Contention','Lookahead']
    fig,axes=plt.subplots(1,2,figsize=(10,4.7),sharey=True)
    for ax,base in zip(axes,['fifo','residency']):
        for i,sc in enumerate(scenarios):
            vals=wide[wide.scenario==sc]
            ax.scatter(vals[f'proposed_minus_{base}_s'],np.array([i-.12,i,i+.12]),color=COLORS['proposed'],s=40)
            for offset, row in zip([-.12,0,.12],vals.itertuples()):
                ax.annotate(str(row.seed),(getattr(row,f'proposed_minus_{base}_s'),i+offset),xytext=(4,3),textcoords='offset points',fontsize=7)
        ax.axvline(0,color='#444444',linewidth=.8); ax.set_title(f'Proposed minus {LABELS[base]}',loc='left')
        ax.set_xlabel('Difference in simulated seconds\nNegative favors proposed'); ax.set_xlim(-13,20); ax.grid(axis='x',alpha=.2)
    axes[0].set_yticks(range(4),display); axes[0].invert_yaxis()
    fig.suptitle('Only three held-out seeds per scenario; show every pair',x=.08,ha='left',fontsize=13)
    fig.tight_layout(); save(fig,'04_holdout_pairs')

    ablation=read_json('reports/objective_ablation.json')
    for row in ablation['results']:
        require_complete(row['metrics'])
    ab=pd.DataFrame([{'scenario':r['metrics']['scenario'],'seed':r['metrics']['seed'],'changed_makespan_s':r['metrics']['makespan_s']} for r in ablation['results']])
    base=matched[matched.policy=='proposed'][['scenario','seed','makespan_s']]
    ab=ab.merge(base,on=['scenario','seed'],validate='one_to_one',how='outer',indicator=True)
    assert (ab['_merge']=='both').all()
    ab['changed_minus_default_s']=ab.changed_makespan_s-ab.makespan_s
    ab.drop(columns=['_merge']).to_csv(OUT/'objective_ablation_pairs.csv',index=False)
    summary={'diagnosis_makespan_s':{d['label']:d['metrics']['makespan_s'] for d in diagnosis},
             'matched_means_s':{s:{p:float(matched[(matched.scenario==s)&(matched.policy==p)].makespan_s.mean()) for p in ['fifo','residency','proposed']} for s in scenarios},
             'ablation_means_s':{s:float(ab[ab.scenario==s].changed_makespan_s.mean()) for s in scenarios},
             'warning':'Descriptive simulator results; 3 held-out seeds per scenario. No deployment superiority or confident population-tail claim.'}
    return summary


def synthetic_examples():
    rng=np.random.default_rng(20261002)
    # The population and generation rules are invented for teaching only.
    rows=[]
    for task in range(120):
        difficulty='hard' if task%3==0 else 'easy'
        for variant,cost,baseprob in [('small',.025,.73),('large',.11,.87),('review',.17,.91)]:
            prob=baseprob-(.24 if difficulty=='hard' else 0)
            for trial in range(3):
                human=int(rng.random()<prob)
                # A flawed judge is more likely to miss a failure than reject a success.
                judge=int(rng.random() < (.95 if human else .28))
                confidence=float(np.clip((.88 if judge else .27)+rng.normal(0,.06),.01,.99))
                rows.append({'data_origin':'synthetic','task_id':f't{task:03d}','family':difficulty,'variant':variant,'trial':trial,'human_pass':human,'judge_pass':judge,'judge_probability_pass':confidence,'cost_usd':cost*(.85+.3*rng.random()),'latency_s':(4+35*cost)*(1+.45*(difficulty=='hard'))*(.8+.4*rng.random())})
    a=pd.DataFrame(rows); a.to_csv(OUT/'synthetic_agent_trials.csv',index=False)
    judge=pd.crosstab(a.human_pass,a.judge_pass).reindex(index=[0,1],columns=[0,1],fill_value=0)
    judge.to_csv(OUT/'synthetic_judge_confusion.csv')
    a['bin']=pd.cut(a.judge_probability_pass,np.linspace(0,1,6),include_lowest=True)
    bins=a.groupby('bin',observed=True).agg(n=('human_pass','size'),mean_predicted=('judge_probability_pass','mean'),observed_pass=('human_pass','mean')).reset_index()
    bins.to_csv(OUT/'synthetic_calibration.csv',index=False)
    fig,(ax,hist)=plt.subplots(2,1,figsize=(7.5,6.2),gridspec_kw={'height_ratios':[3,1]},sharex=True)
    ax.plot([0,1],[0,1],linestyle='--',color='#888888',label='Perfect calibration')
    ax.plot(bins.mean_predicted,bins.observed_pass,'o-',color='#9A4115',label='Synthetic judge')
    for r in bins.itertuples(): ax.annotate(f'n={r.n}',(r.mean_predicted,r.observed_pass),xytext=(4,-13),textcoords='offset points',fontsize=8)
    ax.set(ylabel='Observed human pass fraction',ylim=(0,1),title='A judge score is a prediction to check - synthetic example')
    ax.legend(frameon=False); ax.grid(alpha=.2)
    hist.hist(a.judge_probability_pass,bins=np.linspace(0,1,6),color='#28638A',edgecolor='white')
    hist.set(xlabel='Judge predicted probability of passing',ylabel='Trials',xlim=(0,1))
    fig.tight_layout(); save(fig,'05_synthetic_calibration')
    metrics=a.groupby('variant').agg(success=('human_pass','mean'),cost=('cost_usd','mean'),latency=('latency_s','mean'),trials=('human_pass','size'))
    metrics['cost_per_observed_success_usd']=a.groupby('variant').cost_usd.sum()/a.groupby('variant').human_pass.sum()
    metrics.to_csv(OUT/'synthetic_agent_metrics.csv')
    fig,ax=plt.subplots(figsize=(7.5,4.5))
    for name,r in metrics.iterrows():
        ax.scatter(r.cost,r.success,s=90,color='#28638A'); ax.annotate(name,(r.cost,r.success),xytext=(5,6),textcoords='offset points')
    ax.set(xlabel='Mean cost per attempt in illustrative USD',ylabel='Observed success fraction',ylim=(.4,1),xlim=(0,.2),title='Cost and quality must be compared together - synthetic')
    ax.grid(alpha=.2); fig.tight_layout(); save(fig,'06_synthetic_cost_quality')
    # Thirty independent synthetic blocks; preserve pairs during resampling.
    baseline=rng.lognormal(mean=3.5,sigma=.25,size=30)
    differences=rng.normal(loc=-2,scale=4,size=30)
    changed=baseline+differences
    paired=pd.DataFrame({'data_origin':'synthetic','block_id':np.arange(30),'baseline_s':baseline,'changed_s':changed,'difference_s':differences})
    paired.to_csv(OUT/'synthetic_paired_runs.csv',index=False)
    boot_rng=np.random.default_rng(82)
    indices=boot_rng.integers(0,len(differences),size=(20000,len(differences)))
    bootstrap_means=differences[indices].mean(axis=1)
    low,high=np.quantile(bootstrap_means,[.025,.975])
    # Synthetic collection bias example: values missing by a known generated rule.
    research=[]
    for i in range(100):
        source='catalog_a' if i<70 else 'catalog_b'
        hard=i%4==0
        research.append({'data_origin':'synthetic','record_id':f'r{i:03d}','source':source,'hard_to_verify':hard,'verification_minutes':None if (hard and i%3!=0) else (18 if hard else 4),'missing_reason':'unresolved' if (hard and i%3!=0) else ''})
    pd.DataFrame(research).to_csv(OUT/'synthetic_research_records.csv',index=False)
    return {'paired_mean_difference_s':float(differences.mean()),'paired_percentile_bootstrap_95_interval_s':[float(low),float(high)],'paired_independent_blocks':30,'bootstrap_resamples':20000,'judge_confusion':{'true_negative':int(judge.loc[0,0]),'false_positive':int(judge.loc[0,1]),'false_negative':int(judge.loc[1,0]),'true_positive':int(judge.loc[1,1])},'warning':'All values in this section are synthetic teaching examples, not project findings.'}


def main():
    checked=verify_snapshot()
    summary={'snapshot_files_verified':checked,'scheduler':scheduler_analysis(),'synthetic':synthetic_examples()}
    summary['environment']={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'matplotlib':matplotlib.__version__}
    (OUT/'analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (OUT/'validation.txt').write_text(f'PASS: {checked} input hashes; 5 complete diagnostic traces; 60 unique task rows; phase accounting; nearest-rank quantiles; 72 unique holdout run rows; 12 matched seed/scenario groups; 12 objective ablation pairs.\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
