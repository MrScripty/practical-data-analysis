#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil,zipfile
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1]
STEM='practical_data_analysis_for_engineering_decisions'
stage=ROOT/'qa/package_stage'/'engineering_analytics_book'
if stage.exists():shutil.rmtree(stage)
stage.mkdir(parents=True)
for folder in ['chapters','sources','snapshot','figures','companion','covers','production']:
    shutil.copytree(ROOT/folder,stage/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ['README.md','requirements-analysis.txt','verify_package.py']:
    shutil.copy2(ROOT/name,stage/name)
for ext in ['pdf','md']:
    shutil.copy2(ROOT/'output'/(STEM+'.'+ext),stage/(STEM+'.'+ext))
rows=[]
for p in sorted(stage.rglob('*')):
    if p.is_file():
        b=p.read_bytes();rows.append({'path':str(p.relative_to(stage)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(stage/'package_manifest.json').write_text(json.dumps({'title':'Practical Data Analysis for Engineering Decisions','version_date':'2026-10-02','edition':'expanded','author':'Puma','pdf_pages':len(PdfReader(ROOT/'output'/(STEM+'.pdf')).pages),'files':rows},indent=2)+'\n')
zpath=ROOT/'output'/'engineering_analytics_book_companion.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(stage.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(stage.parent))
receipt=[]
for p in [ROOT/'output'/(STEM+'.pdf'),ROOT/'output'/(STEM+'.md'),zpath]:
    b=p.read_bytes();receipt.append({'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(ROOT/'qa/final_delivery_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'package_files':len(rows)+1,'artifacts':receipt},indent=2))
